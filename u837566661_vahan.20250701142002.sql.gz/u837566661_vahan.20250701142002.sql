/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u837566661_vahan
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_admin_login`
--

DROP TABLE IF EXISTS `tbl_admin_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` varchar(200) NOT NULL,
  `modify_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin_login`
--

/*!40000 ALTER TABLE `tbl_admin_login` DISABLE KEYS */;
INSERT INTO `tbl_admin_login` VALUES
(1,'','admin@gmail.com','123',0,'','2018-10-09 04:57:47');
/*!40000 ALTER TABLE `tbl_admin_login` ENABLE KEYS */;

--
-- Table structure for table `tbl_banner`
--

DROP TABLE IF EXISTS `tbl_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(150) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updateAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_banner`
--

/*!40000 ALTER TABLE `tbl_banner` DISABLE KEYS */;
INSERT INTO `tbl_banner` VALUES
(19,'app-banner-3.jpg','2024-10-21 05:42:15','2024-10-21 05:42:15'),
(20,'app-banner-4.jpg','2024-10-21 06:20:04','2024-10-21 06:20:04');
/*!40000 ALTER TABLE `tbl_banner` ENABLE KEYS */;

--
-- Table structure for table `tbl_booking`
--

DROP TABLE IF EXISTS `tbl_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` tinyint(4) DEFAULT NULL,
  `pickupLocation` varchar(200) NOT NULL,
  `dropLocation` varchar(200) NOT NULL,
  `picklat` text NOT NULL,
  `droplat` text NOT NULL,
  `picklng` text NOT NULL,
  `droplng` text NOT NULL,
  `kmDiff` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `comments` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `phoneNumber` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL,
  `total_quote` varchar(100) NOT NULL,
  `quote_date` varchar(100) NOT NULL,
  `bookingType` varchar(100) NOT NULL,
  `otp` varchar(100) NOT NULL,
  `includeTollAndFuel` tinyint(11) NOT NULL DEFAULT 0,
  `startOdometerReading` varchar(150) NOT NULL,
  `endOdometerReading` varchar(150) NOT NULL,
  `category` tinyint(4) DEFAULT 0,
  `brand` tinyint(4) DEFAULT 0,
  `model` tinyint(4) DEFAULT 0,
  `bookFrom` varchar(100) NOT NULL,
  `bookTo` varchar(100) NOT NULL,
  `insuranceType` varchar(100) NOT NULL,
  `regNo` varchar(100) NOT NULL,
  `mfgYear` varchar(100) NOT NULL,
  `chasis` varchar(100) NOT NULL,
  `engNo` varchar(100) NOT NULL,
  `rcFrontUpload` varchar(100) NOT NULL,
  `rcBackUpload` varchar(100) NOT NULL,
  `source` varchar(150) DEFAULT NULL,
  `pay_status` varchar(200) NOT NULL DEFAULT 'unpaid',
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `assignDriverId` int(11) NOT NULL,
  `statusDriverTwo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_booking`
--

/*!40000 ALTER TABLE `tbl_booking` DISABLE KEYS */;
INSERT INTO `tbl_booking` VALUES
(1,1,'3MF6+R7Q, Usargaon Village, Osargav, Uttar Pradesh 285202, India','Orai','26.0746133','25.987523','79.660663','79.4488695','23.703','21-06-2025','20 : 25','Part Load','test db clear','sagar  test','testing@gma.com','','1234567890','ONGOING','1000','2025-06-26','TRAILER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-21 14:56:01','2025-06-26 12:55:43',0,''),
(2,1,'3MF5+7VQ, Usargaon Village, Osargav, Uttar Pradesh 285202, India','','26.074669089606118','','79.6608617529273','','','22-06-2025','14 : 52','','zvzbzb','sagar  test','testing@gma.com','','1234567890','ASSIGNED','','','INSPECTION','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-22 09:22:21','2025-06-24 16:32:53',0,''),
(3,4,'6622+V78, Ladinaka, Morivali, Ambernath, Maharashtra 421501, India','Pune','19.2021397','18.5246091','73.2007072','73.8786239','152.349','04-06-2025','05:50 pm','','test','Amit Shukla','aashukla04@gmail.com','','9764334576','BOOKED','','','TOWING','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-22 12:20:59','2025-06-22 12:20:59',0,''),
(4,4,'6622+V78, Ladinaka, Morivali, Ambernath, Maharashtra 421501, India','Pune','19.2021302','18.5246091','73.2007108','73.8786239','152.35','10-06-2025','06:31 pm','','test','Amit Shukla','aashukla04@gmail.com','','9764334576','BOOKED','','','TOWING','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-22 13:02:12','2025-06-22 13:02:12',0,''),
(8,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','Haridwar','28.6468192','29.9456906','77.5090958','78.16424780000001','194.596','26-06-2025','12 : 19','Part Load','shahsh','sagar  test','testing@gma.com','','1234567860','ASSIGNED','500','2025-06-26','TRAILER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-26 06:47:11','2025-06-28 15:51:04',0,''),
(9,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','','28.646800135614797','','77.50910885632038','','','26-06-2025','20 : 31','','uwuw','sagar  test','testing@gma.com','','1234567890','COMPLETED','','','INSPECTION','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-26 14:59:38','2025-06-28 15:03:27',0,''),
(12,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','Haridwar','28.64676','29.9456906','77.5091542','78.16424780000001','194.599','26-06-2025','23 : 15','Part Load','hdjdn','sagar  test','testing@gma.com','','1234567890','BOOKED','','','TRAILER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-26 17:31:51','2025-06-26 17:31:51',0,''),
(15,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','Itarsi, Madhya Pradesh, India','28.646753','22.611454','77.509144','77.762332','854.748','28-06-2025','11:00 AM','B2B Intercity','shshshs','sagar  test','testing@gma.com','','1216464978','COMPLETED','','','DRIVER','4394',0,'','12365',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-28 05:20:47','2025-06-29 16:26:52',2,''),
(16,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','Shirdi, Maharashtra, India','28.646764','19.764536','77.509148','74.476212','1278.054','29-06-2025','10:00 PM','B2B Intercity','shdheh','sagar  test','testing@gma.com','','1234567890','BOOKED','','','DRIVER','1234',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-29 15:56:34','2025-06-29 16:26:01',0,''),
(17,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','ITO Delhi','28.6467818','28.6275431','77.5091179','77.242955','33.419','29-06-2025','22 : 5','Part Load','sbzb','sagar  test','testing@gma.com','','1234567890','BOOKED','','','TRAILER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-29 16:32:54','2025-06-29 16:32:54',0,''),
(18,1,'8V9R+WC9, Ambala-Dehradun-Rishikesh Rd, East Hopetown, Uttarakhand 248007, भारत','Delhi, भारत','30.319156','28.704059','77.891237','77.102490','255.511','30-06-2025','10:04 pm','Hourly','test','sagar  test','testing@gma.com','','8077151869','BOOKED','','','DRIVER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-29 16:34:22','2025-06-29 16:34:22',0,''),
(19,1,'8V9R+WC9, Ambala-Dehradun-Rishikesh Rd, East Hopetown, Uttarakhand 248007, भारत','Delhi, भारत','30.319156','28.704059','77.891237','77.102490','255.511','30-06-2025','10:07 am','B2B Intercity','test','sagar  test','testing@gma.com','','8077151869','BOOKED','','','DRIVER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-29 16:37:24','2025-06-29 16:37:24',0,''),
(20,1,'8V9R+WC9, Ambala-Dehradun-Rishikesh Rd, East Hopetown, Uttarakhand 248007, भारत','Delhi, भारत','30.319145','28.704059','77.891236','77.102490','255.51','30-06-2025','07:11 pm','B2B Intercity','test','sagar  test','testing@gma.com','','8877151869','BOOKED','','','DRIVER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-29 16:41:40','2025-06-29 16:41:40',0,''),
(21,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','Itarsi, Madhya Pradesh, India','28.646809','22.611454','77.509104','77.762332','854.747','29-06-2025','10:45 PM','B2B Intercity','bbjnnnmn','sagar  test','testing@gma.com','','1234567890','ASSIGNED','','','DRIVER','5062',0,'12345','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-29 17:08:33','2025-06-30 16:29:10',2,''),
(22,1,'Wave City Executive Floors A185-A188, Wave City, Ghaziabad, Uttar Pradesh 201002, India','Haridwar, Uttarakhand, India','28.646787','29.945691','77.509122','78.164248','194.597','30-06-2025','08:45 PM','B2B Intercity','bz zbz','sagar  test','testing@gma.com','','6767679797','ACCEPTED','','','DRIVER','1385',0,'12345','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-30 15:13:24','2025-06-30 16:58:51',2,''),
(23,4,'6622+R83, Ladinaka, Morivali, Ambernath, Maharashtra 421501, India','Delhi','19.20205','28.7040592','73.2007651','77.10249019999999','1356.428','02-07-2025','9 : 30','Part Load','test','Amit Shukla','aashukla04@gmail.com','','9764334576','COMPLETED','20000','2025-07-01','TRAILER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-06-30 18:54:23','2025-06-30 19:19:56',0,''),
(24,6,'Delhi','Vijayapura New Bus stand','28.7040592','16.8317512','77.10249019999999','75.7016167','1619.145','01-07-2025','10 : 52','Part Load','inspection','shashikumar kumbhar','skumbhar031@gmail.com','','9653610533','BOOKED','','','TRAILER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-07-01 03:24:13','2025-07-01 03:24:13',0,''),
(25,11,'BMC parking yard ashrof royal mulund 400578','Dapodi Railway Station, Old Mumbai - Pune Highway, Dapodi, Pimpri-Chinchwad, Maharashtra, India','12.957148','18.582522','77.566954','73.832257','879.679','01-07-2025','01:05 pm','B2B Intercity','after drop call me','SANJEEV  BHOSALE','sheetalbhosalebhosale@gmail.com','','9960944599','BOOKED','','','DRIVER','',0,'','',0,0,0,'','','','','','','','','','APP','unpaid','2025-07-01 05:47:59','2025-07-01 05:47:59',0,'');
/*!40000 ALTER TABLE `tbl_booking` ENABLE KEYS */;

--
-- Table structure for table `tbl_booking_breakdown`
--

DROP TABLE IF EXISTS `tbl_booking_breakdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_booking_breakdown` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `reason` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_booking_breakdown`
--

/*!40000 ALTER TABLE `tbl_booking_breakdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_booking_breakdown` ENABLE KEYS */;

--
-- Table structure for table `tbl_booking_payment`
--

DROP TABLE IF EXISTS `tbl_booking_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_booking_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `orderId` varchar(200) DEFAULT NULL,
  `paymentId` varchar(200) NOT NULL,
  `totalAmountDate` varchar(100) NOT NULL,
  `totalAmount` varchar(100) NOT NULL,
  `partialPaymentId` text NOT NULL,
  `partialPaymentDate` varchar(100) NOT NULL,
  `partialAmount` varchar(100) NOT NULL,
  `paidAmount` varchar(200) NOT NULL,
  `tollPrice` varchar(100) DEFAULT NULL,
  `fuelPrice` varchar(100) DEFAULT NULL,
  `gst` varchar(100) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_booking_payment`
--

/*!40000 ALTER TABLE `tbl_booking_payment` DISABLE KEYS */;
INSERT INTO `tbl_booking_payment` VALUES
(1,0,'','','','4248.31','','','','850.0','0.0','0.0','764.69','cancelled','APP','2025-06-25 15:36:52','2025-06-25 15:36:52'),
(2,0,'','','','4319.49','','','','864.0','0.0','0.0','777.51','cancelled','APP','2025-06-25 16:34:55','2025-06-25 16:34:55'),
(3,0,'','','','8332.63','','','','1667.0','0.0','0.0','1499.87','cancelled','APP','2025-06-28 05:21:15','2025-06-28 05:21:15'),
(4,0,'','','','672.88','','','','135.0','0.0','0.0','121.12','cancelled','APP','2025-06-29 16:34:40','2025-06-29 16:34:40'),
(5,0,'','','','4405.08','','','','882.0','0.0','0.0','792.92','cancelled','APP','2025-06-29 16:38:40','2025-06-29 16:38:40'),
(6,20,'','','','4405.08','','','','882.0','0.0','0.0','792.92','cancelled','APP','2025-06-29 16:42:00','2025-06-29 16:42:00'),
(7,21,'','','','8332.63','','','','1667.0','0.0','0.0','1499.87','cancelled','APP','2025-06-29 17:08:59','2025-06-29 17:08:59'),
(8,25,'','','','2272.88','','','','455.0','0.0','0.0','409.12','cancelled','APP','2025-07-01 05:53:23','2025-07-01 05:53:23');
/*!40000 ALTER TABLE `tbl_booking_payment` ENABLE KEYS */;

--
-- Table structure for table `tbl_booking_tracking`
--

DROP TABLE IF EXISTS `tbl_booking_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_booking_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `comment` text NOT NULL,
  `date_time` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_booking_tracking`
--

/*!40000 ALTER TABLE `tbl_booking_tracking` DISABLE KEYS */;
INSERT INTO `tbl_booking_tracking` VALUES
(1,8,'1. Driver 1 pickup\r\n2. Driver 1 Drop\r\n3. Yard Reached\r\n4. Loaded from Yard - xyz123try\r\n5. Unloaded at yard \r\n6. Driver 2 Pickup\r\n7. Driver 2 Drop\r\n8. Booking Complete','2025-06-26 18:27:55','2025-06-26 12:57:55','2025-06-26 12:57:55'),
(2,14,'Yard 1 reached','2025-06-27 20:01:36','2025-06-27 14:31:36','2025-06-27 14:31:36'),
(3,14,'Load to trailer','2025-06-27 20:01:49','2025-06-27 14:31:49','2025-06-27 14:31:49'),
(4,14,'ahmedabad','2025-06-27 20:02:07','2025-06-27 14:32:07','2025-06-27 14:32:07'),
(5,14,'jaipur','2025-06-27 20:02:20','2025-06-27 14:32:20','2025-06-27 14:32:20'),
(6,14,'yard 2 reached','2025-06-27 20:02:27','2025-06-27 14:32:27','2025-06-27 14:32:27'),
(7,13,'yard 1','2025-06-27 20:04:50','2025-06-27 14:34:50','2025-06-27 14:34:50'),
(8,13,'treck1','2025-06-27 20:04:58','2025-06-27 14:34:58','2025-06-27 14:34:58'),
(9,23,'Car reached taloja yard','2025-07-01 00:32:58','2025-06-30 19:02:58','2025-06-30 19:02:58'),
(10,0,'','2025-07-01 00:33:03','2025-06-30 19:03:03','2025-06-30 19:03:03'),
(11,23,'Car reached delhi parking yard','2025-07-01 00:41:29','2025-06-30 19:11:29','2025-06-30 19:11:29'),
(12,23,'Car delivered to dealer','2025-07-01 00:49:20','2025-06-30 19:19:20','2025-06-30 19:19:20');
/*!40000 ALTER TABLE `tbl_booking_tracking` ENABLE KEYS */;

--
-- Table structure for table `tbl_car_brand`
--

DROP TABLE IF EXISTS `tbl_car_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_car_brand`
--

/*!40000 ALTER TABLE `tbl_car_brand` DISABLE KEYS */;
INSERT INTO `tbl_car_brand` VALUES
(6,2,'SKODA','2024-05-16 07:39:02','2024-05-16 07:39:02'),
(7,2,'HYUNDAI','2024-05-16 07:41:38','2024-05-16 07:41:38'),
(8,2,'MARUTI SUZUKI','2024-05-16 07:43:10','2024-05-22 09:46:03'),
(9,2,'FIAT','2024-05-16 07:46:17','2024-05-16 07:46:17'),
(10,2,'AUDI','2024-05-16 07:46:38','2024-05-16 07:46:38'),
(11,2,'BMW','2024-05-16 07:46:52','2024-05-16 07:46:52'),
(12,2,'CHEVROLET','2024-05-16 07:47:44','2024-05-16 07:47:44'),
(13,2,'DATSUN','2024-05-16 07:48:00','2024-05-16 07:48:00'),
(14,2,'FORD','2024-05-16 07:49:48','2024-05-16 07:49:48'),
(15,2,'HONDA','2024-05-16 07:50:06','2024-05-16 07:50:06'),
(16,2,'JAGUAR','2024-05-16 07:50:32','2024-05-16 07:50:32'),
(17,2,'JEEP','2024-05-16 07:50:46','2024-05-16 07:50:46'),
(18,2,'KIA','2024-05-16 07:51:03','2024-05-16 07:51:03'),
(19,2,'MAHINDRA ','2024-05-16 07:51:28','2024-05-16 07:51:28'),
(20,2,'MERCEDES-BENZ','2024-05-16 07:51:50','2024-05-16 07:51:50'),
(21,2,'MITSUBISHI','2024-05-16 07:52:27','2024-05-16 07:52:27'),
(22,2,'MORRIS GARAGE','2024-05-16 07:53:44','2024-05-16 07:53:44'),
(23,2,'NISSAN','2024-05-16 07:54:32','2024-05-16 07:54:32'),
(24,2,'OPEL','2024-05-16 07:54:47','2024-05-16 07:54:47'),
(25,2,'RENAULT','2024-05-16 07:55:24','2024-05-16 07:55:24'),
(26,2,'SSANGYONG','2024-05-16 07:58:07','2024-05-16 07:58:07'),
(27,2,'TATA','2024-05-16 07:58:40','2024-05-16 07:58:40'),
(28,2,'TOYOTA','2024-05-16 07:59:04','2024-05-16 07:59:04'),
(29,2,'VOLKSWAGEN','2024-05-16 07:59:24','2024-05-16 07:59:24'),
(30,2,'VOLVO','2024-05-16 07:59:42','2024-05-16 07:59:42'),
(31,2,'ASTON MARTIN','2024-05-16 08:05:56','2024-05-16 08:05:56'),
(32,2,'BENTLEY','2024-05-16 08:06:07','2024-05-16 08:06:07'),
(33,2,'BUGATTI','2024-05-16 08:06:18','2024-05-16 08:06:18'),
(34,2,'LAND ROVER','2024-05-16 08:07:01','2024-05-16 08:07:01'),
(35,2,'HINDUSTAN','2024-05-16 08:09:02','2024-05-16 08:09:02'),
(38,15,'APRILIA ','2024-07-24 18:21:24','2024-07-24 18:21:24'),
(39,15,'BAJAJ','2024-07-24 18:21:49','2024-07-24 18:21:49'),
(40,15,'BENELLI','2024-07-24 18:22:14','2024-07-24 18:22:14'),
(41,15,'BMW','2024-07-24 18:22:45','2024-07-24 18:22:45'),
(42,15,'DUCATI','2024-07-24 18:23:07','2024-07-24 18:23:07'),
(43,15,'HARLEY DAVIDSON','2024-07-24 18:24:08','2024-07-24 18:24:08'),
(44,15,'HERO','2024-07-24 18:24:39','2024-07-24 18:24:39'),
(45,15,'HONDA','2024-07-24 18:24:45','2024-07-24 18:24:45'),
(46,15,'INDIAN','2024-07-24 18:25:45','2024-07-24 18:25:45'),
(47,15,'JAWA','2024-07-24 18:25:59','2024-07-24 18:25:59'),
(48,15,'KAWASAKI','2024-07-24 18:27:01','2024-07-24 18:27:01'),
(49,15,'KTM','2024-07-24 18:28:48','2024-07-24 18:28:48'),
(50,15,'ROYAL ENFIELD','2024-07-24 18:33:29','2024-07-24 18:33:29'),
(51,15,'SUZUKI ','2024-07-24 18:34:30','2024-07-24 18:34:30'),
(52,15,'TRIUMPH','2024-07-24 18:34:56','2024-07-24 18:34:56'),
(53,15,'TVS','2024-07-24 18:35:14','2024-07-24 18:35:14'),
(54,15,'YAMAHA','2024-07-24 18:35:33','2024-07-24 18:35:33'),
(55,15,'YEZDI ','2024-07-24 18:36:13','2024-07-24 18:36:13');
/*!40000 ALTER TABLE `tbl_car_brand` ENABLE KEYS */;

--
-- Table structure for table `tbl_car_detail`
--

DROP TABLE IF EXISTS `tbl_car_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `model` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `brand` varchar(200) NOT NULL,
  `inspectionType` varchar(100) NOT NULL,
  `doc` varchar(100) NOT NULL,
  `carQuality` varchar(100) NOT NULL,
  `carCondition` varchar(100) NOT NULL,
  `assignDriverId` int(11) NOT NULL,
  `assignSecondDriverId` int(11) NOT NULL,
  `secondDriverAssignFlag` tinyint(4) NOT NULL,
  `status` varchar(100) NOT NULL,
  `pickup_images_verified` tinyint(4) NOT NULL DEFAULT 0,
  `drop_images_verified` tinyint(4) NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `driverOneStatus` varchar(200) NOT NULL,
  `driverTwoStatus` varchar(200) NOT NULL,
  `pickup_images_verified2` tinyint(4) NOT NULL,
  `drop_images_verified2` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_car_detail`
--

/*!40000 ALTER TABLE `tbl_car_detail` DISABLE KEYS */;
INSERT INTO `tbl_car_detail` VALUES
(1,1,'ALTO LXI','Car','MARUTI SUZUKI','null','temp_17505177269693164601428909960182.jpg','Used Car','Running',2,3,1,'',1,1,'2025-06-21 14:56:01','ONGOING','ASSIGNED',1,1),
(2,1,'LINEA','Car','FIAT','null','temp_17505177409923823336163879248554.jpg','Used Car','Scrap',0,0,0,'',0,0,'2025-06-21 14:56:01','','',0,0),
(3,2,'UNO','Car','FIAT','Pre Delivery','temp_1750584135564256091831002562.jpg','New Car','null',7,0,0,'',0,0,'2025-06-22 09:22:21','','',0,0),
(4,3,'Redi-Go','Car','DATSUN','null','','null','null',0,0,0,'',0,0,'2025-06-22 12:20:59','','',0,0),
(5,4,'Ecosport','Car','FORD','null','','null','null',0,0,0,'',0,0,'2025-06-22 13:02:12','','',0,0),
(6,5,'GETZ','Car','HYUNDAI','null','','Used Car','Running',0,0,0,'',0,0,'2025-06-25 15:35:39','','',0,0),
(7,8,'SIENA WEEKEND','Car','FIAT','null','temp_17509204129755296020258087806100.jpg','Used Car','Running',2,7,1,'',1,1,'2025-06-26 06:47:11','COMPLETED','ONGOING',1,1),
(8,8,'YETI','Car','SKODA','null','temp_175092042515352986687727627795.jpg','New Car','Running',0,0,0,'',0,0,'2025-06-26 06:47:11','','',0,0),
(9,9,'ALTO 800','Car','MARUTI SUZUKI','General Inspection','temp_17509499719141895168234707367375.jpg','New Car','null',2,0,0,'',0,0,'2025-06-26 14:59:38','','',0,0),
(10,10,'A STAR','Car','MARUTI SUZUKI','null','temp_17509520991075973579201764296231.jpg','Used Car','Running',0,0,0,'',0,0,'2025-06-26 15:35:16','','',0,0),
(11,11,'A STAR','Car','MARUTI SUZUKI','null','','Used Car','Running',0,0,0,'',0,0,'2025-06-26 15:53:50','','',0,0),
(12,12,'ALTO LXI','Car','MARUTI SUZUKI','null','temp_17509591029009052134859624223308.jpg','Used Car','Running',0,0,0,'',0,0,'2025-06-26 17:31:51','','',0,0),
(13,13,'XUV400','Car','MAHINDRA ','null','','Used Car','Running',8,8,1,'',1,1,'2025-06-27 06:30:05','COMPLETED','ASSIGNED',0,0),
(14,14,'WAGON R 1.0','Car','MARUTI SUZUKI','null','','Used Car','Running',9,7,1,'',1,1,'2025-06-27 14:06:38','COMPLETED','ASSIGNED',0,0),
(15,17,'GETZ PRIME','Car','HYUNDAI','null','temp_17512147471495075879853845346801.jpg','Used Car','Running',0,0,0,'',0,0,'2025-06-29 16:32:54','','',0,0),
(16,23,'ALTO LXI','Car','MARUTI SUZUKI','null','','Used Car','Running',9,10,1,'',1,1,'2025-06-30 18:54:23','COMPLETED','COMPLETED',1,1),
(17,24,'SWIFT DZIRE','Car','MARUTI SUZUKI','null','temp_17513402421171905598360845206908.jpg','Used Car','Running',0,0,0,'',0,0,'2025-07-01 03:24:13','','',0,0);
/*!40000 ALTER TABLE `tbl_car_detail` ENABLE KEYS */;

--
-- Table structure for table `tbl_car_drop_images`
--

DROP TABLE IF EXISTS `tbl_car_drop_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_drop_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driverId` int(11) NOT NULL,
  `carId` int(11) NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `is_verified` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_car_drop_images`
--

/*!40000 ALTER TABLE `tbl_car_drop_images` DISABLE KEYS */;
INSERT INTO `tbl_car_drop_images` VALUES
(1,2,1,'temp6642962970346238335.jpg',1,'2025-06-21 14:59:04'),
(2,2,1,'temp757546933315972555.jpg',1,'2025-06-21 14:59:04'),
(3,3,1,'temp167669871600295102.jpg',1,'2025-06-24 15:20:43'),
(4,3,1,'temp2716956101460041011.jpg',1,'2025-06-24 15:20:43'),
(5,3,1,'temp3771494279290792102.jpg',1,'2025-06-24 15:20:43'),
(6,3,1,'temp1883597982492184282.jpg',1,'2025-06-24 15:20:43'),
(7,3,1,'temp1375966123687532717.jpg',1,'2025-06-24 15:20:43'),
(8,3,1,'temp7651027006228603199.jpg',1,'2025-06-24 15:20:43'),
(9,2,7,'temp7170711911477663421.jpg',1,'2025-06-26 07:40:07'),
(10,2,7,'temp7188366427337816256.jpg',1,'2025-06-26 07:40:07'),
(11,7,7,'temp7977292228228427227.jpg',1,'2025-06-26 08:25:54'),
(12,7,7,'temp7632286302529658558.jpg',1,'2025-06-26 08:25:54'),
(13,8,13,'temp2905931551633634800.jpg',1,'2025-06-27 14:16:48'),
(14,8,13,'temp8111358638538204475.jpg',1,'2025-06-27 14:16:48'),
(15,8,13,'temp602701165676297561.jpg',1,'2025-06-27 14:16:48'),
(16,8,13,'temp912154839221271216.jpg',1,'2025-06-27 14:16:48'),
(17,8,13,'temp6566352152833790419.jpg',1,'2025-06-27 14:16:48'),
(18,8,13,'temp7584571878507099585.jpg',1,'2025-06-27 14:16:48'),
(19,8,13,'temp4502412172329104714.jpg',1,'2025-06-27 14:16:48'),
(20,9,14,'temp5258750083268077944.jpg',1,'2025-06-27 14:20:32'),
(21,9,14,'temp6472383254634354500.jpg',1,'2025-06-27 14:20:33'),
(22,9,14,'temp6005666400852770602.jpg',1,'2025-06-27 14:20:33'),
(23,9,14,'temp2720990516019423892.jpg',1,'2025-06-27 14:20:33'),
(24,9,14,'temp1177082467169028775.jpg',1,'2025-06-27 14:20:33'),
(25,9,14,'temp7024903508908608642.jpg',1,'2025-06-27 14:20:33'),
(26,9,14,'temp4529038838211025046.jpg',1,'2025-06-27 14:20:33'),
(27,9,16,'temp1173080475619165989.jpg',1,'2025-06-30 19:02:33'),
(28,9,16,'temp7487365537758979356.jpg',1,'2025-06-30 19:02:33'),
(29,9,16,'temp756836918747805298.jpg',1,'2025-06-30 19:02:33'),
(30,9,16,'temp7413075778104571795.jpg',1,'2025-06-30 19:02:33'),
(31,9,16,'temp7669517258594793534.jpg',1,'2025-06-30 19:02:33'),
(32,9,16,'temp4378748077978349448.jpg',1,'2025-06-30 19:02:33'),
(33,9,16,'temp7326215364969226385.jpg',1,'2025-06-30 19:02:33'),
(34,9,16,'temp2324369645554564410.jpg',1,'2025-06-30 19:02:33'),
(35,9,16,'temp9021203661828460299.jpg',1,'2025-06-30 19:02:33'),
(36,9,16,'temp3288400262192916711.jpg',1,'2025-06-30 19:02:33'),
(37,9,16,'temp1032718706775833955.jpg',1,'2025-06-30 19:02:33'),
(38,10,16,'temp7463401010066285260.jpg',1,'2025-06-30 19:17:33'),
(39,10,16,'temp1928980420095383454.jpg',1,'2025-06-30 19:17:33'),
(40,10,16,'temp2694468262120807678.jpg',1,'2025-06-30 19:17:33'),
(41,10,16,'temp6168106222671995932.jpg',1,'2025-06-30 19:17:33'),
(42,10,16,'temp6051676864387035645.jpg',1,'2025-06-30 19:17:33'),
(43,10,16,'temp722637208386790853.jpg',1,'2025-06-30 19:17:33'),
(44,10,16,'temp1444478368469156899.jpg',1,'2025-06-30 19:17:33'),
(45,10,16,'temp3223764051106291890.jpg',1,'2025-06-30 19:17:33'),
(46,10,16,'temp1728358265278152765.jpg',1,'2025-06-30 19:17:33'),
(47,10,16,'temp5018656606786992704.jpg',1,'2025-06-30 19:17:34'),
(48,10,16,'temp1106812288134997435.jpg',1,'2025-06-30 19:17:34'),
(49,10,16,'temp1301764925410973196.jpg',1,'2025-06-30 19:17:34');
/*!40000 ALTER TABLE `tbl_car_drop_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_car_model`
--

DROP TABLE IF EXISTS `tbl_car_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `displacement` varchar(64) DEFAULT NULL,
  `emission_norm` varchar(64) DEFAULT NULL,
  `fuel_tank_capacity` varchar(64) DEFAULT NULL,
  `fuel_type` varchar(64) DEFAULT NULL,
  `height` varchar(64) DEFAULT NULL,
  `length` varchar(64) DEFAULT NULL,
  `width` varchar(64) DEFAULT NULL,
  `body_type` varchar(64) DEFAULT NULL,
  `kerb_weight` varchar(64) DEFAULT NULL,
  `gears` varchar(64) DEFAULT NULL,
  `ground_clearance` varchar(64) DEFAULT NULL,
  `front_brakes` varchar(64) DEFAULT NULL,
  `rear_brakes` varchar(64) DEFAULT NULL,
  `power_windows` varchar(64) DEFAULT NULL,
  `power_seats` varchar(64) DEFAULT NULL,
  `power` varchar(64) DEFAULT NULL,
  `torque` varchar(64) DEFAULT NULL,
  `odometer` varchar(64) DEFAULT NULL,
  `speedometer` varchar(64) DEFAULT NULL,
  `seating_capacity` varchar(64) DEFAULT NULL,
  `seats_material` varchar(64) DEFAULT NULL,
  `transmission` varchar(64) DEFAULT NULL,
  `central_locking` varchar(64) DEFAULT NULL,
  `child_safety_locks` varchar(64) DEFAULT NULL,
  `abs` varchar(64) DEFAULT NULL,
  `ventilation_system` varchar(64) DEFAULT NULL,
  `created` varchar(64) DEFAULT NULL,
  `updated` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_car_model`
--

/*!40000 ALTER TABLE `tbl_car_model` DISABLE KEYS */;
INSERT INTO `tbl_car_model` VALUES
(4,6,'FABIA','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11-05-24 9:47','13-05-24 4:52'),
(5,22,'GLOSTER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:46','16-05-24 9:20'),
(6,6,'OPTRA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:46','16-05-24 7:46'),
(7,6,'OPTRA MAGNUM','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:46','16-05-24 7:46'),
(8,6,'OPTRA SRV','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:46','16-05-24 7:46'),
(10,6,'LAURA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:47','16-05-24 7:47'),
(11,7,'EON','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:47','16-05-24 7:47'),
(15,6,'OCTAVIA COMBI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(16,7,'I10','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(17,6,'YETI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(18,7,'ELITE I10','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(19,6,'FABIA CLASSIC','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(20,7,'GETZ','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(21,6,'KUSHAQ','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(22,7,'GETZ PRIME','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:49','16-05-24 7:49'),
(23,7,'I20','1393 CC','BS IV','45 Litre','Petrol','1505 mm','3995 mm','1710 mm','Hatchback','1240 kg','5','165 mm','Disc','Drum','No','No','82.85bhp@6000rpm','113.7Nm@4000rpm','Digital','Analogue','5','Fabric','Manual ','Yes','No','Yes','Blower, Vents Behind Front Armrest, Automatic climate control - ','16-05-24 7:49','16-05-24 7:49'),
(24,8,'800','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:50','16-05-24 7:50'),
(26,8,'800 CAR STD MPI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:50','16-05-24 7:50'),
(28,8,'A STAR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:50','16-05-24 7:50'),
(29,7,'SANTRO XING','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:50','16-05-24 7:50'),
(31,7,'ACCENT','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:50','16-05-24 7:50'),
(32,8,'ALTO 800','796 CC','BS VI 2.0','60 litre','Petrol + CNG','1475 mm','3445 mm','1515 mm','Hatchback','850 kg','5','160 mm','Disc','Drum','Front only ','No','40.36bhp@6000rpm','60Nm@3500rpm','Digital','Analogue ','4','Fabric','Manual','No','Yes','Yes','Manual AC working ','16-05-24 7:50','16-05-24 7:50'),
(33,7,'ACCENT EXECUTIVE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:50','16-05-24 7:50'),
(36,8,'ALTO LXI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:51','16-05-24 7:51'),
(40,8,'ZEN','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:51','16-05-24 7:51'),
(41,8,'ZEN ESTILO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:51','16-05-24 7:51'),
(42,8,'ZEN ESTILO VXI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(43,7,'ACCENT VIVA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(44,8,'Wagnor LXI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(45,7,'NEW ELANTRA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(46,8,'WAGONR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(48,8,'RITZ','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(51,8,'WAGON R 1.0','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(52,7,'SANTA FE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(53,8,'WAGON R DUO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:52','16-05-24 7:52'),
(55,8,'WAGON R STINGRAY','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:53','16-05-24 7:53'),
(56,7,'I10 Magna','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:53','16-05-24 7:53'),
(57,8,'1000','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:53','16-05-24 7:53'),
(61,8,'SWIFT DZIRE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:54','16-05-24 7:54'),
(62,8,'SX4','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:54','16-05-24 7:54'),
(63,7,'EXTER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:54','16-05-24 7:54'),
(66,7,'ALCAZAR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:54','16-05-24 7:54'),
(67,8,'VERSA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:54','16-05-24 7:54'),
(70,8,'KIZASHI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:55','16-05-24 7:55'),
(71,8,'S CROSS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:56','16-05-24 7:56'),
(73,8,'GRAND VITARA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:56','16-05-24 7:56'),
(75,8,'FORNX','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:56','16-05-24 7:56'),
(76,8,'JIMMY','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:56','16-05-24 7:56'),
(80,9,'500','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 7:58','16-05-24 7:58'),
(81,9,'GRAND PUNTO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:07','16-05-24 8:07'),
(82,9,'PALIO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:08','16-05-24 8:08'),
(83,9,'PUNTO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:08','16-05-24 8:08'),
(84,9,'UNO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:08','16-05-24 8:08'),
(85,9,'LINEA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:12','16-05-24 8:12'),
(86,9,'SIENA WEEKEND','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:12','16-05-24 8:12'),
(87,9,'PADMINI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:12','16-05-24 8:12'),
(88,9,'PETRA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:12','16-05-24 8:12'),
(89,9,'SIENA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:12','16-05-24 8:12'),
(90,9,'ADVENTURE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:12','16-05-24 8:12'),
(94,10,'A7','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:13','16-05-24 8:13'),
(95,10,'A8','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:13','16-05-24 8:13'),
(101,11,'1 SERIES','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:47','16-05-24 8:48'),
(102,11,'520 D','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:47','16-05-24 8:49'),
(103,11,'M3','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:47','16-05-24 8:49'),
(105,11,'M6','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:49','16-05-24 8:49'),
(107,11,'Z4','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:50','16-05-24 8:50'),
(108,11,'3 SERIES','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:50','16-05-24 8:50'),
(109,11,'5 SERIES','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:50','16-05-24 8:50'),
(110,11,'599 GTB','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:50','16-05-24 8:50'),
(111,11,'6 SERIES','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:50','16-05-24 8:50'),
(112,11,'7 SERIES','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:51','16-05-24 8:51'),
(114,11,'X6','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:51','16-05-24 8:51'),
(115,12,'BEAT','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(116,12,'SPARK','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(117,12,'AVEO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(118,12,'SAIL','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(119,12,'CRUZE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(120,12,'CAPTIVA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(121,12,'ENJOY','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:52','16-05-24 8:52'),
(122,12,'TAVERA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:53','16-05-24 8:53'),
(123,13,'DATSUN','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:57','16-05-24 8:57'),
(124,13,'REDI GO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 8:57','16-05-24 8:57'),
(125,15,'BRIO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:00','16-05-24 9:02'),
(126,15,'ACCORD','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:00','16-05-24 9:04'),
(128,15,'JAZZ ','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:02','16-05-24 9:02'),
(132,15,'CRV','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:04','16-05-24 9:04'),
(133,15,'MOBILIO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:04','16-05-24 9:04'),
(134,15,'BR-V','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:04','16-05-24 9:04'),
(135,14,'ESCORT','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:05','16-05-24 9:05'),
(137,14,'FIESTA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:05','16-05-24 9:05'),
(138,15,'ELEVATE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:05','16-05-24 9:05'),
(140,14,'FUSION','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:05','16-05-24 9:05'),
(141,14,'IKON','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:05','16-05-24 9:05'),
(146,14,'TOUAREG','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:06','16-05-24 9:06'),
(147,16,'XJL','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:06','16-05-24 9:06'),
(149,16,'XK','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:06','16-05-24 9:06'),
(151,17,'Jeep COMPASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:07','16-05-24 9:07'),
(153,18,'SONET','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:07','16-05-24 9:07'),
(154,18,'CARNES','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:07','16-05-24 9:07'),
(155,19,'REVA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:08','16-05-24 9:08'),
(156,19,'E 20','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:08','16-05-24 9:08'),
(157,19,'LOGAN','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:08','16-05-24 9:08'),
(158,19,'KUV100','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:08','16-05-24 9:08'),
(159,21,'CEDIA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(160,19,'QUANTO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(161,21,'LANCER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(162,21,'FREELANDER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(163,19,'TUV','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(164,21,'OUTLANDER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(166,21,'PAJERO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:09','16-05-24 9:09'),
(168,19,'ARMADA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:10','16-05-24 9:10'),
(170,19,'Jeep','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:10','16-05-24 9:10'),
(171,19,'Jeep Classic','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:11','16-05-24 9:11'),
(172,19,'open jeep','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:11','16-05-24 9:11'),
(177,19,'XUV700','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:12','16-05-24 9:12'),
(179,19,'SCORPIO N','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:13','16-05-24 9:13'),
(180,19,'BOLERO NEO N8','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:13','16-05-24 9:13'),
(181,19,'XUV400','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:13','16-05-24 9:13'),
(182,20,'SDL','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:14','16-05-24 9:14'),
(183,20,'VIANO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:14','16-05-24 9:14'),
(184,20,'GLA 200','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:15','16-05-24 9:15'),
(185,20,'R CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:15','16-05-24 9:15'),
(186,20,'A CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:15','16-05-24 9:15'),
(187,20,'B CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:15','16-05-24 9:15'),
(188,20,'C 220','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:15','16-05-24 9:15'),
(189,20,'C CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:16','16-05-24 9:16'),
(190,20,'CLA CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:16','16-05-24 9:16'),
(191,20,'E CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:16','16-05-24 9:16'),
(192,20,'G CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:16','16-05-24 9:16'),
(193,20,'GL CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:16','16-05-24 9:16'),
(194,20,'GLA CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:17','16-05-24 9:17'),
(195,20,'MAYBACH S CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:17','16-05-24 9:17'),
(196,20,'ML CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:17','16-05-24 9:17'),
(197,20,'S CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:17','16-05-24 9:17'),
(198,20,'SL CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:17','16-05-24 9:17'),
(199,20,'SLK CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:18','16-05-24 9:18'),
(200,20,'SLS CLASS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:18','16-05-24 9:18'),
(201,20,'E250','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:18','16-05-24 9:18'),
(202,22,'ASTOR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:19','16-05-24 9:19'),
(203,22,'HECTOR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:19','16-05-24 9:19'),
(204,22,'HECTOR PLUS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:22','16-05-24 9:22'),
(207,23,'X TRAIL','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:23','16-05-24 9:23'),
(208,23,'EVALIA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:23','16-05-24 9:23'),
(209,23,'TEANA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:23','16-05-24 9:23'),
(210,23,'TERRACAN','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:23','16-05-24 9:23'),
(212,23,'TRAILBLAZER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:24','16-05-24 9:24'),
(214,24,'CORSA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:40','16-05-24 9:40'),
(215,24,'ASTRA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:40','16-05-24 9:40'),
(217,25,'PULSE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:41','16-05-24 9:41'),
(218,25,'SCALA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:41','16-05-24 9:41'),
(220,25,'FLUENCE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:41','16-05-24 9:41'),
(222,25,'KOLEOS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:42','16-05-24 9:42'),
(223,26,'REXTON','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:42','16-05-24 9:42'),
(224,28,'COROLLA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:43','16-05-24 9:43'),
(225,28,'ETIOS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:43','16-05-24 9:43'),
(226,27,'NANO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:44','16-05-24 9:44'),
(227,28,'ALTIS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:44','16-05-24 9:44'),
(228,27,'INDICA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:44','16-05-24 9:44'),
(230,27,'INDICA VISTA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:44','16-05-24 9:44'),
(233,28,'INNOVA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:45','16-05-24 9:45'),
(234,27,'VENTURE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:45','16-05-24 9:45'),
(239,28,'PRADO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:45','16-05-24 9:45'),
(240,27,'INDIGO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:45','16-05-24 9:45'),
(241,28,'QUALIS','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:46','16-05-24 9:46'),
(242,27,'MANZA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:46','16-05-24 9:46'),
(244,27,'ARIA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:46','16-05-24 9:46'),
(245,27,'SAFARI','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:46','16-05-24 9:46'),
(247,29,'CROSS POLO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:47','16-05-24 9:47'),
(248,27,'SIERRA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:47','16-05-24 9:47'),
(250,27,'SUMO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:47','16-05-24 9:47'),
(252,27,'SUMO GOLD','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:48','16-05-24 9:48'),
(253,27,'SUMO GRANDE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:48','16-05-24 9:48'),
(255,29,'VELTO','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:48','16-05-24 9:48'),
(257,29,'JETTA','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:48','16-05-24 9:48'),
(260,27,'XENON XT','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:49','16-05-24 9:49'),
(263,29,'BEETLE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:49','16-05-24 9:49'),
(264,27,'PUNCH ','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:49','16-05-24 9:49'),
(267,30,'S6','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:50','16-05-24 9:50'),
(270,30,'S80','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:50','16-05-24 9:50'),
(271,31,'RAPIDE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:51','16-05-24 9:51'),
(272,31,'V12 VANTAGE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:51','16-05-24 9:51'),
(273,31,'V8 VANTAGE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:51','16-05-24 9:51'),
(274,32,'FLYING SPUR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:52','16-05-24 9:52'),
(275,33,'VEYRON','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:52','16-05-24 9:52'),
(277,34,'DISCOVERY 4','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:53','16-05-24 9:53'),
(278,34,'RANGE ROVER','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:53','16-05-24 9:53'),
(279,35,'AMBASSADOR','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:53','16-05-24 9:53'),
(280,34,'RANGE ROVER EVOGUE','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:53','16-05-24 9:53'),
(281,34,'RANGE ROVER SPORT','','','','','','','','','','','','','','','','','','','','','','','','','','','16-05-24 9:54','16-05-24 9:54'),
(282,27,'Nano Genx','624 cc','BS IV','24 litres','Petrol','1652 mm','3164 mm','1750 mm','Hatchback','660 kg','4','180 mm','Drum','Drum','Only Front Windows','NA','38PS@5500rpm','51Nm@4000rpm','Digital','Analog','4','Fabric','Manual','Yes','Yes','No','Manual Air conditioning with cooling and heating','',''),
(288,13,'Redi-Go','799 cc','BS IV','28 litres','Petrol','1541 mm','3429 mm','1560 mm','Hatchback','','5','185 mm','Ventilated Disc','Drum','','','54PS@5678rpm','72Nm@4386rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Yes','',''),
(294,25,'Kwid','799 cc','BS 6','28 litres','Petrol','1490 mm','3731 mm','1579 mm','Hatchback','669 kg','6','184 mm','Ventilated Disc','Drum','','','54PS@5678rpm','72Nm@4386rpm','Digital','Digital','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(306,8,'Eeco','1196 cc','BS 6','40 litres','Petrol','1800 mm','3675 mm','1475 mm','MPV','920 kg','5','160 mm','Ventilated Disc','Drum','','','73PS@6000rpm','101Nm@3000rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','','',''),
(311,8,'Alto K10','998 cc','BS IV','35 litres','Petrol','1475 mm','3545 mm','1490 mm','Hatchback','745 kg','5','160 mm','Ventilated Disc','Drum','','','68PS@6000rpm','90Nm@3500rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(317,13,'Go','1198 cc','BS IV','35 litres','Petrol','1507 mm','3788 mm','1636 mm','Hatchback','864 kg','5','180 mm','Ventilated Disc','Drum','Only Front Windows','','68PS@5000rpm','104Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Heater','',''),
(326,8,'Celerio Tour','998 cc','BS IV','35 litres','Petrol','1560 mm','3600 mm','1600 mm','Hatchback','830 kg','5','165 mm','Ventilated Disc','Drum','','','68PS@6000rpm','90Nm@3500rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(328,7,'Santro','1086 cc','BS IV','35 litres','Petrol','1560 mm','3610 mm','1645 mm','Hatchback','','5','','','','Only Front Windows','','69PS@5500rpm','99.04nm@4500RPM','Analog','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(336,27,'Tiago','1199 cc','BS 6','35 litres','Petrol','1535 mm','3765 mm','1677 mm','Hatchback','935 kg','5','','Ventilated Disc','Drum','','','86PS@6000rpm','114NM@3300rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(344,8,'Celerio X','998 cc','BS IV','35 litres','Petrol','1560 mm','3600 mm','1600 mm','Hatchback','810 kg','5','165 mm','Ventilated Disc','Drum','All Windows','','68PS@6000rpm','90Nm@3500rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(352,8,'Ignis','1197 cc','BS IV','32 litres','Petrol','1595 mm','3700 mm','1690 mm','Hatchback','860 kg','','180 mm','Ventilated Disc','Drum','All Windows','','83PS@6000rpm','113Nm@4200RPM','Analog','Analog','5','Fabric','AMT','Yes','Yes','Yes','Heater, Fully automatic climate control','',''),
(359,25,'Triber','999 cc','BS 6','40 litres','Petrol','1643 mm','3990 mm','1739 mm','MUV','947 kg','5','182 mm','Ventilated Disc','Drum','Only Front Windows','','72PS@62050rpm','96Nm@3500rpm','Digital','Analog, Digital','7','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(363,28,'Etios Liva','1197 cc','BS IV','45 litres','Petrol','1510 mm','3884 mm','1695 mm','Hatchback','895 kg','5','170 mm','Ventilated Disc','Drum','All Windows','','80PS@5600rpm','104Nm@3100rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(377,23,'Micra Active','1198 cc','BS IV','41 litres','Petrol','1530 mm','3801 mm','1665 mm','Hatchback','','5','154 mm','Ventilated Disc','Drum','Only Front Windows','','68PS@5000rpm','104Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(380,27,'Bolt','1248 cc','BS IV','44 litres','Diesel','1562 mm','3825 mm','1695 mm','Hatchback','1132 kg','5','165 mm','Solid Disc','Drum','All Windows','','75PS@4000rpm','190Nm@1750-3000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(388,7,'Xcent Prime','1197 cc','BS IV','43 litres','CNG + Petrol','1520 mm','3995 mm','1660 mm','Sedan','1100 kg','5','165 mm','Ventilated Disc','Drum','Only Front Windows','','83PS@6000rpm','114Nm@6000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(394,8,'Dzire Tour','1248 cc','BS IV','42 litres','Diesel','1555 mm','3995 mm','1695 mm','Sedan','1045 kg','','170 mm','Ventilated Disc','Drum','Only Front Windows','','75PS@4000rpm','190Nm@2000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(397,7,'Elite I20','1197 cc','BS IV','45 litres','Petrol','1505 mm','3995 mm','1710 mm','Hatchback','1066 kg','5','165 mm','Ventilated Disc','Drum','Only Front Windows','','84PS@6000rpm','115Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(409,7,'Aura','1197 cc','BS 6','37 litres','Petrol','1520 mm','3995 mm','1680 mm','Sedan','','5','','Ventilated Disc','Drum','Only Front Windows','','83PS@6000rpm','114Nm@4000rpm','Digital','','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(421,29,'Polo','999 cc','BS IV','45 litres','Petrol','1469 mm','3971 mm','1682 mm','Hatchback','1033 kg','5','165 mm','Ventilated Disc','Drum','Only Front Windows','','76PS@6200RPM','95Nm@3000-4300rpm','Digital','Analog','5','Polyurethene','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(429,8,'Dzire','1197 cc','BS IV','37 litres','Petrol','1515 mm','3995 mm','1735 mm','Sedan','860 kg','5','163 mm','Ventilated Disc','Drum','','','84.3PS@6000rpm','115Nm@4000rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(443,14,'Freestyle','1498 cc','BS IV','40 litres','Diesel','1570 mm','3954 mm','1737 mm','Crossover','1062 kg','5','190 mm','Ventilated Disc','Drum','Only Front Windows','','100PS@3750RPM','215Nm@1750-3000RPM','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(451,29,'Ameo','1498 cc','BS IV','45 litres','Diesel','1483 mm','3995 mm','1682 mm','Sedan','1044 kg','','165 mm','Ventilated Disc','Drum','Only Front Windows','','110PS@4400rpm','250Nm@1500-2500rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Air Conditioning with cooling only','',''),
(459,14,'Aspire','1194 cc','BS IV','42 litres','Petrol','1525 mm','3995 mm','1704 mm','Sedan','1016-1043 kg','5','','Ventilated Disc','Drum','Only Front Windows','','96PS@6500rpm','120Nm@4250rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(472,28,'Platinum Etios','1496 cc','BS IV','45 litres','Petrol','1510 mm','4369 mm','1695 mm','Sedan','935 kg','5','170 mm','Ventilated Disc','Drum','All Windows','','90PS@5600rpm','132Nm@3000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(482,28,'Etios Cross','1496 cc','BS IV','45 litres','Petrol','1555 mm','3895 mm','1735 mm','Hatchback','950 kg','5','174 mm','Ventilated Disc','Drum','All Windows','','90PS@5600rpm','132Nm@3000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(488,19,'Verito Vibe','1461 cc','BS IV','50 litres','Diesel','1540 mm','3991 mm','1740 mm','Hatchback','1155 kg','5','172 mm','Solid Disc','Drum','','','65PS@4000rpm','160Nm@2000rpm','Digital','Analog','5','Fabric','Manual','','Yes','','Manual Air conditioning with cooling and heating','',''),
(491,28,'Glanza','1197 cc','BS 6','37 litres','Petrol','1540 mm','3995 mm','1745 mm','Hatchback','910 kg','5','','Ventilated Disc','Drum','All Windows','Yes','89PS@6000 rpm','113Nm@4400 rpm','Digital','Analog, Digital','5','Fabric','Manual','Yes','Yes','Yes','2 Zone Climate Control','',''),
(496,15,'Jazz','1199 cc','BS IV','40 litres','Petrol','1544 mm','3955 mm','1694 mm','Hatchback','1042 kg','5','165 mm','Ventilated Disc','Drum','All Windows','','90PS@6000rpm','110Nm@4800rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(504,19,'Bolero Power Plus','1493 cc','BS IV','60 litres','Diesel','1880 mm','3995 mm','1745 mm','SUV','1615 kg','5','180 mm','Ventilated Disc','Drum','All Windows','','70ps@3600rpm','195Nm@1400-2200rpm','Digital','Digital','7','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(510,8,'VITARA BREZZA VDI','1248 cc','BS IV','48 litres','Diesel','1640 mm','3995 mm','1790 mm','SUV','1170 kg','5','198 mm','Ventilated Disc','Drum','Front & Rear Window','NA','89bhp@4000rpm','200Nm@1750rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(519,7,'I20 Active','1197 cc','BS IV','40 litres','Petrol','1555 mm','3995 mm','1760 mm','Hatchback','','5','190 mm','Ventilated Disc','Drum','All Windows','','83PS@6000rpm','114Nm@4000rpm','Digital','Analog, Digital','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(523,14,'Ecosport','1497 cc','BS 6','52 litres','Petrol','1647 mm','3998 mm','1765 mm','SUV','1220 kg','5','200 mm','Ventilated Disc','Drum','All Windows','','123PS@6500rpm','150Nm@4500rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(535,25,'Duster','1498 cc','BS IV','50 litres','Petrol','1695 mm','4315 mm','1822 mm','SUV','1296 kg','5','205 mm','Ventilated Disc','Drum','All Windows','','106PS@5600rpm','142Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(544,7,'Verna','1591 cc','BS IV','45 litres','Petrol','1445 mm','4440 mm','1729 mm','Sedan','','5','165 mm','Ventilated Disc','Drum','All Windows','','123PS@6400rpm','151Nm@4850rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(557,19,'Xuv300','1197 cc','BS 6','42 litres','Petrol','1617 mm','3995 mm','1821 mm','SUV','','6','180 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','','109bhp@5000RPM','200Nm@2000rpm','Yes','Yes','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(568,25,'Lodgy','1461 cc','BS IV','50 litres','Diesel','1697 mm','4498 mm','1751 mm','MUV','1299 kg','5','174 mm','Ventilated Disc','Drum','','','85PS@3750rpm','200Nm@1900rpm','Digital','Analog','8','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(586,29,'Vento','1197 cc','BS IV','45 litres','Petrol','1469 mm','3971 mm','1682 mm','Hatchback','1109 kg','7','165 mm','Ventilated Disc','Drum','All Windows','','105PS@5000rpm','175Nm@1500-4100rpm','Digital','Analog','5','Fabric','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(587,19,'E2O Plus','','BS IV','','Electric','1585 mm','3390 mm','1575 mm','Hatchback','937 kg','','170 mm','Ventilated Disc','Drum','All Windows','','25.8PS@3500rpm','70Nm@1000rpm','Analog','Digital','4','Vinyl','Automatic','','Yes','','Manual Air conditioning with cooling and heating','',''),
(591,27,'Tigor Ev','','BS VI','35 litres','Electric','1537 mm','3992 mm','1677 mm','Sedan','','NA','165 mm','Ventilated Disc','Drum','Only Front Windows','','41.5PS@4500rpm','105Nm@2500RPM','Digital','Yes','5','Fabric','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(592,15,'Brv','1497 cc','BS IV','42 litres','Petrol','1666 mm','4453 mm','1735 mm','SUV','1199 kg','7','210 mm','Ventilated Disc','Drum','Only Front Windows','','119PS@6600rpm','145Nm@4600rpm','Digital','Analog','7','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(600,19,'Thar','2498 cc','BS IV','60 litres','Diesel','1930 mm','3920 mm','1726 mm','SUV','1750 kg','5','200 mm','Ventilated Disc','Drum','','','105 Bhp@ 3800 rpm','247Nm@1800-2000rpm','','Analog','6','Fabric','Manual','','','','Manual Air conditioning with cooling and heating','',''),
(603,0,'Gurkha','2596 cc','BS IV','63 litres','Diesel','2055 mm','4342 mm','1790 mm','SUV','','6','190 mm','Ventilated Disc','Drum','Only Front Windows','','85PS@3200rpm','230Nm@1400-2400rpm','Digital','Analog','7','Fabric','Manual','','Yes','','','',''),
(609,8,'Xl6','1462 cc','BS 6','45 litres','Petrol','1700 mm','4445 mm','1775 mm','MPV','1180 kg','5','','Ventilated Disc','Drum','All Windows','','104PS@6000rpm','138Nm@4400rpm','Digital','Analog, Digital','6','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(613,19,'Tuv300 Plus','2179 cc','BS IV','60 litres','Diesel','1812 mm','4400 mm','1835 mm','SUV','','5','','Ventilated Disc','Drum','All Windows','','120PS@4000RPM','280Nm@1800-2800rpm','Digital','Analog','9','Leather','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(623,19,'Marazzo','1497 cc','BS IV','45 litres','Diesel','1774 mm','4585 mm','1866 mm','MPV','','6','','Ventilated Disc','Ventilated Disc','All Windows','','121Bhp@3500rpm','300Nm@1750-2500rpm','Digital','Analog, Digital','8','Leather','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(624,19,'Scorpio','2523 cc','BS IV','60 litres','Diesel','1930 mm','4456 mm','1820 mm','SUV','','5','','Ventilated Disc','Drum','All Windows','','75PS@3200rpm','200Nm@1400-2200rpm','Digital','Analog','9','Vinyl','Manual','Yes','','','Manual Air conditioning with cooling and heating','',''),
(636,6,'Monte Carlo','1598 cc','BS IV','55 litres','Petrol','1466 mm','4413 mm','1699 mm','Sedan','1137 kg','5','163 mm','Ventilated Disc','Drum','All Windows','','105PS@5250rpm','153Nm@3750-3800rpm','Digital','Analog','5','Leather','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(637,19,'Xuv500','2179 cc','BS IV','70 litres','Petrol','1785 mm','4585 mm','1890 mm','SUV','1785 kg','6','200 mm','Ventilated Disc','Ventilated Disc','All Windows','','140PS@4500rpm','320Nm@2000 - 3000rpm','Digital','Analog','7','Fabric','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(651,19,'E Verito','72 cc','','','Electric','1540 mm','4247 mm','1740 mm','Sedan','','','','Ventilated Disc','Drum','All Windows','','41PS@3500RPM','91Nm@3000rpm','Digital','Analog','5','Fabric','Automatic','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(652,27,'Hexa','2179 cc','BS IV','60 litres','Diesel','1791 mm','4788 mm','1903 mm','SUV','2280 kg','6','200 mm','Ventilated Disc','Ventilated Disc','All Windows','','156PS@4000rpm','400Nm@1700-2700rpm','Digital','Analog','7','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(674,28,'Innova Crysta','2393 cc','BS VI','55 litres','Diesel','1795 mm','4735 mm','1830 mm','MUV','1825 kg','5','167 mm','Ventilated Disc','Drum','All Windows','','150PS@3400rpm','343Nm@1400-2800rpm','Digital','Analog','8','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(675,17,'Compass','1368 cc','BS 6','60 litres','Petrol','1640 mm','4395 mm','1818 mm','SUV','1562 kg','','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','162PS@3750rpm','250Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(701,28,'Corolla Altis','1798 cc','BS IV','55 litres','Petrol','1475 mm','4620 mm','1775 mm','Sedan','1310 kg','6','175 mm','Ventilated Disc','Solid Disc','All Windows','Yes','140PS@6400rpm','173Nm@4000rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(702,15,'Civic','1799 cc','BS 6','47 litres','Petrol','1433 mm','4656 mm','1799 mm','Sedan','1268 kg','7','','Ventilated Disc','Solid Disc','All Windows','Yes','141PS@6500rpm','174Nm@4300rpm','Digital','Yes','5','Fabric','Automatic','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(711,18,'Carnival','2199 cc','BS 6','','Diesel','1755 mm','5115 mm','1985 mm','MUV','','8','','Ventilated Disc','Ventilated Disc','All Windows','','200PS@3800rpm','440Nm@1750-2750rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(712,6,'Superb','1798 cc','BS IV','66 litres','Petrol','1483 mm','4861 mm','1864 mm','Sedan','1449 kg','6','164 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','180PS@6200RPM','320Nm@1450-3900rpm','Analog','Analog','5','Leather','Manual','Yes','Yes','Yes','2 Zone Climate Control','',''),
(720,30,'V40','1984 cc','BS IV','60 litres','Diesel','1420 mm','4369 mm','2041 mm','Hatchback','1500 kg','6','133 mm','Ventilated Disc','Drum','All Windows','Yes, with memory','150PS@3500rpm','350Nm@1500-2750rpm','Digital','Digital','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(721,28,'Fortuner','2755 cc','BS IV','80 litres','Diesel','1835 mm','4795 mm','1855 mm','SUV','1970 kg','5','220 mm','Ventilated Disc','Ventilated Disc','All Windows','','177PS@3400rpm','450Nm@1600-2400rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(730,14,'Endeavour','2198 cc','BS IV','80 litres','Diesel','1837 mm','4903 mm','1869 mm','SUV','2238 kg','6','225 mm','Ventilated Disc','Ventilated Disc','All Windows','','160PS@3200rpm','385Nm@1600-2500rpm','Digital','Analog','7','Leather','Manual','Yes','Yes','Yes','Fully automatic climate control, 2 Zone Climate Control','',''),
(731,30,'V40 Cross Country','1984 cc','BS IV','60 litres','Diesel','1458 mm','4370 mm','1783 mm','Hatchback','1607 kg','6','132 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','150PS@3500rpm','350Nm@1500-2750rpm','Digital','Digital','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(734,0,'Cooper 3 Door','1998 cc','BS IV','44 litres','Petrol','1414 mm','3850 mm','1727 mm','Hatchback','1250 kg','6','','Ventilated Disc','Ventilated Disc','Only Front Windows','Power seats','192PS@5000-6000rpm','280NM@1250-4600rpm','Yes','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(735,6,'Kodiaq Scout','1968 cc','BS 6','63 litres','Diesel','1665 mm','4697 mm','1882 mm','SUV','1799 kg','7','188 mm','Ventilated Disc','Ventilated Disc','All Windows','','148 bhp @ 3500 rpm','340 Nm @ 1750 rpm','Analog','Digital','7','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control, 3 Zone climate control','',''),
(736,0,'Countryman','1998 cc','BS IV','47 litres','Petrol','1557 mm','4299 mm','1822 mm','Hatchback','','8','','Solid Disc','Drum','All Windows','Yes','192PS@5500rpm','280Nm@1350rpm','Yes','Yes','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(740,11,'X1','1995 cc','BS IV','51 litres','Diesel','1612 mm','4439 mm','2060 mm','Crossover, SUV','','8','165 mm','Ventilated Disc','Ventilated Disc','All Windows','','190hp@4000rpm','400Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(745,28,'Camry','2487 cc','BS IV','50 litres','Hybrid','1455 mm','4885 mm','1840 mm','Sedan','1665 kg','','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','178PS@5700rpm','221Nm@3600-5200rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(746,30,'S60','1969 cc','BS IV','67 litres','Petrol','1484 mm','4635 mm','2097 mm','Sedan','1661 kg','8','136 mm','Ventilated Disc','Drum','All Windows','','372Ps@5700rpm','470Nm@2100-4800rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(750,11,'3-Series','1998 cc','BS 6','59 litres','Petrol','1429 mm','4633 mm','1811 mm','Sedan','1595 kg','8','157 mm','Ventilated Disc','Ventilated Disc','All Windows','','258PS@500RPM','400NM@1550rpm','Digital','Analog, Digital','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(751,15,'Accord Hybrid','1993 cc','BS IV','60 litres','Hybrid','1464 mm','4933 mm','1849 mm','Sedan','1620 kg','5','155 mm','Ventilated Disc','Solid Disc','All Windows','Yes, with memory','145PS@6200rpm','175Nm@4000rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(752,30,'S60 Cross Country','2400 cc','BS IV','67 litres','Diesel','1539 mm','4637 mm','2097 mm','Sedan, Crossover','1776 kg','6','201 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','190PS@4000rpm','420Nm@1500-3000rpm','Digital','Digital','4','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(753,28,'Prius','1798 cc','BS IV','43 litres','Hybrid','1490 mm','4540 mm','1760 mm','Sedan','','5','165 mm','Ventilated Disc','Solid Disc','All Windows','Yes','98PS@5200rpm','142Nm@3600rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(754,10,'Q5','1968 cc','BS IV','64 litres','Diesel','1608 mm','4388 mm','1831 mm','SUV','1585 kg','7','170 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','190PS@3800-4000rpm','400Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(760,11,'5-Series','1998 cc','BS IV','70 litres','Petrol','1464 mm','4907 mm','1860 mm','Sedan','1705 kg','8','158 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','252PS@5200rpm','350Nm@1450-4800rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(761,10,'A5','1968 cc','BS IV','','Diesel','1386 mm','4733 mm','1843 mm','Sedan','2115 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Power seats','190ps @ 3800-4200rpm','400Nm @1750-3000rpm','Yes','Digital','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(762,16,'F-Pace','1999 cc','BS IV','60 litres','Diesel','1651 mm','4731 mm','2175 mm','SUV','1830 kg','','213 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','180ps@5500rpm','430Nm@1750-2000rpm','Analog','Digital','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(767,11,'6-Series','1995 cc','BS IV','66 litres','Diesel','1538 mm','5091 mm','1902 mm','Sedan','1720 kg','8','138 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','188PS@4000RPM','400NM@1750rpm','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(768,30,'V90 Cross Country','1969 cc','BS IV','60 litres','Diesel','1543 mm','4950 mm','2052 mm','SUV','2962 kg','8','210 mm','Ventilated Disc','Ventilated Disc','All Windows','Power seats','235PS@4250RPM','480Nm@1740RPM','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(769,10,'A5 Cabriolet','1968 cc','BS IV','58 litres','Diesel','1386 mm','4733 mm','1843 mm','Convertible','1875 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Power seats','190ps @ 3800-4200rpm','400Nm @1750-3000rpm','Yes','Digital','4','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(770,0,'Discovery','2993 cc','BS IV','85 litres','Diesel','1846 mm','4988 mm','2200 mm','SUV','','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','258PS@3750rpm','600Nm@2000rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(782,30,'Xc90','1969 cc','BS IV','68 litres','Diesel','1776 mm','4950 mm','2140 mm','SUV','2962 kg','8','218 mm','Ventilated Disc','Ventilated Disc','All Windows','Power seats','235 bhp @ 4250 rpm','480 Nm @ 1750 rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(783,16,'F-Type','5000 cc','','','Petrol','1308 mm','4470 mm','1923 mm','Convertible','','8','','','','','Power seats','495PS@6500RPM','625Nm@2500-5500rpm','','','','','Automatic','','','','','',''),
(793,16,'Xj','2993 cc','BS IV','82 litres','Diesel','1460 mm','5255 mm','1899 mm','Sedan','1860 kg','8','100 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','302bhp@4000RPM','689Nm@1800rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(794,11,'X7','2998 cc','BS 6','80 litres','Petrol','1805 mm','5151 mm','2000 mm','SUV','','8','','Ventilated Disc','Ventilated Disc','All Windows','','335 bhp @ 5500 rpm','450 Nm @ 1500 rpm','Digital','Digital','7','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(796,11,'M4','2979 cc','BS IV','60 litres','Petrol','1383 mm','4671 mm','1870 mm','Coupe','1612 kg','7','121 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','431PS@7300RPM','550Nm@1850-5500rpm','Digital','Analog','4','Leather','Automatic','Yes','','Yes','2 Zone Climate Control','',''),
(797,28,'Land Cruiser','4461 cc','BS IV','93 litres','Diesel','1910 mm','4950 mm','1980 mm','SUV','2740 kg','6','225 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','265PS@3400rpm','650Nm@1600-2600rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(798,11,'M5','4395 cc','BS 6','68 litres','Petrol','1473 mm','4956 mm','1903 mm','Sedan','1950 kg','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes','625PS@6000rpm','750Nm@1800-5860rpm','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(799,10,'Rs7','3993 cc','BS IV','75 litres','Petrol','1419 mm','5012 mm','1911 mm','Sedan, Coupe','1995 kg','8','109 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','560PS@6600RPM','700Nm@1750-5500rpm','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(800,10,'R8','5204 cc','BS IV','75 litres','Petrol','1252 mm','4440 mm','2029 mm','Coupe','1670 kg','7','110 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','','610PS@8250rpm','560Nm@6500rpm','Digital','Analog','2','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(801,0,'Urus','3996 cc','BS IV','75 litres','Petrol','1638 mm','5112 mm','2181 mm','SUV','2200 kg','','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','650PS@6000rpm','850Nm@2250-4500rpm','Yes','Digital','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(802,0,'Portofino','3855 cc','BS IV','92 litres','Petrol','1320 mm','4569 mm','1910 mm','Convertible','1730 kg','7','119 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','560PS@7500rpm','755NM@4750rpm','Digital','Analog','2','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(803,0,'458 Speciale','4497 cc','BS IV','86 litres','Petrol','1203 mm','4571 mm','1951 mm','Coupe','1395 kg','7','113 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','605PS@9000rpm','540Nm@6000rpm','Digital','Analog','2','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(804,0,'Qute (Re60)','216 cc','BS IV','','Petrol','1652 mm','2752 mm','1312 mm','Hatchback','','5','','Drum','Drum','','','13bhp@5500rpm','18.9Nm@4000rpm','Yes','Yes','4','Fabric','Manual','','Yes','','','',''),
(806,8,'Alto','796 cc','BS 6','35 litres','Petrol','1475 mm','3445 mm','1490 mm','Hatchback','730 kg','5','160 mm','Solid Disc','Drum','','','48PS@6000rpm','69Nm@3500rpm','Digital','Analog','5','Fabric','Manual','','Yes','','','',''),
(823,8,'S-Presso','998 cc','BS 6','27 litres','Petrol','1549 mm','3565 mm','1520 mm','Hatchback','726 kg','5','','Ventilated Disc','Drum','All Windows','','67PS@5500rpm','90Nm@3500rpm','Digital','Digital','5','Fabric','AMT','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(824,8,'Celerio','998 cc','BS 6','35 litres','Petrol','1560 mm','3600 mm','1600 mm','Hatchback','810 kg','5','165 mm','Ventilated Disc','Drum','','','68PS@6000rpm','90Nm@3500rpm','Digital','Analog','5','Fabric','Manual','','Yes','','Manual Air conditioning with cooling and heating','',''),
(840,7,'Grand I10 Prime','1197 cc','BS IV','43 litres','CNG','1520 mm','3765 mm','1660 mm','Hatchback','935 kg','5','165 mm','Ventilated Disc','Drum','Only Front Windows','','83PS@6000rpm','114Nm@4000rpm','Digital','Analog','5','Fabric','Manual','','Yes','','Manual Air conditioning with cooling and heating','',''),
(841,19,'Kuv100 Nxt','1198 cc','BS IV','35 litres','Petrol','1655 mm','3700 mm','1735 mm','Hatchback','','5','170 mm','Ventilated Disc','Drum','','','82PS@5500RPM','115NM@3500-3600RPM','Digital','Analog, Digital','6','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(863,8,'Swift','1197 cc','BS 6','37 litres','Petrol','1530 mm','3840 mm','1735 mm','Hatchback','855 kg','5','163 mm','Ventilated Disc','Drum','','','83PS@6000rpm','113Nm@4200RPM','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(877,27,'Altroz','1199 cc','BS 6','37 litres','Petrol','1523 mm','3990 mm','1755 mm','Hatchback','','5','165 mm','Ventilated Disc','Drum','Only Front Windows','','86PS@6000rpm','113Nm@3300rpm','Digital','Analog, Digital','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(892,27,'Tigor','1199 cc','BS 6','35 litres','Petrol','1537 mm','3992 mm','1677 mm','Sedan','992 kg','5','170 mm','Ventilated Disc','Drum','All Windows','','86PS@6000rpm','113Nm@3300rpm','Digital','Analog','5','Vinyl','AMT','Yes','Yes','Yes','Fully automatic climate control','',''),
(903,27,'Zest','1248 cc','BS IV','44 litres','Diesel','1570 mm','3995 mm','1706 mm','Sedan','1155 kg','5','165 mm','Ventilated Disc','Drum','All Windows','','75PS@4000rpm','190Nm@1750-3000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(904,15,'Amaze','1199 cc','BS 6','35 litres','Petrol','1501 mm','3995 mm','1695 mm','Sedan','942 kg','5','170 mm','Ventilated Disc','Drum','All Windows','','90PS@6000rpm','110Nm@4800rpm','Digital','Analog','5','Fabric','Automatic','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(924,8,'Gypsy','1298 cc','BS III','40 litres','Petrol','1875 mm','4010 mm','1540 mm','SUV','985 kg','5','210 mm','Solid Disc','Drum','','','80PS@6000rpm','103Nm@4500RPM','Yes','Analog','8','Fabric','Manual','','','','','',''),
(926,7,'Venue','1197 cc','BS IV','45 litres','Petrol','1590 mm','3995 mm','1770 mm','SUV','','5','200 mm','Ventilated Disc','Drum','All Windows','','82hp@6000rpm','112.7Nm@4000rpm','Yes','Yes','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(939,27,'Nexon','1198 cc','BS 6','44 litres','Petrol','1607 mm','3994 mm','1811 mm','SUV','','','209 mm','Ventilated Disc','Drum','Only Front Windows','','110PS@5000rpm','170Nm@1500-2750rpm','Analog','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(963,8,'Ertiga','1462 cc','BS 6','45 litres','Petrol','1690 mm','4395 mm','1735 mm','MPV','1135 kg','5','185 mm','Ventilated Disc','Drum','','','103Bhp@6000rpm','138Nm@4400rpm','Digital','Analog','7','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(973,8,'Baleno Rs','998 cc','BS IV','37 litres','Petrol','1510 mm','3995 mm','1745 mm','Hatchback','950 kg','5','170 mm','Ventilated Disc','Ventilated Disc','All Windows','','102PS@5500rpm','150Nm@1700-4500RPM','Digital','Analog','5','Leather','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(974,15,'Wr-V','1498 cc','BS IV','40 litres','Diesel','1601 mm','3999 mm','1734 mm','SUV','1204 kg','7','188 mm','Ventilated Disc','Drum','All Windows','Yes','100PS@3600rpm','200Nm@1750rpm','Analog','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(983,19,'Tuv300','1493 cc','BS IV','60 litres','Diesel','1817 mm','3995 mm','1835 mm','SUV','1590 kg','5','184 mm','Ventilated Disc','Drum','All Windows','','84PS@3750RPM','240Nm@1600-2800rpm','Digital','Analog','7','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(990,8,'S-Cross','1248 cc','BS IV','48 litres','Diesel','1595 mm','4300 mm','1785 mm','Crossover','1215 kg','5','180 mm','Ventilated Disc','Drum','All Windows','','90PS@4000rpm','200Nm@1750rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(994,25,'Captur','1498 cc','BS IV','50 litres','Petrol','1619 mm','4329 mm','1813 mm','SUV','','5','201 mm','Solid Disc','Drum','All Windows','','106PS@5600rpm','142Nm@4000rpm','Digital','Digital','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(998,19,'Xylo','2489 cc','BS IV','55 litres','Diesel','1895 mm','4520 mm','1850 mm','SUV','1875 kg','5','186 mm','Ventilated Disc','Drum','','','95PS@3600rpm','218Nm@1400-2600rpm','Digital','Analog','7','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(1003,18,'Seltos','1497 cc','BS 6','60 litres','Petrol','1645 mm','4315 mm','1800 mm','SUV','','6','190 mm','Ventilated Disc','Ventilated Disc','All Windows','','115PS@6300rpm','144Nm@4500 rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1019,23,'Terrano','1461 cc','BS IV','50 litres','Diesel','1671 mm','4331 mm','1822 mm','SUV','1236 kg','5','205 mm','Ventilated Disc','Drum','All Windows','','85PS@3750rpm','200Nm@1900rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1025,27,'Safari Storme','2179 cc','BS IV','63 litres','Diesel','1922 mm','4655 mm','1855 mm','SUV','2000 kg','5','200 mm','Ventilated Disc','Drum','All Windows','','150PS@4000rpm','320Nm@1700-2700rpm','Digital','Analog','7','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(1029,27,'Nexon Ev','','BS VI','','Electric','1607 mm','3994 mm','1811 mm','SUV','','','205 mm','Ventilated Disc','Solid Disc','All Windows','','129PS','245Nm','Digital','Digital','5','Fabric','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1032,7,'Elantra','1999 cc','BS 6','50 litres','Petrol','1465 mm','4620 mm','1800 mm','Sedan','','6','','Ventilated Disc','Ventilated Disc','All Windows','','152PS@6200rpm','196Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1043,7,'Tucson','1995 cc','BS IV','62 litres','Diesel','1660 mm','4475 mm','1850 mm','SUV','','5','','Ventilated Disc','Solid Disc','All Windows','Yes, with memory','185PS@4000rpm','400NM@1750rpm','Yes','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1044,29,'Passat','1968 cc','BS IV','55 litres','Diesel','1456 mm','4767 mm','1832 mm','Sedan','1535 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','','180PS@3600-4000rpm','350Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(1049,0,'Mu-X','2999 cc','BS IV','76 litres','Diesel','1840 mm','4825 mm','1860 mm','SUV','','5','220 mm','Ventilated Disc','Drum','All Windows','','177PS@3600rpm','380Nm@1800-2800rpm','Analog','Analog','7','Leather','Automatic','Yes','Yes','Yes','Heater, Fully automatic climate control','',''),
(1050,29,'Tiguan','1968 cc','BS IV','71 litres','Diesel','1672 mm','4486 mm','1839 mm','SUV','1720 kg','8','149 mm','Ventilated Disc','Solid Disc','All Windows','Yes, with memory','141PS@4000rpm','340Nm@1750-2750rpm','Analog','Analog','5','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(1053,6,'Superb Sportline','1968 cc','BS IV','66 litres','Diesel','1483 mm','4861 mm','1864 mm','Sedan','1565 kg','6','149 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','177PS@4000RPM','350Nm@1500-3500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(1054,6,'Kodiaq','1968 cc','BS IV','66 litres','Diesel','1483 mm','4861 mm','1864 mm','SUV','1565 kg','6','149 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','177PS@4000RPM','350Nm@1500-3500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1060,10,'Q3','1395 cc','BS IV','64 litres','Petrol','1608 mm','4388 mm','1831 mm','SUV','1585 kg','7','170 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','150PS@4200rpm','250Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1061,0,'Convertible','1998 cc','BS IV','44 litres','Petrol','1415 mm','3850 mm','1727 mm','Convertible','1370 kg','6','','Ventilated Disc','Ventilated Disc','All Windows','Yes','192PS@5000-6000rpm','280NM@1250-4600rpm','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1062,0,'Clubman','1998 cc','BS IV','','Petrol','1441 mm','4253 mm','1801 mm','Hatchback','1960 kg','','146 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','Yes','192PS@6200RPM','280NM@1250rpm','Digital','Analog','5','Leather','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(1063,0,'John Cooper Works','1998 cc','BS 6','44 litres','Petrol','1414 mm','3874 mm','1727 mm','Sports, Hatchback','1330 kg','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','231hp@5200-6200rpm','320 Nm@1450-4800rpm','Digital','Digital','2','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1064,16,'Xf','1999 cc','BS IV','74 litres','Petrol','1460 mm','4961 mm','2091 mm','Sedan','1730 kg','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','247PS@5500rpm','340Nm@1750-2000RPM','Analog','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1070,10,'A6','1984 cc','BS 6','73 litres','Petrol','1455 mm','4933 mm','1874 mm','Sedan','1780 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','245PS@5000-6500rpm','370Nm@1600-4500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1071,0,'Discovery Sport','1999 cc','BS 6','70 litres','Diesel','1727 mm','4600 mm','2069 mm','SUV','2087 kg','9','167 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','179PS@4000rpm','430NM@1750rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1073,30,'Xc60','1969 cc','BS IV','70 litres','Diesel','1658 mm','4688 mm','1902 mm','SUV','1879 kg','6','209 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','233PS@4250rpm','480Nm@1750rpm','Digital','Digital','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1074,17,'Wrangler','1999 cc','BS 6','85 litres','Petrol','1838 mm','4882 mm','1877 mm','SUV','','8','215 mm','Ventilated Disc','Ventilated Disc','All Windows','Power seats','268PS@6350rpm','400Nm@4300rpm','Digital','Analog','5','Leather','Automatic','Yes','','Yes','Fully automatic climate control','',''),
(1075,11,'Z4 Roadster','1998 cc','BS 6','52 litres','Petrol','1304 mm','4324 mm','2024 mm','Sports, Convertible','1495 kg','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','197hp@4500-6500rpm','320hp@1450-2000rpm','Yes','Digital','2','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1077,10,'Q7','2967 cc','BS IV','75 litres','Diesel','1740 mm','5052 mm','1968 mm','SUV','2330 kg','8','200 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','249PS@4500RPM','600Nm@1500-3000rpm','Digital','Digital','7','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1083,10,'S5','2995 cc','BS IV','58 litres','Petrol','1384 mm','4718 mm','1843 mm','Sedan','1790 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes','333PS@5400-6400RPM','500Nm@1370-4500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(1084,14,'Mustang','4951 cc','BS IV','60.9 litres','Petrol','1391 mm','4784 mm','2080 mm','Sedan, Coupe','','6','137 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','401PS@6550RPM','515Nm@4250-4300RPM','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1085,28,'Land Cruiser Prado','2982 cc','BS IV','87 litres','Diesel','1880 mm','4840 mm','1885 mm','SUV','','5','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','173PS@3400rpm','410Nm@1600-2800rpm','Digital','Analog','7','Leather','Automatic','Yes','Yes','Yes','3 Zone climate control','',''),
(1086,10,'Rs5','2894 cc','BS IV','58 litres','Petrol','','4649 mm','','Coupe','1770 kg','7','160 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','Yes','450PS@5700-6700rpm','600Nm@1900-5000rpm','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1087,10,'Q8','2995 cc','BS 6','85 litres','Petrol','1740 mm','5052 mm','1968 mm','SUV','2115 kg','8','200 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','340PS@5000rpm','500Nm@1370rpm','Digital','Analog, Digital','7','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1088,10,'A8 L','2995 cc','BS 6','82 litres','Petrol','1485 mm','5302 mm','1945 mm','Sedan','2030 kg','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','340PS@5000rpm','500Nm@1370rpm','Digital','Analog, Digital','4','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1089,0,'Huracan','5204 cc','BS IV','90 litres','Petrol','1165 mm','4459 mm','1924 mm','Coupe','1422 kg','7','135 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','Power seats','610PS@8250rpm','560Nm@6500rpm','Digital','Digital','2','Leather','Automatic','Yes','','Yes','Fully automatic climate control','',''),
(1098,0,'488 Gtb','3902 cc','BS IV','78 litres','Petrol','1213 mm','4568 mm','1952 mm','Coupe','1475 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes','670PS@8000rpm','760NM@3000rpm','Digital','Digital','2','Leather','Automatic','Yes','','Yes','Fully automatic climate control','',''),
(1100,0,'Gtc4 Lusso','3900 cc','BS IV','91 litres','Petrol','1383 mm','4922 mm','1980 mm','Coupe','1920 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes','610PS@7000rpm','760Nm@5250RPM','Digital','Digital','4','Leather','Automatic','Yes','','Yes','Fully automatic climate control','',''),
(1102,0,'Aventador','6498 cc','BS IV','90 litres','Petrol','1136 mm','4780 mm','2030 mm','Convertible','1575 kg','7','100 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','Yes','700PS@8250RPM','690Nm@5500rpm','','','2','Leather','Automatic','','Yes','','Fully automatic climate control','',''),
(1105,8,'Omni','796 cc','BS IV','35 litres','Petrol','1640 mm','3370 mm','1410 mm','MPV','785 kg','4','165 mm','Solid Disc','Drum','','','34.7PS@5000rpm','59Nm@2500rpm','Analog','Analog','5','Fabric','Manual','','Yes','','','',''),
(1107,14,'Figo','1194 cc','BS IV','42 litres','Petrol','1525 mm','3941 mm','1704 mm','Hatchback','1026 kg','5','','Ventilated Disc','Drum','Only Front Windows','','96PS@6500rpm','120Nm@4250rpm','Digital','Analog','5','Fabric','Manual','','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1113,8,'Baleno','1248 cc','BS IV','37 litres','Diesel','1510 mm','3995 mm','1745 mm','Hatchback','970 kg','5','170 mm','Ventilated Disc','Drum','All Windows','','75PS@4000rpm','190Nm@2000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(1126,7,'Grand I10','1197 cc','BS IV','43 litres','Petrol','1520 mm','3765 mm','1660 mm','Hatchback','1003 kg','5','165 mm','Solid Disc','Drum','All Windows','','83PS@6000rpm','114Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1132,23,'Sunny','1498 cc','BS IV','41 litres','Petrol','1515 mm','4455 mm','1695 mm','Sedan','','5','','Ventilated Disc','Drum','Only Front Windows','','99PS@6000rpm','134Nm@4000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1139,19,'Bolero','2523 cc','BS IV','60 litres','Diesel','1880 mm','4107 mm','1745 mm','SUV','1615 kg','5','180 mm','Ventilated Disc','Drum','All Windows','','63PS@3200rpm','195Nm@1400-2200rpm','Digital','Digital','7','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(1144,8,'Ciaz','1248 cc','BS IV','43 litres','Diesel','1485 mm','4490 mm','1730 mm','Sedan','1105 kg','5','170 mm','Ventilated Disc','Drum','All Windows','','89Bhp@4000RPM','200Nm@1750rpm','Digital','Analog','5','Leather','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(1158,6,'Rapid','1598 cc','BS IV','55 litres','Petrol','1466 mm','4413 mm','1699 mm','Sedan','1137 kg','5','163 mm','Ventilated Disc','Drum','All Windows','','105PS@5250rpm','153Nm@3750-3800rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(1172,7,'Creta','1396 cc','BS IV','55 litres','Diesel','1630 mm','4270 mm','1780 mm','SUV','','6','190 mm','Ventilated Disc','Drum','All Windows','','90PS@4000rpm','220Nm@1500-2750rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1190,27,'Harrier','1956 cc','BS 6','50 litres','Diesel','1706 mm','4598 mm','1894 mm','SUV','','6','205 mm','Ventilated Disc','Drum','All Windows','','140PS@3750rpm','350Nm@1750-2500rpm','','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1196,0,'Dmax V-Cross','2499 cc','BS IV','','Diesel','1840 mm','5295 mm','1860 mm','Pick-up','1935 kg','5','','Ventilated Disc','Drum','All Windows','','134PS@3600RPM','320NM@1800-2800RPM','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(1199,17,'Compass Trailhawk','1956 cc','BS 6','60 litres','Diesel','1657 mm','4398 mm','1818 mm','SUV','1654 kg','9','','Ventilated Disc','Ventilated Disc','All Windows','','173PS@3750rpm','350Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1201,15,'Cr-V','1997 cc','','57 litres','Petrol','1679 mm','4592 mm','1855 mm','SUV','','7','198 mm','Ventilated Disc','Solid Disc','All Windows','Power seats','154PS@6500rpm','189NM@4300rpm','Digital','Digital','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1204,0,'Cooper 5 Door','1496 cc','BS IV','44 litres','Petrol','1425 mm','3982 mm','1727 mm','Hatchback','1295 kg','6','','Ventilated Disc','Ventilated Disc','All Windows','Power seats','116PS@4000rpm','270Nm@1750-2250rpm','','','5','Leather','Automatic','','Yes','Yes','Fully automatic climate control','',''),
(1205,10,'A4','1395 cc','BS IV','54 litres','Petrol','1427 mm','4726 mm','1842 mm','Sedan','1450 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','150PS@5000-6000rpm','250Nm@1500-3500','Digital','Digital','5','Leather','DCT','Yes','Yes','Yes','3 Zone climate control','',''),
(1207,10,'A3 Cabriolet','1395 cc','BS IV','50 litres','Petrol','1409 mm','4421 mm','1793 mm','Convertible','1430 kg','7','160 mm','Ventilated Disc','Ventilated Disc','All Windows','','148 bhp @ 5100 rpm','250 Nm @ 1250 RPM','Digital','Analog','4','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1208,30,'S90','1969 cc','BS IV','','Diesel','1443 mm','4963 mm','1879 mm','Sedan','','','152 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','190PS@4250rpm','400NM@1750rpm','Analog','Analog, Digital','5','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1209,17,'Grand Cherokee','2987 cc','BS IV','93.5 litres','Diesel','1802 mm','4828 mm','1943 mm','SUV','2432 kg','','206 mm','Ventilated Disc','Ventilated Disc','Only Front Windows','Yes, with memory','240PS@3600rpm','570Nm@2000rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1213,11,'7-Series','2993 cc','BS 6','78 litres','Diesel','1479 mm','5120 mm','2169 mm','Sedan','','8','152 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','265PS@4000RPM','620Nm@2000-2500RPM','Digital','Analog, Digital','4','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1219,0,'458 Spider','3902 cc','BS IV','86 litres','Petrol','1211 mm','4568 mm','1952 mm','Coupe, Convertible','1525 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes','669PS@8000rpm','760NM@3000rpm','Digital','Digital','2','Leather','Automatic','Yes','','Yes','Fully automatic climate control','',''),
(1220,8,'Alto 800 Tour','796 cc','BS IV','35 litres','Petrol','1475 mm','3430 mm','1490 mm','Hatchback','720 kg','5','160 mm','Solid Disc','Drum','Only Front Windows','','48PS@6000rpm','69Nm@3500rpm','Digital','Analog','5','Fabric','Manual','','Yes','','Manual Air conditioning with cooling and heating','',''),
(1222,7,'Grand I10 Nios','1186 cc','BS 6','37 litres','Diesel','1520 mm','3805 mm','1680 mm','Hatchback','','5','','Ventilated Disc','Drum','All Windows','','75PS@4000rpm','190NM@1750-2250RPM','Digital','Analog, Digital','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1232,7,'Xcent','1197 cc','BS IV','43 litres','Petrol','1520 mm','3995 mm','1660 mm','Sedan','','5','165 mm','Ventilated Disc','Drum','All Windows','','83PS@6000rpm','114Nm@6000rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1241,23,'Micra','1198 cc','BS IV','41 litres','Petrol','1530 mm','3825 mm','1665 mm','Hatchback','930 kg','5','154 mm','Ventilated Disc','Drum','All Windows','','77PS@6000rpm','104Nm@4000rpm','Digital','Analog','5','Fabric','Automatic','Yes','','Yes','Manual Air conditioning with cooling and heating','',''),
(1245,19,'Nuvosport','1493 cc','BS IV','60 litres','Diesel','1870 mm','3985 mm','1850 mm','SUV','','5','180 mm','Ventilated Disc','Drum','','','100PS@3750RPM','240Nm@1600-2800rpm','Digital','Analog','7','Fabric','Manual','Yes','Yes','','Manual Air conditioning with cooling and heating','',''),
(1251,23,'Kicks','1498 cc','BS 6','50 litres','Petrol','1651 mm','4384 mm','1813 mm','SUV','','6','210 mm','','','All Windows','','106PS@5600rpm','142Nm@4000rpm','Yes','Yes','5','','Manual','Yes','Yes','Yes','Air Conditioning with cooling only','',''),
(1259,27,'Winger','2200 cc','BS 6','60 litres','Diesel','2670 mm','5458 mm','1905 mm','MUV','2275 kg','5','180 mm','Solid Disc','Drum','','','73.5kW@4000rpm','190Nm@1250-3500rpm','Analog','Analog','16','Fabric','Manual','','Yes','','Yes','',''),
(1260,7,'Kona Electric','','','','Electric','1570 mm','4180 mm','1800 mm','SUV','','Single Speed Reduction Gear','160 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','136 bhp','395 Nm','Digital','Digital','4','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1261,10,'A3','1968 cc','BS IV','50 litres','Diesel','1416 mm','4456 mm','1796 mm','Sedan','1340 kg','6','161 mm','Ventilated Disc','Ventilated Disc','All Windows','','143PS@4000rpm','320Nm@1750-3000rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1265,30,'Xc40','1969 cc','BS IV','','Diesel','1652 mm','4425 mm','1863 mm','SUV','','8','211 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','190bhp','400Nm','Digital','Digital','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1268,11,'X3','1995 cc','BS IV','67 litres','Diesel','1678 mm','4657 mm','1881 mm','SUV','1785 kg','8','212 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','190PS@4000rpm','400Nm@1750-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1271,11,'M2 Competition','2979 cc','BS 6','52 litres','Petrol','1410 mm','4461 mm','1854 mm','Coupe','1625 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes','410hp@5230-7000RPM','550Nm@2350-5230rpm','Digital','Analog','4','Leather','Automatic','Yes','','Yes','2 Zone Climate Control','',''),
(1272,23,'Gtr','3799 cc','BS IV','74 litres','Petrol','1370 mm','4710 mm','1895 mm','Coupe','1752 kg','6','110 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','570PS@6800rpm','637Nm@3200rpm','Analog','Analog','4','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1273,8,'Wagon','998 cc','BS 6','32 litres','Petrol','1675 mm','3655 mm','1620 mm','Hatchback','','5','','Ventilated Disc','Drum','All Windows','','68PS@5500rpm','90Nm@3500rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1287,27,'Tiago Nrg','1199 cc','BS IV','35 litres','Petrol','1587 mm','3793 mm','1665 mm','Crossover','1017 kg','5','180 mm','Ventilated Disc','Drum','All Windows','','85PS@6000rpm','114NM@3500rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1290,28,'Yaris','1496 cc','BS IV','42 litres','Petrol','1495 mm','4425 mm','1730 mm','Sedan','1090 kg','6','152 mm','Ventilated Disc','Drum','All Windows','','107PS@6000rpm','140Nm@4200rpm','Yes','Analog','5','Fabric','Manual','Yes','Yes','Yes','Manual Air conditioning with cooling and heating','',''),
(1304,6,'Octavia','1395 cc','BS IV','50 litres','Petrol','1476 mm','4670 mm','1814 mm','Sedan','1260 kg','6','155 mm','Ventilated Disc','Ventilated Disc','All Windows','','140PS@6000RPM','250Nm@1500-3500rpm','Digital','Analog','5','Leather','Manual','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1316,11,'X4','1995 cc','BS 6','60 litres','Diesel','1621 mm','4752 mm','1918 mm','SUV','1740 kg','8','498 mm','Ventilated Disc','Ventilated Disc','All Windows','Yes','188bhp@4000RPM','400NM@1750rpm','Yes','Yes','5','Leather','Automatic','Yes','Yes','Yes','Fully automatic climate control','',''),
(1319,15,'City','1497 cc','BS 6','40 litres','Petrol','1495 mm','4440 mm','1695 mm','Sedan','1063 kg','5','165 mm','Ventilated Disc','Drum','All Windows','','119PS@6600rpm','145Nm@4600rpm','Digital','Analog','5','Fabric','Manual','Yes','Yes','Yes','Fully automatic climate control','',''),
(1329,16,'Xe','1997 cc','BS 6','61 litres','Petrol','1416 mm','4691 mm','1850 mm','Sedan','1639 kg','8','125 mm','Ventilated Disc','Ventilated Disc','All Windows','Power seats','250PS@5500RPM','365Nm@1500-4000rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1333,19,'Verito','1461 cc','BS IV','50 litres','Diesel','1540 mm','4277 mm','1740 mm','Sedan','1140 kg','5','172 mm','Ventilated Disc','Drum','','','65PS@4000rpm','160Nm@2000rpm','Digital','Analog','5','Fabric','Manual','','Yes','','Manual Air conditioning with cooling and heating','',''),
(1336,11,'X5','2993 cc','BS IV','','Diesel','1745 mm','4922 mm','2218 mm','SUV','','8','','Ventilated Disc','Ventilated Disc','All Windows','Yes','265HP@4000rpm','620Nm@1500-2500rpm','Digital','Analog','5','Leather','Automatic','Yes','Yes','Yes','4 Zone climate control','',''),
(1340,19,'Alturas G4','2157 cc','','70 litres','Diesel','1.845 mm','4850 mm','1960 mm','SUV','','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes, with memory','178Bhp @ 4000','420Nm @1600-2600','Digital','Digital','7','Leather','Automatic','Yes','Yes','Yes','2 Zone Climate Control','',''),
(1341,0,'812 Superfast','6496 cc','BS IV','92 litres','Petrol','1276 mm','4657 mm','1971 mm','Coupe','1630 kg','7','','Ventilated Disc','Ventilated Disc','All Windows','Yes','789 bhp @ 8500 rpm','718 Nm @ 7000 rpm','Digital','Digital','2','Leather','Automatic','Yes','','Yes','Fully automatic climate control','',''),
(1342,8,'VITARA BREZZA 1.5 PETROL LXI MT','1462 cc','BS IV','48 litres','Petrol','1685 mm','3995 mm','1790 mm','SUV','1110 kg','5','198 mm','Disc','Drum','Yes','No','102 bhp @ 6000 rpm','136.8 Nm @ 4400 rpm','Digital','Analogue','5','Fabric','Yes','Yes','Yes','Yes','Blower, Vents Behind Front Armrest, Automatic climate control - ',NULL,NULL),
(1343,8,'BREZZA VXI','1462 cc','BS VI Phase 2 ',' 48 liters',' Petrol','1685 mm','3995 mm','1790 mm','SUV','1110 kg','5','198 mm','Ventilated Disc','Drum','Front & Rear Window','No','102 bhp @ 6000 rpm','136.8 Nm @ 4400 rpm','Digital','Analogue','5','Fabric','Manual - 5 Gears','Yes','Yes','Yes',' Yes (Automatic Climate Control)',NULL,NULL),
(1344,8,'BREZZA VXI S-CNG','1462 cc','BS VI Phase 2 ','55 liters','Petrol + CNG','1685 mm','3995 mm','1790 mm','SUV','1110 kg','Manual - 5 Gears','198 mm',' Ventilated Disc',' Drum','Front & Rear Window','No',' 87 bhp @ 5500 rpm',' 121.5 Nm @ 4200 rpm','Digital','Analogue','5','Fabric','Yes','Yes','Yes','Yes',' Yes (Automatic Climate Control)',NULL,NULL);
/*!40000 ALTER TABLE `tbl_car_model` ENABLE KEYS */;

--
-- Table structure for table `tbl_car_pickup_images`
--

DROP TABLE IF EXISTS `tbl_car_pickup_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_car_pickup_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carId` int(11) NOT NULL,
  `driverId` int(11) NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `is_verified` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_car_pickup_images`
--

/*!40000 ALTER TABLE `tbl_car_pickup_images` DISABLE KEYS */;
INSERT INTO `tbl_car_pickup_images` VALUES
(1,1,2,'temp5622887457764015955.jpg',1,'2025-06-21 14:58:26'),
(2,1,2,'temp6585983431421420550.jpg',1,'2025-06-21 14:58:26'),
(3,1,2,'temp1922976291348200982.jpg',1,'2025-06-21 14:58:37'),
(4,1,2,'temp7951447480476550240.jpg',1,'2025-06-21 14:58:37'),
(5,1,3,'temp630081100984780191.jpg',1,'2025-06-24 15:20:12'),
(6,1,3,'temp2847768707917970312.jpg',1,'2025-06-24 15:20:12'),
(7,1,3,'temp2702485721935993666.jpg',1,'2025-06-24 15:20:12'),
(9,1,3,'temp4062182800867332782.jpg',1,'2025-06-24 15:20:12'),
(10,1,3,'temp3380868797131602625.jpg',1,'2025-06-24 15:20:12'),
(11,7,2,'temp9078135806728170553.jpg',1,'2025-06-26 07:39:14'),
(12,7,2,'temp4683954634343457259.jpg',1,'2025-06-26 07:39:14'),
(13,7,7,'temp3007761622188851956.jpg',1,'2025-06-26 08:24:19'),
(14,7,7,'temp7734867149773653131.jpg',1,'2025-06-26 08:24:19'),
(15,14,9,'temp9029227750270712968.jpg',1,'2025-06-27 14:14:06'),
(16,14,9,'temp2094462000794948254.jpg',1,'2025-06-27 14:14:06'),
(17,14,9,'temp7762330616600702016.jpg',1,'2025-06-27 14:14:06'),
(18,14,9,'temp2716079359882497398.jpg',1,'2025-06-27 14:14:06'),
(19,14,9,'temp1729823237104135014.jpg',1,'2025-06-27 14:14:06'),
(20,14,9,'temp7417870104737419819.jpg',1,'2025-06-27 14:14:06'),
(21,14,9,'temp5351185324208435143.jpg',1,'2025-06-27 14:14:06'),
(22,13,8,'temp1105930798333957568.jpg',1,'2025-06-27 14:16:04'),
(23,13,8,'temp7211965035032215577.jpg',1,'2025-06-27 14:16:04'),
(24,13,8,'temp6467488886792042797.jpg',1,'2025-06-27 14:16:04'),
(25,13,8,'temp4331042705571325477.jpg',1,'2025-06-27 14:16:04'),
(26,13,8,'temp7354251458973606129.jpg',1,'2025-06-27 14:16:04'),
(27,16,9,'temp8991194076355838476.jpg',1,'2025-06-30 19:01:17'),
(28,16,9,'temp8974323635858445938.jpg',1,'2025-06-30 19:01:17'),
(29,16,9,'temp7389414007937649377.jpg',1,'2025-06-30 19:01:17'),
(30,16,9,'temp2776030202583314396.jpg',1,'2025-06-30 19:01:17'),
(31,16,9,'temp371205855299267153.jpg',1,'2025-06-30 19:01:17'),
(32,16,9,'temp2247437035268625657.jpg',1,'2025-06-30 19:01:17'),
(33,16,9,'temp7352001883775210695.jpg',1,'2025-06-30 19:01:17'),
(34,16,9,'temp6359197574296565925.jpg',1,'2025-06-30 19:01:17'),
(35,16,9,'temp5672432307526983872.jpg',1,'2025-06-30 19:01:17'),
(36,16,9,'temp7113304861163910099.jpg',1,'2025-06-30 19:01:17'),
(37,16,9,'temp8720995938972893684.jpg',1,'2025-06-30 19:01:17'),
(38,16,9,'temp2249950301806524621.jpg',1,'2025-06-30 19:01:17'),
(39,16,10,'temp2001657804101033142.jpg',1,'2025-06-30 19:12:37'),
(40,16,10,'temp6162449770209125479.jpg',1,'2025-06-30 19:12:37'),
(41,16,10,'temp7360551370266953097.jpg',1,'2025-06-30 19:12:37'),
(42,16,10,'temp4804721429599867583.jpg',1,'2025-06-30 19:12:37'),
(43,16,10,'temp8704430659977340315.jpg',1,'2025-06-30 19:12:37'),
(44,16,10,'temp2685318392165282555.jpg',1,'2025-06-30 19:12:37'),
(45,16,10,'temp2756223843737066192.jpg',1,'2025-06-30 19:12:37'),
(46,16,10,'temp7283839584062888004.jpg',1,'2025-06-30 19:12:37'),
(47,16,10,'temp3199450872311347572.jpg',1,'2025-06-30 19:12:37'),
(48,16,10,'temp8985843521445825165.jpg',1,'2025-06-30 19:12:37'),
(49,16,10,'temp1398466977966762888.jpg',1,'2025-06-30 19:12:37');
/*!40000 ALTER TABLE `tbl_car_pickup_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_city`
--

DROP TABLE IF EXISTS `tbl_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(100) NOT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=657 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_city`
--

/*!40000 ALTER TABLE `tbl_city` DISABLE KEYS */;
INSERT INTO `tbl_city` VALUES
(1,'ANDAMAN_NICOBAR_IS',1),
(2,'ADILABAD',2),
(3,'ANANTAPUR',2),
(4,'CHITTOOR',2),
(5,'EAST_GODAVARI',2),
(6,'GUNTUR',2),
(7,'HYDERABAD',2),
(8,'Kadapa',2),
(9,'KARIMNAGAR',2),
(10,'KHAMMAM/BHADRACHALAM',2),
(11,'KRISHNA',2),
(12,'KURNOOL',2),
(13,'MAHBUBNAGAR',2),
(14,'MEDAK',2),
(15,'NALGONDA',2),
(16,'NELLORE',2),
(17,'NIZAMABAD',2),
(18,'PRAKASAM',2),
(19,'RANGAREDDI',2),
(20,'SRIKAKULAM',2),
(21,'VISAKHAPATNAM',2),
(22,'VIZIANAGARAM',2),
(23,'WARANGAL',2),
(24,'WEST_GODAVARI',2),
(25,'ANJAW',3),
(26,'CHANGLANG',3),
(27,'EAST KAMENG',3),
(28,'EAST SIANG',3),
(29,'KURUNG KUMEY',3),
(30,'LOHIT',3),
(31,'LOWER DIBANG_VALLEY',3),
(32,'LOWER SUBANSIRI',3),
(33,'PAPUM PARE',3),
(34,'TAWANG',3),
(35,'TIRAP',3),
(36,'UPPER DIBANG VALLEY',3),
(37,'UPPER SIANG',3),
(38,'UPPER SUBANSIRI',3),
(39,'WEST KAMENG',3),
(40,'WEST SIANG',3),
(41,'BAKSA',4),
(42,'BARPETA',4),
(43,'BONGAIGAON',4),
(44,'CACHAR',4),
(45,'CHIRANG',4),
(46,'DARRANG',4),
(47,'DHEMAJI',4),
(48,'DHUBRI',4),
(49,'DIBRUGARH',4),
(50,'GOALPARA',4),
(51,'GOLAGHAT',4),
(52,'HAILAKANDI',4),
(53,'JORHAT',4),
(54,'KAMRUP',4),
(55,'KARBI ANGLONG',4),
(56,'KARIMGANJ',4),
(57,'KOKRAJHAR',4),
(58,'LAKHIMPUR',4),
(59,'MARIGAON',4),
(60,'NAGAON',4),
(61,'NALBARI',4),
(62,'NORTH_CACHAR_HILLS',4),
(63,'SIBSAGAR',4),
(64,'SONITPUR',4),
(65,'TINSUKIA',4),
(66,'UDALGURI',4),
(67,'ARARIA',5),
(68,'ARWAL',5),
(69,'AURANGABAD-BI',5),
(70,'BANKA',5),
(71,'BEGUSARAI',5),
(72,'BHAGALPUR',5),
(73,'BHOJPUR',5),
(74,'BUXAR',5),
(75,'DARBHANGA',5),
(76,'EAST CHAMPARAN',5),
(77,'GAYA',5),
(78,'GOPALGANJ',5),
(79,'JAMUI',5),
(80,'JEHANABAD',5),
(81,'KAIMUR',5),
(82,'KATIHAR',5),
(83,'KHAGARIA',5),
(84,'KISHANGANJ',5),
(85,'LAKHISARAI',5),
(86,'MADHEPURA',5),
(87,'MADHUBANI',5),
(88,'MUNGER',5),
(89,'MUZAFFARPUR',5),
(90,'NALANDA',5),
(91,'NAWADA',5),
(92,'PATNA',5),
(93,'PURNIA',5),
(94,'ROHTAS',5),
(95,'SAHARSA',5),
(96,'SAMASTIPUR',5),
(97,'SARAN',5),
(98,'SHEIKHPURA',5),
(99,'SHEOHAR',5),
(100,'SITAMARHI',5),
(101,'SIWAN',5),
(102,'SUPAUL',5),
(103,'VAISHALI',5),
(104,'WEST CHAMPARAN',5),
(105,'BASTAR',7),
(106,'BILASPUR-CG',7),
(107,'DANTEWADA',7),
(108,'DHAMTARI',7),
(109,'DURG',7),
(110,'JANJGIR',7),
(111,'JASHPUR',7),
(112,'KANKER',7),
(113,'KAWARDHA/Kabir Dham',7),
(114,'KORBA',7),
(115,'KORIYA',7),
(116,'MAHASAMUND',7),
(117,'RAIGARH-CG',7),
(118,'RAIPUR',7),
(119,'RAJNANDGAON',7),
(120,'SURGUJA (Ambikapur)',7),
(121,'CHANDIGARH',6),
(122,'Daman',9),
(123,'DIU',9),
(124,'Central',10),
(125,'CITY ZONE',10),
(126,'Civili Line',10),
(127,'Karol Bagh',10),
(128,'Najafgarh',10),
(129,'NARELA',10),
(130,'Rohini',10),
(131,'S. Pahar Ganj',10),
(132,'Shahadra (N)',10),
(133,'Shahadra (S)',10),
(134,'SOUTH',10),
(135,'West',10),
(136,'DADRA_&_NAGAR_HAVELI',8),
(137,'GOA',11),
(138,'Ahmedabad',12),
(139,'Amreli',12),
(140,'Anand',12),
(141,'Banaskantha',12),
(142,'Bharuch',12),
(143,'Bhavnagar',12),
(144,'Dahod',12),
(145,'Dang',12),
(146,'Gandhinagar',12),
(147,'Godhara',12),
(148,'Jamnagar',12),
(149,'Junagadh',12),
(150,'Kheda',12),
(151,'Kutch',12),
(152,'Mahesana',12),
(153,'Narmada',12),
(154,'Navsari',12),
(155,'Patan',12),
(156,'Porbandar',12),
(157,'Rajkot',12),
(158,'Sabarkantha',12),
(159,'Surat',12),
(160,'Surendranagar',12),
(161,'Vadodara',12),
(162,'Valsad',12),
(163,'Tapi',12),
(164,'BILASPUR-HP',14),
(165,'CHAMBA',14),
(166,'HAMIRPUR-HP',14),
(167,'KANGRA',14),
(168,'KULLU',14),
(169,'MANDI',14),
(170,'SHIMLA',14),
(171,'SIRMAUR',14),
(172,'SOLAN',14),
(173,'UNA',14),
(174,'AMBALA',13),
(175,'BHIWANI',13),
(176,'FARIDABAD',13),
(177,'FATEHABAD',13),
(178,'GURGAON',13),
(179,'HISAR',13),
(180,'JHAJJAR',13),
(181,'JIND',13),
(182,'KAITHAL',13),
(183,'KARNAL',13),
(184,'KURUKSHETRA',13),
(185,'MEWAT',13),
(186,'NARNAUL',13),
(187,'PALWAL',13),
(188,'PANCHKULA',13),
(189,'PANIPAT',13),
(190,'REWARI',13),
(191,'ROHTAK',13),
(192,'SIRSA',13),
(193,'SONIPAT',13),
(194,'YAMUNANAGAR',13),
(195,'BOKARO',16),
(196,'CHATRA',16),
(197,'DEOGARH',16),
(198,'DHANBAD',16),
(199,'DUMKA',16),
(200,'EAST SINGHBHUM',16),
(201,'GARHWA',16),
(202,'GIRIDIH',16),
(203,'GODDA',16),
(204,'GUMLA',16),
(205,'HAZARIBAGH',16),
(206,'JAMTARA',16),
(207,'KODARMA',16),
(208,'LATHEHAR',16),
(209,'LOHARDAGA',16),
(210,'PAKUR',16),
(211,'PALAMU',16),
(212,'RANCHI',16),
(213,'SAHIBGANJ',16),
(214,'SARAIKELA-KHARSAWAN',16),
(215,'SIMDEGA',16),
(216,'WEST SINGHBHUM',16),
(217,'BARAMULA',15),
(218,'DODA',15),
(219,'JAMMU',15),
(220,'KATHUA',15),
(221,'KISHTWAR',15),
(222,'POONCH',15),
(223,'RAJOURI',15),
(224,'RAMBAN',15),
(225,'REASI',15),
(226,'SAMBHA',15),
(227,'UDHAMPUR',15),
(228,'BAGALKOT',17),
(229,'BANGALORE RURAL',17),
(230,'BANGALORE Urban',17),
(231,'BELGAUM',17),
(232,'BELLARY',17),
(233,'BIDAR',17),
(234,'BIJAPUR',17),
(235,'CHAMARAJANAGAR',17),
(236,'CHIKKABALLAPUR',17),
(237,'CHIKMAGALUR',17),
(238,'CHITRADURGA',17),
(239,'DAKSHINA KANNADA',17),
(240,'DAVANAGERE',17),
(241,'DHARWAD',17),
(242,'GADAG',17),
(243,'GULBARGA',17),
(244,'HASSAN',17),
(245,'HAVERI',17),
(246,'KODAGU',17),
(247,'KOLAR',17),
(248,'KOPPAL',17),
(249,'MANDYA',17),
(250,'MYSORE',17),
(251,'RAICHUR',17),
(252,'RAMANAGARA',17),
(253,'SHIMOGA',17),
(254,'TUMKUR',17),
(255,'UDUPI',17),
(256,'UTTARA_KANNADA',17),
(257,'ALAPPUZHA',18),
(258,'Ernakulam',18),
(259,'IDUKKI',18),
(260,'KANNUR',18),
(261,'KASARAGOD',18),
(262,'KOLLAM',18),
(263,'KOTTAYAM',18),
(264,'KOZHIKODE',18),
(265,'MALAPPURAM',18),
(266,'PALAKKAD',18),
(267,'PATHANAMTHITTA',18),
(268,'THIRUVANANTHAPURAM',18),
(269,'THRISSUR',18),
(270,'WAYANAD',18),
(271,'LAKSHADWEEP',19),
(272,'BHOI',23),
(273,'EAST GARO HILLS',23),
(274,'EAST KHASI HILLS',23),
(275,'JAINTIA HILLS',23),
(276,'SOUTH GARO HILLS',23),
(277,'WEST GARO HILLS',23),
(278,'WEST KHASI HILLS',23),
(279,'AHMEDNAGAR',21),
(280,'AKOLA',21),
(281,'AMARAVATI',21),
(282,'AURANGABAD',21),
(283,'BEED',21),
(284,'BHANDARA',21),
(285,'BULDANA',21),
(286,'CHANDRAPUR',21),
(287,'DHULE',21),
(288,'GADCHIROLI',21),
(289,'GONDIA',21),
(290,'HINGOLI',21),
(291,'JALGAON',21),
(292,'JALNA',21),
(293,'KOLHAPUR',21),
(294,'LATUR',21),
(295,'NAGPUR',21),
(296,'NANDED',21),
(297,'NANDURBAR',21),
(298,'NASIK',21),
(299,'OSMANABAD',21),
(300,'PARBHANI',21),
(301,'PUNE',21),
(302,'RAIGAD',21),
(303,'RATNAGIRI',21),
(304,'SANGLI',21),
(305,'SATARA',21),
(306,'SINDHUDURG',21),
(307,'SOLAPUR',21),
(308,'THANE',21),
(309,'WARDHA',21),
(310,'WASHIM',21),
(311,'YAWATMAL',21),
(312,'BISHNUPUR',22),
(313,'CHANDEL',22),
(314,'CHURACHANDPUR',22),
(315,'IMPHAL_EAST',22),
(316,'IMPHAL_WEST',22),
(317,'KANGPOKPI',22),
(318,'SENAPATI',22),
(319,'TAMENGLONG',22),
(320,'THOUBAL',22),
(321,'UKHRUL',22),
(322,'Anupur',20),
(323,'ASHOK NAGAR',20),
(324,'BALAGHAT',20),
(325,'BARWANI',20),
(326,'BETUL',20),
(327,'BHIND',20),
(328,'BHOPAL',20),
(329,'BURHANPUR',20),
(330,'CHHATARPUR',20),
(331,'CHHINDWARA',20),
(332,'DAMOH',20),
(333,'DATIA',20),
(334,'DEWAS',20),
(335,'DHAR',20),
(336,'DINDORI',20),
(337,'GUNA',20),
(338,'GWALIOR',20),
(339,'HARDA',20),
(340,'HOSHANGABAD',20),
(341,'INDORE',20),
(342,'JABALPUR',20),
(343,'JHABUA',20),
(344,'KATNI',20),
(345,'KHANDWA',20),
(346,'KHARGONE',20),
(347,'MANDLA',20),
(348,'MANDSAUR',20),
(349,'MORENA',20),
(350,'NARSINGHPUR',20),
(351,'NEEMUCH',20),
(352,'PANNA',20),
(353,'RAISEN',20),
(354,'RAJGARH',20),
(355,'RATLAM',20),
(356,'REWA',20),
(357,'SAGAR',20),
(358,'SATNA',20),
(359,'SEONI',20),
(360,'SHAHDOL',20),
(361,'SHAJAPUR',20),
(362,'SHEOPUR',20),
(363,'SHIVPURI',20),
(364,'SIDHI',20),
(365,'TIKAMGARH',20),
(366,'UJJAIN',20),
(367,'UMARIA',20),
(368,'VIDISHA',20),
(369,'Aizawal West',24),
(370,'AIZAWL East',24),
(371,'CHAMPHAI',24),
(372,'KOLASIB',24),
(373,'LAWNGTLAI',24),
(374,'LUNGLEI',24),
(375,'MAMIT',24),
(376,'SAIHA',24),
(377,'SERCHHIP',24),
(378,'DIMAPUR',25),
(379,'KIPHIRE',25),
(380,'KOHIMA',25),
(381,'LONGLENG',25),
(382,'MOKOKCHUNG',25),
(383,'MON',25),
(384,'PEREN',25),
(385,'PHEK',25),
(386,'TUENSANG',25),
(387,'WOKHA',25),
(388,'ZUNHEBOTO',25),
(389,'ANGUL',26),
(390,'BALANGIR',26),
(391,'BALESHWAR',26),
(392,'BARGARH',26),
(393,'BAUDH',26),
(394,'BHADRAK',26),
(395,'CUTTACK',26),
(396,'DEBAGARH',26),
(397,'DHENKANAL',26),
(398,'GAJAPATI',26),
(399,'GANJAM',26),
(400,'JAGATSINGHAPUR',26),
(401,'JAJPUR',26),
(402,'JHARSUGUDA',26),
(403,'KALAHANDI',26),
(404,'KANDHAMAL',26),
(405,'KENDRAPARA',26),
(406,'KEONJHAR',26),
(407,'KHURDA',26),
(408,'KORAPUT',26),
(409,'MALKANGIRI',26),
(410,'MAYURBHANJ',26),
(411,'NABARANGAPUR',26),
(412,'NAYAGARH',26),
(413,'NUAPADA',26),
(414,'PURI',26),
(415,'RAYAGADA',26),
(416,'SAMBALPUR',26),
(417,'SONAPUR / SUBARNAPUR',26),
(418,'SUNDARGARH',26),
(419,'PONDICHERRY',27),
(420,'AMRITSAR',28),
(421,'BATHINDA',28),
(422,'BARNALA',28),
(423,'FARIDKOT',28),
(424,'FATEGARH SAHIB',28),
(425,'FIROZPUR',28),
(426,'GURDASPUR',28),
(427,'HOSHIARPUR',28),
(428,'JALANDHAR',28),
(429,'KAPURTHALA',28),
(430,'LUDHIANA',28),
(431,'MANSA-PU',28),
(432,'MOGA',28),
(433,'MOHALI/SASNAGAR',28),
(434,'MUKATSAR',28),
(435,'NAWANSHAHR',28),
(436,'PATIALA',28),
(437,'RUPNAGAR/ROPAR',28),
(438,'SANGRUR',28),
(439,'TARN_TARAN',28),
(440,'AJMER',29),
(441,'ALWAR',29),
(442,'BANSWARA',29),
(443,'BARAN',29),
(444,'BARMER',29),
(445,'BHARATPUR',29),
(446,'BHILWARA',29),
(447,'BIKANER',29),
(448,'BUNDI',29),
(449,'CHITTAURGARH',29),
(450,'CHURU',29),
(451,'DAUSA',29),
(452,'DHAULPUR',29),
(453,'DUNGARPUR',29),
(454,'GANGANAGAR',29),
(455,'HANUMANGARH',29),
(456,'JAIPUR',29),
(457,'JAISALMER',29),
(458,'JALORE',29),
(459,'JHALAWAR',29),
(460,'JHUNJHUNUN',29),
(461,'JODHPUR',29),
(462,'KARAULI',29),
(463,'KOTA',29),
(464,'NAGAUR',29),
(465,'PALI',29),
(466,'PRATAPGARH',29),
(467,'RAJSAMAND',29),
(468,'SAWAI_MADHOPUR',29),
(469,'SIKAR',29),
(470,'SIROHI',29),
(471,'TONK',29),
(472,'UDAIPUR',29),
(473,'EAST',30),
(474,'NORTH',30),
(475,'SOUTH',30),
(476,'WEST',30),
(477,'KANCHEEPURAM',31),
(478,'SAIDAPET',31),
(479,'THIRUVALLORE',31),
(480,'POONAMALLEE',31),
(481,'VELLORE',31),
(482,'THIRUPPATTUR',31),
(483,'TIRUVANNAMALAI',31),
(484,'CHEYYAR',31),
(485,'CUDDALORE',31),
(486,'VILLUPURAM',31),
(487,'KALLAKURICHI',31),
(488,'THANJAVUR',31),
(489,'THIRUVARUR',31),
(490,'NAGAPATTINAM',31),
(491,'THIRUCHIRAPALLI',31),
(492,'KARUR',31),
(493,'PERAMBALUR',31),
(494,'PUDUKOTTAI',31),
(495,'ARANTHANGI',31),
(496,'MADURAI',31),
(497,'THENI',31),
(498,'DINDIGUL',31),
(499,'PALANI',31),
(500,'RAMANATHAPURAM',31),
(501,'PARAMAKUDI',31),
(502,'SIVAGANGA',31),
(503,'VIRUDHUNAGAR',31),
(504,'SIVAKASI',31),
(505,'THIRUNELVELI',31),
(506,'SANKARANKOIL',31),
(507,'THOOTHUKUDI',31),
(508,'KOVILPATTI',31),
(509,'NAGERCOIL',31),
(510,'SALEM',31),
(511,'NAMAKKAL',31),
(512,'DHARMAPURI',31),
(513,'KRISHNAGIRI',31),
(514,'COIMBATORE',31),
(515,'THIRUPPUR',31),
(516,'ERODE',31),
(517,'DHARAPURAM',31),
(518,'THE NILGIRIS',31),
(519,'CHENNAI CORP',31),
(520,'EAST /DHALAI TRIPURA',33),
(521,'NORTH_TRIPURA',33),
(522,'SOUTH_TRIPURA',33),
(523,'WEST_TRIPURA',33),
(524,'AGRA',34),
(525,'ALIGARH',34),
(526,'ALLAHABAD',34),
(527,'AMBEDKAR_NAGAR',34),
(528,'AURAIYA',34),
(529,'AZAMGARH',34),
(530,'BAGHPAT',34),
(531,'BAHRAICH',34),
(532,'BALLIA',34),
(533,'BALRAMPUR',34),
(534,'BANDA',34),
(535,'BARABANKI',34),
(536,'BAREILLY',34),
(537,'BASTI',34),
(538,'BIJNOR',34),
(539,'BUDAUN',34),
(540,'BULANDSHAHAR',34),
(541,'CHANDAULI',34),
(542,'CHITRAKOOT',34),
(543,'DEORIA',34),
(544,'ETAH',34),
(545,'ETAWAH',34),
(546,'FAIZABAD',34),
(547,'FARRUKHABAD',34),
(548,'FATEHPUR',34),
(549,'FIROZABAD',34),
(550,'GAUTAM_BUDH_NAGAR',34),
(551,'GHAZIABAD',34),
(552,'GHAZIPUR',34),
(553,'GONDA',34),
(554,'GORAKHPUR',34),
(555,'HAMIRPUR-UP',34),
(556,'HARDOI',34),
(557,'HATHRAS/MAHAMAYANAGAR',34),
(558,'JALAUN',34),
(559,'JAUNPUR',34),
(560,'JHANSI',34),
(561,'JYOTIBA_PHULE_NAGAR',34),
(562,'KANNAUJ',34),
(563,'KANPUR NAGAR',34),
(564,'KANPUR_DEHAT',34),
(565,'KAUSHAMBI',34),
(566,'KHERI',34),
(567,'KUSHINAGAR',34),
(568,'LALITPUR',34),
(569,'LUCKNOW',34),
(570,'MAHARAJGANJ',34),
(571,'MAHOBA',34),
(572,'MAINPURI',34),
(573,'MATHURA',34),
(574,'MAU',34),
(575,'MEERUT',34),
(576,'MIRZAPUR',34),
(577,'MORADABAD',34),
(578,'MUZAFFARNAGAR',34),
(579,'PILIBHIT',34),
(580,'PRATAPGARH',34),
(581,'RAEBARELI',34),
(582,'RAMPUR',34),
(583,'SAHARANPUR',34),
(584,'SANT_KABIR_NAGAR',34),
(585,'SANT_RAVIDAS_NAGAR',34),
(586,'SHAHJAHANPUR',34),
(587,'SHRAVASTI',34),
(588,'SIDDHARTHNAGAR',34),
(589,'SITAPUR',34),
(590,'SONBHADRA',34),
(591,'SULTANPUR',34),
(592,'UNNAO',34),
(593,'VARANASI',34),
(594,'ALMORA',35),
(595,'BAGESHWAR',35),
(596,'CHAMOLI',35),
(597,'CHAMPAWAT',35),
(598,'DEHRADUN',35),
(599,'PAURI GARHWAL',35),
(600,'HARDWAR',35),
(601,'NAINITAL',35),
(602,'PITHORAGARH',35),
(603,'RUDRAPRAYAG',35),
(604,'TEHRI_GARHWAL',35),
(605,'UDHAM SINGH NAGAR',35),
(606,'UTTARKASHI',35),
(607,'BANKURA',36),
(608,'BARDDHAMAN',36),
(609,'BIRBHUM',36),
(610,'COOCH BEHAR',36),
(611,'DAKSHIN_DINAJPUR',36),
(612,'DARJILING',36),
(613,'EAST MEDINIPUR',36),
(614,'HAORA / HOWRAH',36),
(615,'HUGLY',36),
(616,'JALPAIGURI',36),
(617,'KOLKATA',36),
(618,'MALDAH',36),
(619,'MURSHIDABAD',36),
(620,'NADIA',36),
(621,'NORTH_24_PARGANAS',36),
(622,'PURULIYA',36),
(623,'SOUTH_24_PARGANAS',36),
(624,'UTTAR_DINAJPUR',36),
(625,'WEST MEDNAPUR',36),
(626,'Mumbai',21),
(628,'Ambarnath',21),
(629,'Badlapur',21),
(630,'Ulhasnagar',21),
(631,'Vithalwadi',21),
(632,'Kalyan',21),
(633,'Thakurli',21),
(634,'Dombivali',21),
(635,'Kopar',21),
(636,'Kalwa',21),
(637,'Diva',21),
(638,'Kalwa',21),
(639,'Mulund',21),
(640,'Nahur',21),
(641,'Bhandup',21),
(642,'Kanjurmarg',21),
(643,'Vikhroli',21),
(644,'Ghatkopar',21),
(645,'Vidyavihar',21),
(646,'Kurla',21),
(647,'Sion',21),
(648,'Matunga',21),
(649,'Dadar',21),
(650,'Parel',21),
(651,'Currey Road',21),
(652,'Chinchpokli',21),
(653,'Byculla',21),
(654,'Sandhurst Road',21),
(655,'Masjid ',21);
/*!40000 ALTER TABLE `tbl_city` ENABLE KEYS */;

--
-- Table structure for table `tbl_coupon`
--

DROP TABLE IF EXISTS `tbl_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon` varchar(200) NOT NULL,
  `discount` int(11) NOT NULL,
  `type` enum('Service','Subscription') NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT 1,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_coupon`
--

/*!40000 ALTER TABLE `tbl_coupon` DISABLE KEYS */;
INSERT INTO `tbl_coupon` VALUES
(1,'test10',10,'Service',1,'2024-08-28 03:55:02'),
(2,'subs10',10,'Subscription',1,'2024-08-28 03:55:18'),
(3,'test abc',1000,'Service',1,'2025-06-16 10:14:35');
/*!40000 ALTER TABLE `tbl_coupon` ENABLE KEYS */;

--
-- Table structure for table `tbl_drop_images`
--

DROP TABLE IF EXISTS `tbl_drop_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_drop_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `image` varchar(150) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_drop_images`
--

/*!40000 ALTER TABLE `tbl_drop_images` DISABLE KEYS */;
INSERT INTO `tbl_drop_images` VALUES
(1,15,'temp3582019433584249921.jpg','2025-06-29 16:26:52');
/*!40000 ALTER TABLE `tbl_drop_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_drop_odometer_images`
--

DROP TABLE IF EXISTS `tbl_drop_odometer_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_drop_odometer_images` (
  `id` int(11) NOT NULL,
  `bookingId` int(11) NOT NULL,
  `reading` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_drop_odometer_images`
--

/*!40000 ALTER TABLE `tbl_drop_odometer_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_drop_odometer_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_enquiry`
--

DROP TABLE IF EXISTS `tbl_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phoneNumber` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_enquiry`
--

/*!40000 ALTER TABLE `tbl_enquiry` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_enquiry` ENABLE KEYS */;

--
-- Table structure for table `tbl_inspection`
--

DROP TABLE IF EXISTS `tbl_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_inspection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `vehicleId` int(11) NOT NULL,
  `vehicleType` varchar(100) NOT NULL,
  `make` varchar(150) NOT NULL,
  `model` varchar(150) NOT NULL,
  `variant` varchar(150) NOT NULL,
  `color` varchar(150) NOT NULL,
  `regNumber` varchar(150) NOT NULL,
  `rcAvailable` varchar(150) NOT NULL,
  `rcCondition` varchar(150) NOT NULL,
  `misMatched` tinyint(1) NOT NULL,
  `regState` varchar(150) NOT NULL,
  `regCity` varchar(150) NOT NULL,
  `rtoCity` varchar(150) NOT NULL,
  `noOfOwner` varchar(100) NOT NULL,
  `mgdMonthYear` varchar(150) NOT NULL,
  `regMonthYear` varchar(150) NOT NULL,
  `insurance` varchar(100) NOT NULL,
  `fitnessUpto` varchar(100) NOT NULL,
  `rtoNocIssued` tinyint(1) NOT NULL,
  `underHypothecation` tinyint(1) NOT NULL,
  `fuelType` varchar(100) NOT NULL,
  `drivernKm` varchar(100) NOT NULL,
  `chasisNumberEmbossing` varchar(100) NOT NULL,
  `roadTaxPaid` varchar(100) NOT NULL,
  `duplicateKey` varchar(100) NOT NULL,
  `toBeScrapped` tinyint(1) NOT NULL,
  `ownershipDetail` varchar(100) NOT NULL,
  `cnglpgFitmentRc` varchar(100) NOT NULL,
  `cngFitnessPlate` varchar(100) NOT NULL,
  `cngCertificate` tinyint(1) NOT NULL,
  `insuranceValidity` varchar(100) NOT NULL,
  `pucValidity` varchar(100) NOT NULL,
  `userServiceManual` tinyint(1) NOT NULL,
  `vinChasisPlate` tinyint(1) NOT NULL,
  `chasisNumber` varchar(150) NOT NULL,
  `engineNumber` varchar(150) NOT NULL,
  `purchasingInvoice` varchar(100) NOT NULL,
  `bankNocForm35` varchar(150) NOT NULL,
  `roadTaxValidity` varchar(100) NOT NULL,
  `permit` varchar(150) NOT NULL,
  `batteryWarrantyCard` varchar(100) NOT NULL,
  `bumperFront` varchar(100) NOT NULL,
  `bumperRear` varchar(100) NOT NULL,
  `bonetHood` varchar(100) NOT NULL,
  `frontWindsheild` varchar(100) NOT NULL,
  `rearWindSheild` varchar(100) NOT NULL,
  `fendorLeft` varchar(100) NOT NULL,
  `fendorRight` varchar(100) NOT NULL,
  `doorRhsFront` varchar(100) NOT NULL,
  `doorRhsRear` varchar(100) NOT NULL,
  `doorLhsFront` varchar(100) NOT NULL,
  `doorLhsRear` varchar(100) NOT NULL,
  `dickyDoor` varchar(100) NOT NULL,
  `dickyShockAbsorber` varchar(100) NOT NULL,
  `bootSpace` varchar(100) NOT NULL,
  `roofTop` varchar(100) NOT NULL,
  `lhPillarA` varchar(100) NOT NULL,
  `lhPillarB` varchar(100) NOT NULL,
  `lhPillarC` varchar(100) NOT NULL,
  `rhPillarA` varchar(100) NOT NULL,
  `rhPillarB` varchar(100) NOT NULL,
  `rhPillarC` varchar(100) NOT NULL,
  `runningBoardLhs` varchar(100) NOT NULL,
  `runningBoardRhs` varchar(100) NOT NULL,
  `lhQuaterPanel` varchar(100) NOT NULL,
  `rhQuaterPanel` varchar(100) NOT NULL,
  `lhApron` varchar(100) NOT NULL,
  `rhApron` varchar(100) NOT NULL,
  `firewall` varchar(100) NOT NULL,
  `cowlTop` varchar(100) NOT NULL,
  `lowerCrossMember` varchar(100) NOT NULL,
  `upperCrossMember` varchar(100) NOT NULL,
  `headlightSupport` varchar(100) NOT NULL,
  `readiotorSupport` varchar(100) NOT NULL,
  `frontShowGrill` varchar(100) NOT NULL,
  `bumperGrill` varchar(100) NOT NULL,
  `orvmLh` varchar(100) NOT NULL,
  `orvmRh` varchar(100) NOT NULL,
  `headlightLh` varchar(100) NOT NULL,
  `headlightRh` varchar(100) NOT NULL,
  `fogLightLh` varchar(100) NOT NULL,
  `fogLightRh` varchar(100) NOT NULL,
  `tailLightLh` varchar(100) NOT NULL,
  `tailLightRh` varchar(100) NOT NULL,
  `tyreFlh` varchar(100) NOT NULL,
  `tyreRlh` varchar(100) NOT NULL,
  `tyreRrh` varchar(100) NOT NULL,
  `tyreFrh` varchar(100) NOT NULL,
  `spareTyre` varchar(100) NOT NULL,
  `alloyWheels` varchar(100) NOT NULL,
  `roofRailCarrier` varchar(100) NOT NULL,
  `roofLuggageCarrier` varchar(100) NOT NULL,
  `suspension` varchar(100) NOT NULL,
  `axel` varchar(100) NOT NULL,
  `commentexterior` text NOT NULL,
  `interior` varchar(100) NOT NULL,
  `noOfPowerWindows` varchar(100) NOT NULL,
  `powerWindowFlh` varchar(100) NOT NULL,
  `powerWindowRlh` varchar(100) NOT NULL,
  `powerWindowFrh` varchar(100) NOT NULL,
  `powerWindowRrh` varchar(100) NOT NULL,
  `musicSystem` varchar(100) NOT NULL,
  `normalSpeakers` varchar(100) NOT NULL,
  `steeringMountAudioControl` varchar(100) NOT NULL,
  `frontWiper` varchar(100) NOT NULL,
  `rearWiper` varchar(100) NOT NULL,
  `wiperWaterSpray` varchar(100) NOT NULL,
  `rearDefogger` varchar(100) NOT NULL,
  `rearCamera` varchar(100) NOT NULL,
  `parkingSensor` varchar(100) NOT NULL,
  `360Camera` varchar(100) NOT NULL,
  `abs` varchar(100) NOT NULL,
  `gps` varchar(100) NOT NULL,
  `selfStarter` varchar(100) NOT NULL,
  `alternator` varchar(100) NOT NULL,
  `centerLocking` varchar(100) NOT NULL,
  `horn` varchar(100) NOT NULL,
  `signalSwitchKnob` varchar(100) NOT NULL,
  `sunroofMoonroof` varchar(100) NOT NULL,
  `pushButton` varchar(100) NOT NULL,
  `dashboard` varchar(100) NOT NULL,
  `odometer` varchar(100) NOT NULL,
  `gloveBox` varchar(100) NOT NULL,
  `roofTopExtr` varchar(100) NOT NULL,
  `seat` varchar(100) NOT NULL,
  `seatAdjustment` varchar(100) NOT NULL,
  `seatBelt` varchar(100) NOT NULL,
  `floorMat` varchar(100) NOT NULL,
  `cruzeControl` varchar(100) NOT NULL,
  `acVentilation` varchar(100) NOT NULL,
  `climateControlAc` varchar(100) NOT NULL,
  `flooded` varchar(100) NOT NULL,
  `noOfAirbags` varchar(100) NOT NULL,
  `transmissionType` varchar(100) NOT NULL,
  `engineSound` varchar(100) NOT NULL,
  `engine` varchar(100) NOT NULL,
  `engineOil` varchar(100) NOT NULL,
  `gearOil` varchar(100) NOT NULL,
  `breakOil` varchar(100) NOT NULL,
  `clutchOil` varchar(100) NOT NULL,
  `radiator` varchar(100) NOT NULL,
  `coolant` varchar(100) NOT NULL,
  `engineMounting` varchar(100) NOT NULL,
  `enginerCover` varchar(100) NOT NULL,
  `engineBackCompression` varchar(100) NOT NULL,
  `battery` varchar(100) NOT NULL,
  `exahuast` varchar(100) NOT NULL,
  `exahuastCatalyticConverter` varchar(100) NOT NULL,
  `gearShiting` varchar(100) NOT NULL,
  `exterior_remark` varchar(200) NOT NULL,
  `clutch` varchar(100) NOT NULL,
  `break` varchar(100) NOT NULL,
  `steering` varchar(100) NOT NULL,
  `comments` text NOT NULL,
  `addtionalFitting` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_inspection`
--

/*!40000 ALTER TABLE `tbl_inspection` DISABLE KEYS */;
INSERT INTO `tbl_inspection` VALUES
(1,9,9,'PRIVATE','6','4','czx','csdzx','','','',0,'','','','','','','','',0,0,'','','','','',0,'Individual','','',0,'2025-06-12','2025-06-11',0,0,'1478259635','14785236','','','OTT','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','Available','Available','','','czxcs','','1','Working','Working','Working','Working','Working','Working','Working','Working','Working','Working','Available','Available','Available','Available','Yes','Available','Working','Working','Working','Working','Working','N/A','Working','Scratched','Scratched','Working','Damaged','Torn','Working','1','Dirty','N/A','Front-Damaged','','','1','Manual','','','','','','','','','','Available','Back Compression Exist','','','No','','zxcsz','','','','Starter motor / solenoid malfunctioning','Extra Bass / Woofer Speaker','2025-06-29 05:03:04','2025-06-29 05:04:03');
/*!40000 ALTER TABLE `tbl_inspection` ENABLE KEYS */;

--
-- Table structure for table `tbl_mp_custom_enquiry`
--

DROP TABLE IF EXISTS `tbl_mp_custom_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mp_custom_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `category_id` text NOT NULL,
  `brand_id` text NOT NULL,
  `model_id` text NOT NULL,
  `ownership` varchar(100) NOT NULL,
  `price` varchar(200) NOT NULL,
  `priceFrom` varchar(200) NOT NULL,
  `priceToo` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `hide` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mp_custom_enquiry`
--

/*!40000 ALTER TABLE `tbl_mp_custom_enquiry` DISABLE KEYS */;
INSERT INTO `tbl_mp_custom_enquiry` VALUES
(20,8,'[\"2\"]','[\"8\"]','[]','[]','','00','2500000','','308','Enquired',0,'2024-07-30 09:54:22','2024-07-30 09:54:22'),
(21,10,'[\"2\"]','[]','[]','[\"1\",\"2\",\"3\",\"4\"]','','','5005753','','598','Enquired',0,'2024-08-12 15:38:53','2024-08-12 15:38:53'),
(22,4,'[\"2\"]','[\"8\"]','[\"46\"]','[\"1\",\"2\"]','','200000','250000','need clean car','308','Enquired',0,'2024-09-05 07:42:00','2024-09-05 07:42:00'),
(23,15,'[]','[]','[]','[\"1\"]','','00','2500000','','601','Enquired',0,'2025-07-01 08:04:04','2025-07-01 08:04:04');
/*!40000 ALTER TABLE `tbl_mp_custom_enquiry` ENABLE KEYS */;

--
-- Table structure for table `tbl_mp_vehicle`
--

DROP TABLE IF EXISTS `tbl_mp_vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mp_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` text DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `listingtype` varchar(150) NOT NULL,
  `regno` varchar(150) NOT NULL,
  `transmission` varchar(150) NOT NULL,
  `insurance` varchar(100) NOT NULL,
  `insurancedate` varchar(200) DEFAULT NULL,
  `ownership` varchar(100) NOT NULL,
  `vcondition` varchar(100) NOT NULL,
  `variant` varchar(100) NOT NULL,
  `state` int(11) DEFAULT NULL,
  `rto` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `kms` varchar(100) NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount_percent` int(11) DEFAULT NULL,
  `discount_price` decimal(10,0) DEFAULT NULL,
  `rc_availability` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `features` text NOT NULL,
  `fuel_type` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `status` varchar(100) NOT NULL,
  `added_by` tinyint(4) NOT NULL,
  `added_type` varchar(100) NOT NULL,
  `hide` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mp_vehicle`
--

/*!40000 ALTER TABLE `tbl_mp_vehicle` DISABLE KEYS */;
INSERT INTO `tbl_mp_vehicle` VALUES
(6,'',2,8,24,'std','MH03BJ6031','Manual','','0000-00-00','2','Used','Yuva',21,'Mumbai','1997','190209','',308,700000,0,0,'','20240503_082527.jpg','Bshjdjd','Vdbdbb','Petrol',1,'Pending',7,'USER',0,'2024-06-07 12:33:56','2025-01-25 04:33:51'),
(9,'',2,8,36,'stc','MH31EA4432','Manual','','0000-00-00','1','Used','LXI',21,'NAGPUR','2008','99883','',301,80000,0,0,'','WhatsApp_Image_2024-06-07_at_2_23_15_PM_(1).jpeg','Non-Accidental ','XX','Petrol',0,'Pending',8,'DEALER',0,'2024-06-07 13:10:48','2025-04-28 12:27:45'),
(10,'',2,7,11,'stc','MH12LD612211','Manual','','0000-00-00','1','Used','Era plus',21,'Pune','2015','38850','',308,150000,0,0,'','WhatsApp_Image_2024-06-06_at_1_02_04_PM_(1).jpeg','xxxxx','xx','Petrol',0,'Pending',8,'DEALER',0,'2024-06-07 13:29:16','2025-04-28 12:27:43'),
(15,'',2,8,863,'stc','MH03BH7978','Manual','','0000-00-00','2','Used','Vxi',21,'Mumbai','2013','88000','',626,250000,0,0,'','IMG-20240611-WA0036.jpg','Non accidental, \r\nToch screen music system,\r\nWindshield crack,\r\nTake and drive.','Andheri','Petrol',0,'Pending',4,'DEALER',0,'2024-06-11 07:28:57','2024-11-06 03:00:30'),
(17,'',2,8,1113,'std','MH12','Manual','','0000-00-00','1','Used','Delta petrol',21,'Pune ','2018','72000','',301,620000,0,0,'','IMG-20240525-WA0098.jpg','maruti suzuki Baleno Delta pure petrol.\r\n1st owner insurance vallid.\r\n','Hadapsar pune','Petrol',1,'Pending',11,'DEALER',0,'2024-06-13 14:05:00','2024-06-13 14:05:00'),
(21,'',2,11,108,'stc','GA05D0077-1','Automatic','','0000-00-00','1','Used','320d',11,'PONDA RTO','2011','77991','',137,750000,0,0,'','WhatsApp_Image_2024-06-22_at_1_04_19_PM3.jpeg','well maintained, with service record','Near IDC Circle, Kundain, Ponda, Goa','Diesel',0,'Pending',8,'DEALER',0,'2024-06-22 07:46:23','2025-04-28 12:27:41'),
(26,'',2,8,510,'std','MH01XX','Manual','','0000-00-00','1','Used','VDI MT',21,'Mumbai','2018','96816','',308,550000,0,0,'','WhatsApp_Image_2024-06-25_at_08_22_31.jpeg','Non-Accidental ','Shop No.3, Cardiction, Hari Shrushti, Badlapur West, Thane 421503','Diesel',0,'Sold',3,'DEALER',0,'2024-06-25 09:46:18','2024-07-24 08:38:15'),
(36,'',2,15,702,'std','Mh122014','Manual','','0000-00-00','','Used','XYZ',21,'thane','2014','90000','Ramesh wadi , tilakanagar , Ganesh chowk thane Maharashtra',626,1200000,0,0,'','temp_17208754763767643946843700229941.jpg','first class\nexterior interior work','','Petrol',0,'Pending',3,'DEALER',0,'2024-07-13 12:58:30','2024-07-26 06:33:41'),
(37,'',2,8,1113,'std','mh05','Manual','','0000-00-00','','Used','Delta petrol',21,'kalyan','2019','284398','station road, near MG school, ambernath west, thane',308,586425,0,0,'','temp_17208772864783097993180479750549.jpg','good car','','Petrol',0,'Pending',8,'DEALER',0,'2024-07-13 13:02:40','2025-04-28 12:27:39'),
(38,'',2,7,23,'std','mh12..','Manual','','0000-00-00','2','Used','vista',21,'jharkhand','2014','66117','kalyan badlapur road , near reliance petrol pump , vadvali',628,300000,0,0,'','temp_17210971807267985810690927694391.jpg','Non - Accidental\nOne handed use','','Petrol',0,'Sold',3,'DEALER',0,'2024-07-16 02:34:03','2024-08-12 12:07:16'),
(46,'',2,28,225,'std','mh02','Manual','','0000-00-00','','Used','G',21,'mumbai','2011','50000','samarth nagar rameshwadi badlapur west',298,240000,0,0,'','temp_17211226710155826566677997367640.jpg','well maintained car \nfinal rate','','Petrol',0,'Pending',4,'DEALER',0,'2024-07-16 09:40:00','2024-11-06 03:00:28'),
(47,'',2,7,1032,'std','Mhxxx','Manual','','','','Used','SX',21,'Kalyan','2019','52876','1234,durgadi road, khadakpada',632,550000,0,0,'','temp_17211303736214099044035556397892.jpg','good condition car.','','Petrol',0,'Pending',8,'DEALER',0,'2024-07-16 11:46:46','2025-04-28 12:27:36'),
(48,'',2,18,1003,'std','MH46','Manual','Yes','27 Jul 2025','1','Used','HTX+',21,'panvel','2021','41000','goregaon west',626,1395000,0,0,'','temp_1721224430616627224377328295275.jpg','- 3 pieces need touch up\n- company alloy wheels \n- with sunroof\n- insurance valid\n-','','Diesel',0,'Pending',4,'DEALER',0,'2024-07-17 13:55:40','2024-11-06 03:00:27'),
(49,'',2,8,326,'std','MH01','Manual','Yes','2025-07-25','1','Used','Vxi',21,'Andheri ','2013','50000','',626,150000,0,0,'','IMG-20240717-WA0342.jpg','Over coat required ','Near fountain hotel Mira bhayander ghodbander road ','Petrol',0,'Pending',4,'DEALER',0,'2024-07-17 14:50:48','2024-11-06 02:59:40'),
(50,'',2,8,963,'std','Mh04gj9132','Manual','Yes','2025-05-01','2','Used','Vxi cng',21,'Thane','2014','85000','',628,590000,0,0,'','IMG-20240718-WA0001.jpg','In good condition no work required \r\nJust take n drive \r\n','Matka chowk old bhendi pada Ambernath west','Petrol + CNG',1,'Pending',31,'DEALER',0,'2024-07-18 06:28:39','2024-07-18 06:28:39'),
(55,'',2,19,600,'stc','MH46BA9200','Manual','','0000-00-00','','Used','Mahindra Thar 4×4, 2017 , 2Nd Owner km-51k Diesel Engine Manual Transmission Insurance Valid Mint Co',21,'Amravati','2017','51000','Vikhroli West',626,649000,0,0,'','','Mahindra Thar 4×4\nDiesel Engine\nManual Transmission\n2017\n2nd Owner\nKm-51k\nInsurance Valid\nPower Steering\nChilled AC\nExtra Fitting\nHard Top\nAndroid System\nNeat N Clean Interior\nNo Work Required\nCar In Beautiful Condition.','','Diesel',0,'Pending',37,'DEALER',0,'2024-07-19 07:12:54','2024-07-22 07:04:02'),
(56,'',2,7,1172,'std','MH02FJ3117','Automatic','No','0000-00-00','1','Used','Hyundai Creta SX Top Model Push Button Sunroof Automatic Transmission Sequential CNG Fitted Km-103K ',21,'Mh03','2020','103000','Vikhroli West',626,1099000,0,0,'','','Hyundai Creta SX (O) \nPush Button Start\nSunroof\nAutomatic Transmission\n2020\nSingle Owner\nKm-103k With Service Record\nSequential CNG Fitted\nNeat N Clean Interior\nAuto Mirror\nPower Windows\nPower Steering\nAudio Control\nChilled AC\nLook Like New Tyres\nCompany Fitted Magwheel\nCar In Mint Condition.','','CNG',1,'Pending',37,'DEALER',0,'2024-07-19 07:23:52','2024-07-19 07:23:52'),
(57,'',2,8,1113,'stc','MH43CG0212','Automatic','','0000-00-00','','Used','Zeta',21,'Vashi','2023','15000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan West',632,875000,0,0,'','temp_17213767357166488181449151049998.jpg','Certified pre-owned car, loan facility available, Exchange facility available,','','Petrol',1,'Pending',39,'DEALER',0,'2024-07-19 08:20:56','2024-07-19 10:33:39'),
(58,'',2,8,429,'stc','MH03DX3617','Manual','','0000-00-00','','Used','VXI Green',21,'Ghatkopar','2022','7000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan West',632,825000,0,0,'','temp_17213779422907244158510779119755.jpg','Certified pre-owned vehicles, loan facility available, exchange facility available','','CNG',1,'Pending',39,'DEALER',0,'2024-07-19 08:45:03','2024-07-19 10:33:39'),
(59,'',2,7,519,'stc','MH05CV8938','Manual','Yes','0000-00-00','1','Used','S',21,'Kalyan','2017','33000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,545000,0,0,'','temp_17213810050925006993985969680114.jpg','Certified pre-owned car, loan facility available, exchange facility available','','Petrol',1,'Pending',39,'DEALER',0,'2024-07-19 09:24:09','2024-07-19 09:24:09'),
(60,'',2,7,409,'stc','MH14JE1502','Manual','No','0000-00-00','2','Used','S Green',21,'Pune','2020','40000','shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,630000,0,0,'','temp_17213813483186756239400465211222.jpg','Certified pre-owned car, loan facility available, exchange facility available','','CNG',1,'Pending',39,'DEALER',0,'2024-07-19 09:29:37','2024-07-19 09:29:37'),
(61,'',2,8,48,'stc','MH01BK6163','Manual','Yes','0000-00-00','2','Used','ZXI',21,'Kalyan','2010','47000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,195000,0,0,'','temp_17213817910926634320121893206883.jpg','Certified pre-owned car,','','Petrol',1,'Pending',39,'DEALER',0,'2024-07-19 09:37:05','2024-07-19 10:34:26'),
(62,'',2,7,1222,'stc','MH12UN4143','Manual','Yes','0000-00-00','1','Used','Sports Green',21,'Pune','2022','25000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,725000,0,0,'','temp_17213825008595713283958981415620.jpg','Certified pre-owned car, loan facility available, exchange facility available','','CNG',1,'Pending',39,'DEALER',0,'2024-07-19 09:48:53','2024-07-19 09:48:53'),
(63,'',2,8,963,'stc','MH03DG2540','Manual','Yes','0000-00-00','1','Used','VXI Green',21,'Ghatkopar','2019','41000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,1035000,0,0,'','temp_17213834356386760755428750469522.jpg','Certified pre-owned car, loan facility available, exchange facility available','','CNG',1,'Pending',39,'DEALER',0,'2024-07-19 10:04:37','2024-07-19 10:04:37'),
(64,'',2,8,963,'stc','MH0505EJ8281','Manual','Yes','0000-00-00','1','Used','VXI Green',21,'Kalyan','2021','33000','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,1125000,0,0,'','temp_1721384668449537077580053421269.jpg','Certified pre-owned car, loan facility available, exchange facility available','','CNG',1,'Pending',39,'DEALER',0,'2024-07-19 10:25:03','2024-07-19 10:34:22'),
(65,'',2,8,963,'stc','MH04LH3670','Manual','Yes','0000-00-00','1','Used','VXI Green',21,'Thane','2022','9900','Shiv Shankar Motors Shop no 1 Kashinath Apartment near Sai Mahadev Dhaba Khadakpada circle Kalyan',632,1190000,0,0,'','temp_17213850558032527440777451138530.jpg','Certified pre-owned car, loan facility available, exchange facility available','','CNG',1,'Pending',39,'DEALER',0,'2024-07-19 10:32:47','2024-07-19 10:34:21'),
(66,'',2,8,963,'stc','MH03','Manual','Yes','2025-05-28','2','Used','Suv',21,'MH03','2015','34000','',632,700000,0,0,'','0FC80FBB-6D7F-4FAD-8A12-A96EA5C23EF9.jpeg','Just tak @ Drvi','Khadakpada Kalyan w','Diesel',1,'Pending',40,'DEALER',0,'2024-07-20 09:44:49','2024-08-12 16:41:03'),
(67,'',2,8,32,'stc','MH04','Manual','Yes','2025-03-20','1','Used','Hasbag',21,'Thane','2016','64000','',632,200000,0,0,'','1bc0ad50-86f3-4fde-b736-10cb10b959af.jpeg','Used for only ladies ','Khadakpada ','Petrol + CNG',1,'Pending',40,'DEALER',0,'2024-07-20 10:01:31','2024-08-12 16:41:07'),
(68,'',2,7,1172,'stc','MH48','Manual','Yes','2025-03-19','1','Used','Used',21,'Vasai','2022','43000','',632,170000,0,0,'','IMG_2641.jpeg','Car just like new','Khadakpada ','Diesel',1,'Pending',40,'DEALER',0,'2024-07-20 10:07:58','2024-07-20 10:07:58'),
(69,'',2,14,523,'stc','MH 04','Manual','Yes','2024-11-14','1','Used','Suv',21,'MH04','2016','74000','',632,600000,0,0,'','d4251c2e-ff41-4074-9e8d-c82ac97267bc2.jpeg','Just Tak & drvi','Khadakpada ','Diesel',1,'Pending',40,'DEALER',0,'2024-07-20 11:50:06','2024-08-12 16:41:12'),
(70,'',2,8,51,'stc','MH 48','Manual','Yes','2025-02-21','1','New','Cng',21,'MH 48','2022','34000','',632,600000,0,0,'','F5221A30-DE5C-4359-B502-289B9CDC1AB63.jpeg','Just like new tip','Khadakpada ','Petrol + CNG',1,'Pending',40,'DEALER',0,'2024-07-20 11:57:50','2024-08-12 16:41:13'),
(71,'',2,8,51,'stc','MH 02','Manual','Yes','2024-11-21','1','Used','Usd',21,'MH 02','2018','64009','',632,400000,0,0,'','6740823f-efc8-42cc-8878-c3f22e74ddfd.jpeg','One hand car','Khadakpada ','Petrol + CNG',1,'Pending',40,'DEALER',0,'2024-07-20 12:01:20','2024-08-12 16:41:14'),
(77,'',2,28,233,'stc','MH06BE8998','Manual','No','0000-00-00','2','Used','Innova G Model 8 Seater 2013, 2nd Owner Diesel Engine Manual Transmission Power Windows Power Steeri',21,'Thane','2013','142000','Vikhroli West',626,699000,0,0,'','','Toyota Innova G Model\n8 Seater\n2013\n2nd Owner\nkm-142k\nDiesel Engine\nManual Transmission\nPower Windows\nPower Steering\nChilled Dual AC\nlook Like New Tyres\nNew Seat Covers\nflooring Laminated\nWodden Finishing\nAndroid System\ncar In Mint Condition.','','Diesel',1,'Pending',37,'DEALER',0,'2024-07-22 06:35:30','2024-07-22 06:35:30'),
(78,'',2,15,126,'stc','MH12KT0681','Automatic','Yes','0000-00-00','2','Used','Honda Accord 2.4 AT Petrol Engine Automatic Transmission 2014, 2nd Owner Insurance Valid Sunroof Nea',21,'Pinpri Chinchwad','2014','91000','Vikhroli West',626,499000,0,0,'','','Honda Accord 2.4 AT\nPetrol Engine\nAutomatic Transmission\n2014\n2nd Owner\nKm-91k\nInsurance Valid\nAuto Mirror\nPower Windows\nPower Steering\nAudio Control\nChilled Dual AC\nLook Like New Tyres\nSoundless Engine\nSmooth Suspension\nNeat N Clean Interior\nCar In Mint Condition.','','Petrol',1,'Pending',37,'DEALER',0,'2024-07-22 06:42:40','2024-07-22 06:42:40'),
(79,'',2,7,52,'stc','MH43AW0014','Automatic','Yes','0000-00-00','1','Used','Hyundai Santa Fe 2WD AT, 2015 Single Owner km-67k Diesel Engine Automatic Transmission 7 Seater Mint',21,'Vashi','2015','67000','Vikhroli West',643,849000,0,0,'','','Hyundai Santa Fe 2WD\nAutomatic Transmission\nDiesel Engine\n7Seater\n2015 Nov\nSingle Owner\nKm-67k\nAuto Mirror\nPower Windows\nPower Steering\nAudio Control\nChilled Dual AC\nlook Like New Tyres\nCompany Fitted Magwheel\nNew Seat Covers\nCar In Nxt To Showroom Condition.','','Diesel',1,'Pending',37,'DEALER',0,'2024-07-22 07:03:29','2024-07-22 07:03:29'),
(90,'VA2407280009',2,8,429,'stc','MH02CH7083','Manual','Yes','23 February 2025','1','Used','Zdi Model Diesel Engine',21,'MH02','2012','90000','Vikhroli West',643,399000,0,0,'','temp_17221715163307710582674008429718.jpg','Swift Dzire ZDI Model\n2012\nSingle Owner\nkm-90k\nInsurance Valid\nDiesel Engine\nManual Transmission\nPower Windows\nPower Steering\nChilled AC\nLook Like New Tyres\nSoundless Engine\nSmooth Suspension\nNeat N Clean Interior\nCar In Mint Condition. \nLocation- Vikhroli West','','Diesel',1,'Pending',37,'DEALER',0,'2024-07-28 12:59:17','2024-08-02 06:44:22'),
(91,'VA2407300010',2,8,963,'std','MH03BH2076','Manual','Yes','08 Oct 2024','1','Used','vxi cng',21,'mh03','2012','69000','mumund west',639,495000,0,0,'','temp_17223274833087554702216288098194.jpg','call now for best offer','','Petrol+CNG',1,'Pending',49,'DEALER',0,'2024-07-30 08:17:56','2024-08-02 06:44:36'),
(92,'VA2407300011',2,8,863,'std','mh12tk0860','Automatic','No','','1','Used','vxi',21,'pune','2021','45000','Ashford royal bmc parking',639,670000,0,0,'','temp_17223335830676655167506891049413.jpg','very good condition car','','Petrol',1,'Pending',50,'DEALER',0,'2024-07-30 10:02:12','2024-08-02 06:44:53'),
(93,'VA2407300012',2,8,32,'std','mh04kw7846','Manual','No','','1','Used','alto',21,'thane','2021','57500','Ashford royal bmc parking nahur west',626,430000,0,0,'','temp_17223339630002884261391318387903.jpg','alto cng good condition car','','Petrol+CNG',1,'Pending',50,'DEALER',0,'2024-07-30 10:09:09','2024-08-02 06:44:57'),
(94,'VA2407310003',2,23,1272,'stc','mh05ev6272','Manual','Yes','30 November 2024','1','Used','Xe',21,'kalyan','2022','26000','Sonarpafs',634,565000,0,0,'','','Mint Condition Car','','Petrol',1,'Pending',47,'DEALER',0,'2024-07-31 03:38:58','2024-08-02 06:45:06'),
(95,'VA2408120001',2,7,1126,'std','hemant thakkar','Automatic','Yes','24 Aug 2025','1','Used','asta',21,'MH','2014','395000','Thane',308,395000,0,0,'','temp_17234629561902645041048155255661.jpg','*????Make* -Hyundai \n*????Name* - i10\n*⛽Fuel* - petrol \n*????Model* -  23/7/2014\n*♈Variant* - grand asta1.2\n*????????Owner* -2\n*☑Transmission Type* - automatic \nInsurance = 28/7/25\n *Kilometre* - 53133\n*⚪Colour* - t blue \n*®️Passing*- MH 01\nA      ???? *Additional Information -* ????\n\n*Price \n395000/-* negotiable sighlighty','','Petrol',1,'Pending',55,'DEALER',0,'2024-08-12 11:46:00','2024-08-12 11:46:00'),
(97,'VA2408130001',2,15,125,'stc','MH12HV6826','Manual','No','2024-07-12','1','Used','Smt',21,'Pimpri chinchwad','2012','65000','',298,285000,0,0,'','d8da177d-3cc2-48f3-8e9f-f8529a26a988.jpeg','*HONDA BRIO SMT*\r\n*PETROL 2012 MH12*\r\n\r\n*MAKE - HONDA*\r\n*MODEL - BRIO*\r\n*VARIENT - SMT*\r\n*YEAR -APRIL 2012*\r\n*SR. OWNER - SINGLE*\r\n*INSURANCE- NIL*\r\n*COLOUR -WHITE*\r\n*PASSING - MH 12*\r\n*KILOMETER - 65000*\r\n*FUEL TYPE -PETROL*\r\n*TRANSMISSION - MANUAL*\r\n\r\n*PRICE - 2,85,000/-*\r\n *(SLIGHTLY NEGOTIABLE)*','Mumbai naka','Petrol',1,'Pending',58,'DEALER',0,'2024-08-13 07:10:39','2024-08-13 07:10:39'),
(98,'VA2408160002',2,34,277,'std','MH 01 DE ****','Automatic','','27 Jun 2025','1','Used','Discovery sport 2.0',21,'MH 01','2019','7900','Thane',626,5250000,0,0,'','','????????????\nNEW ARRIVAL \nLAND ROVER\nDISCOVERY SPORTS 2.0\n7-SEATER \nYEAR-2019\n1ST OWNER \nDIESEL\nONLY-7500-KM DRIVEN WITH SERVICE RECORD \nINSURANCE VALID \nLOAN AVAILABLE UPTO 90%\n1year engine gear box warranty \n2services free\n1year road side assistance \nAt the time of delivery interior exterior detailing','','Diesel',1,'Sold',56,'DEALER',0,'2024-08-16 10:37:45','2024-11-26 15:54:26'),
(99,'VA2408160009',2,15,134,'std','MH 47 AG ****','Manual','Yes','19 Aug 2024','1','Used','1.5 V',21,'MH 47','2018','51000','Andheri',308,850000,0,0,'','','????????????\nNEW ARRIVAL\nHONDA BRV V-MT \n2018\n1ST OWNER \n50K DRIVEN WITH SERVICE RECORD \nFUEL-PETROL\nINSURANCE EXPIRED \nRECENTLY SERVICE DONE FROM HONDA\nALL 4 NEW TYRES\nLOAN AVAILABLE UPTO 90%\nFREE RSA AVAILABLE FOR ONE YEAR','','Petrol',1,'Sold',56,'DEALER',0,'2024-08-16 11:01:39','2024-11-26 15:54:19'),
(100,'VA2408160001',2,7,23,'std','MH43AJ9611','Automatic','No','04 Aug 2024','2','Used','Aastha',21,'Vasai','2012','69000','Thane',626,180000,0,0,'','','i 20 Hyundai good condition second owner automatic good condition well maintain','','Petrol+CNG',1,'Pending',73,'DEALER',0,'2024-08-16 15:24:37','2024-08-16 15:24:37'),
(107,'VA2408230001',2,27,282,'stc','32131245','Manual','Yes','2024-08-23','2','New','xe',19,'delhi','1111','1111111','',271,321465,0,0,'','car2.jpg','asdasd asd asd as','asdasdasd','Diesel',0,'Pending',1,'DEALER',0,'2024-08-23 06:18:58','2025-04-07 15:02:59'),
(111,'VA2408280001',2,27,282,'std','testsagar','Manual','Yes','28 Aug 2024','1','New','exi',11,'shahba','2824','12221212','testts',137,120000,10,108000,'','temp_17248280975848957568129655038016.jpg','tetsttss bhshshs hshsha jajaj','','Petrol',0,'Pending',1,'DEALER',0,'2024-08-28 06:55:58','2025-04-05 14:53:42'),
(112,'VA2408280006',2,8,394,'std','MH05BJ','Manual','Yes','23 Nov 2024','3','Used','LDI',21,'Kalyan','2016','1750000','3, Hari shrushti, church road.',628,280000,0,280000,'','temp_17248308441587826426942818897386.jpg','Outside Fitted Touch Music System and speaker.','','Diesel',1,'Pending',74,'USER',0,'2024-08-28 07:42:13','2024-09-16 06:15:21'),
(118,'VA21002666',2,8,46,'stc','MH05BS0219','Manual','','30 Dec 2024','1','Used','LXI CNG',21,'Kalyan RTO','2013','97315','3, Hari Shrushti, church road, Rameshwadi,',629,230000,0,230000,'','temp_17250046599243681171187057345687.jpg','Non Accidental','','Petrol+CNG',0,'Pending',8,'DEALER',0,'2024-08-30 07:59:56','2025-04-28 12:27:33'),
(121,'VA62544210',2,7,409,'std','MH04xxx','Automatic','No','','2','Used','AMT Kappa SX+',21,'Kalyan Rto','2020','25605','3,Hari Shrushti, church road,',629,550000,1,544500,'','temp_17255195234688972294235400909299.jpg','Car in good condition','','Petrol',0,'Pending',8,'DEALER',0,'2024-09-05 07:01:00','2025-04-28 12:27:31'),
(122,'VA74102076',2,14,141,'std','fhcnb','Manual','No','','1','Used','vjn',21,'bhandara','2024','100000','gbbj',284,100000,5,95000,'','temp_17258757618137460726311532864457.jpg','gjchv\njcvjvi\nbhchchv\nhguvu\nugfuv','','Petrol',0,'Pending',8,'DEALER',0,'2024-09-09 09:56:18','2025-04-28 12:27:29'),
(123,'VA36824599',2,6,6,'std','asd11','Manual','Yes','09 Sep 2024','1','New','EX',2,'Delhi','1222','213456','sdsdfsdfsdf',3,100000,1,99000,'','temp_1725880732796520142877.jpg','adsasdasd','','Petrol',0,'Pending',1,'DEALER',0,'2024-09-09 11:19:01','2025-04-07 15:03:02'),
(124,'VA15497669',2,20,194,'stc','Mh03cm','Automatic','','','1','Used','GLE',0,'mumbai','2018','12345','Andheri',0,1000000,5,950000,'','temp_1730132719442221323271000668047.jpg','well maintained luxury car','','Diesel',0,'Pending',4,'DEALER',0,'2024-10-28 16:26:20','2024-11-06 02:59:39'),
(125,'VA17832635',2,12,117,'std','dheh','Manual','Yes','08 Oct 2024','2','New','dhsb',1,'zvavaba','2121','4994497','dbsb',1,100,10,90,'','temp_1730134493846431096554053889396.jpg','working','','Petrol',0,'Pending',1,'DEALER',0,'2024-10-28 16:55:11','2025-04-07 15:33:48'),
(126,'VA74478326',2,8,1343,'stc','MH46Bk7550','Automatic','','19 May 2025','1','Used','ZDI',21,'Navi Mumbai','2019','95205','Vashi, navi mumbai',626,523580,1,518345,'','temp_17301832295307307739642604317830.jpg','good car','','Petrol',0,'Pending',8,'DEALER',0,'2024-10-29 06:28:46','2025-04-28 12:27:27'),
(127,'VA05671639',2,12,120,'std','please','Manual','','02 Nov 2024','2','New','xls',1,'dehradun','1996','326999','test',1,98653988,99,86885886,'','temp_17305379031146405537052952496487.jpg','nsnsn','','Petrol',0,'Pending',88,'DEALER',0,'2024-11-02 08:59:52','2024-11-05 05:34:19'),
(128,'VA83922840',2,12,118,'std','snsnsn','Manual','','02 Nov 2024','1','New','nsnsn',4,'newnnw','0000','9494799','nsnssn',46,94494949,99,86844296,'','temp_17305380961198521134915989975920.jpg','tetsgs','','Petrol',0,'Pending',88,'DEALER',0,'2024-11-02 09:01:56','2024-11-05 05:34:18'),
(129,'VA70459672',2,11,109,'std','fjdm','Manual','Yes','02 Nov 2024','3','New','nej',2,'nwnwnw','5659','944949','jejej',4,49944994,0,49944994,'','temp_17305400188754640435549597191998.jpg','nenen','','Petrol',1,'Pending',95,'USER',0,'2024-11-02 09:33:54','2024-11-02 09:33:54'),
(130,'VA50732615',2,14,1107,'std','MH09xxxxxx','Manual','No','','1','Used','Titanium',21,'MH04','2014','27000','badlapur',626,200000,5,190000,'','temp_17347627299375807718562222757249.jpg','Good','','Petrol',0,'Pending',8,'DEALER',0,'2024-12-21 06:32:51','2025-06-16 10:21:51'),
(131,'VA37748786',2,6,4,'std','MH14HM6969','Manual','Yes','19 Mar 2025','1','Used','10',21,'Maharashtra','2024','100080','sanewadi',280,15000,0,15000,'','temp_17377795940216460738319733201229.jpg','used car with extra fitting','','Petrol',1,'Pending',7,'USER',0,'2025-01-25 04:33:44','2025-01-25 04:33:44');
/*!40000 ALTER TABLE `tbl_mp_vehicle` ENABLE KEYS */;

--
-- Table structure for table `tbl_mp_vehicle_appointment`
--

DROP TABLE IF EXISTS `tbl_mp_vehicle_appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mp_vehicle_appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mp_vehicle_appointment`
--

/*!40000 ALTER TABLE `tbl_mp_vehicle_appointment` DISABLE KEYS */;
INSERT INTO `tbl_mp_vehicle_appointment` VALUES
(1,82,120,'2024-08-31','10 : 30 Am','aja milte hai','2024-08-31 10:07:24'),
(2,4,121,'2024-09-05','12 : 31 Pm','I will come','2024-09-05 07:35:07'),
(3,7,124,'2024-10-29','10 : 30 Am','de dona sir','2024-10-29 06:30:52'),
(4,2,97,'2024-11-14','10 : 30 Am','7503196450','2024-11-15 06:23:31'),
(5,2,94,'2024-11-14','10 : 30 Am','7503196450','2024-11-15 06:24:17');
/*!40000 ALTER TABLE `tbl_mp_vehicle_appointment` ENABLE KEYS */;

--
-- Table structure for table `tbl_mp_vehicle_enquiry`
--

DROP TABLE IF EXISTS `tbl_mp_vehicle_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mp_vehicle_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `status` varchar(150) NOT NULL,
  `hide` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mp_vehicle_enquiry`
--

/*!40000 ALTER TABLE `tbl_mp_vehicle_enquiry` DISABLE KEYS */;
INSERT INTO `tbl_mp_vehicle_enquiry` VALUES
(1,8,39,65,'Attended',0,'2024-07-20 08:11:56','2024-07-21 12:21:12'),
(2,8,11,17,'Enquired',0,'2024-07-20 08:12:08','2024-07-20 08:12:08'),
(3,3,39,65,'Attended',0,'2024-07-20 09:07:19','2024-07-21 12:20:51'),
(4,1,40,71,'Enquired',0,'2024-07-20 13:15:33','2024-07-20 13:15:33'),
(5,1,40,71,'Enquired',0,'2024-07-20 15:14:34','2024-07-20 15:14:34'),
(6,1,40,71,'Enquired',0,'2024-07-20 15:15:50','2024-07-20 15:15:50'),
(7,8,40,71,'Enquired',0,'2024-07-21 09:07:42','2024-07-21 09:07:42'),
(8,42,40,71,'Enquired',0,'2024-07-21 09:32:00','2024-07-21 09:32:00'),
(9,8,40,71,'Enquired',0,'2024-07-21 15:18:29','2024-07-21 15:18:29'),
(10,8,8,47,'Attended',0,'2024-07-23 06:15:17','2024-09-05 07:36:27'),
(11,8,8,47,'Attended',0,'2024-07-23 07:49:43','2024-09-05 07:36:26'),
(12,8,8,47,'Attended',0,'2024-07-23 08:18:23','2024-09-05 07:36:25'),
(13,3,37,56,'Enquired',0,'2024-07-23 08:26:38','2024-07-23 08:26:38'),
(14,8,40,71,'Enquired',0,'2024-07-23 10:30:07','2024-07-23 10:30:07'),
(15,1,1,83,'Enquired',0,'2024-07-23 16:19:51','2024-07-23 16:19:51'),
(16,42,37,56,'Enquired',0,'2024-07-23 18:12:23','2024-07-23 18:12:23'),
(17,42,1,83,'Enquired',0,'2024-07-23 18:36:40','2024-07-23 18:36:40'),
(18,42,1,83,'Attended',0,'2024-07-23 18:37:15','2024-07-23 23:52:33'),
(19,1,1,83,'Attended',0,'2024-07-23 23:52:08','2024-07-23 23:52:28'),
(21,3,8,37,'Attended',0,'2024-07-26 07:50:47','2024-08-15 07:19:03'),
(22,4,39,63,'Enquired',0,'2024-07-26 08:31:47','2024-07-26 08:31:47'),
(23,8,4,48,'Attended',0,'2024-07-26 08:32:00','2024-07-26 08:34:06'),
(24,8,4,48,'Attended',0,'2024-07-26 08:33:08','2024-07-26 08:34:09'),
(25,4,8,37,'Attended',0,'2024-07-26 12:42:56','2024-07-30 16:11:46'),
(26,8,4,48,'Enquired',0,'2024-07-30 08:33:33','2024-07-30 08:33:33'),
(27,8,4,48,'Enquired',0,'2024-07-30 08:59:34','2024-07-30 08:59:34'),
(28,8,4,48,'Enquired',0,'2024-07-30 09:55:06','2024-07-30 09:55:06'),
(29,8,4,48,'Attended',0,'2024-07-30 16:10:51','2024-07-30 16:12:38'),
(30,1,11,17,'Enquired',0,'2024-07-31 11:33:46','2024-07-31 11:33:46'),
(31,42,42,88,'Enquired',0,'2024-08-07 18:17:51','2024-08-07 18:17:51'),
(32,42,42,88,'Enquired',0,'2024-08-07 18:19:05','2024-08-07 18:19:05'),
(33,10,42,88,'Enquired',0,'2024-08-08 17:02:40','2024-08-08 17:02:40'),
(34,8,49,91,'Enquired',0,'2024-08-12 10:54:04','2024-08-12 10:54:04'),
(35,8,4,48,'Enquired',0,'2024-08-12 11:58:51','2024-08-12 11:58:51'),
(36,8,4,48,'Enquired',0,'2024-08-12 12:59:12','2024-08-12 12:59:12'),
(37,10,42,96,'Enquired',0,'2024-08-12 15:36:57','2024-08-12 15:36:57'),
(38,10,42,96,'Enquired',0,'2024-08-12 15:38:04','2024-08-12 15:38:04'),
(39,10,42,96,'Attended',0,'2024-08-12 15:41:12','2024-08-17 11:43:46'),
(40,4,4,48,'Enquired',0,'2024-08-13 06:44:45','2024-08-13 06:44:45'),
(41,4,4,48,'Enquired',0,'2024-08-13 08:46:05','2024-08-13 08:46:05'),
(42,8,8,47,'Attended',0,'2024-08-13 10:30:04','2024-08-14 13:27:34'),
(43,8,4,48,'Enquired',0,'2024-08-13 10:47:44','2024-08-13 10:47:44'),
(44,4,4,48,'Enquired',0,'2024-08-14 11:24:34','2024-08-14 11:24:34'),
(45,66,40,71,'Enquired',0,'2024-08-14 13:04:35','2024-08-14 13:04:35'),
(46,8,58,97,'Enquired',0,'2024-08-15 07:01:32','2024-08-15 07:01:32'),
(47,8,4,48,'Enquired',0,'2024-08-15 08:31:52','2024-08-15 08:31:52'),
(48,59,58,97,'Enquired',0,'2024-08-15 22:42:47','2024-08-15 22:42:47'),
(49,8,4,48,'Enquired',0,'2024-08-17 10:35:22','2024-08-17 10:35:22'),
(50,8,4,48,'Enquired',0,'2024-08-17 11:04:40','2024-08-17 11:04:40'),
(51,4,8,21,'Attended',0,'2024-08-22 07:43:03','2024-09-05 07:36:22'),
(52,8,4,48,'Enquired',0,'2024-08-22 07:43:39','2024-08-22 07:43:39'),
(53,8,8,21,'Attended',0,'2024-08-22 07:46:48','2024-09-05 07:36:23'),
(54,2,1,107,'Enquired',0,'2024-08-25 07:00:15','2024-08-25 07:00:15'),
(55,1,1,107,'Enquired',0,'2024-08-25 07:06:22','2024-08-25 07:06:22'),
(56,10,1,107,'Attended',0,'2024-08-28 03:07:23','2025-01-18 07:08:47'),
(57,10,42,110,'Enquired',0,'2024-08-28 03:09:40','2024-08-28 03:09:40'),
(66,4,8,121,'Enquired',0,'2024-09-05 07:35:23','2024-09-05 07:35:23'),
(67,74,58,97,'Enquired',0,'2024-09-09 10:22:14','2024-09-09 10:22:14'),
(68,2,58,97,'Enquired',0,'2024-10-17 07:02:57','2024-10-17 07:02:57'),
(69,1,58,97,'Enquired',0,'2024-10-25 11:27:02','2024-10-25 11:27:02'),
(70,91,37,77,'Enquired',0,'2024-10-28 15:22:10','2024-10-28 15:22:10'),
(71,2,40,70,'Enquired',0,'2024-10-29 06:56:38','2024-10-29 06:56:38'),
(72,7,8,126,'Enquired',0,'2024-11-02 03:11:52','2024-11-02 03:11:52'),
(73,2,39,63,'Enquired',0,'2024-11-15 06:25:12','2024-11-15 06:25:12'),
(74,56,56,99,'Enquired',0,'2024-11-26 15:52:44','2024-11-26 15:52:44'),
(75,7,37,79,'Enquired',0,'2025-01-25 04:39:07','2025-01-25 04:39:07'),
(76,8,49,91,'Enquired',0,'2025-02-08 20:34:57','2025-02-08 20:34:57'),
(77,1,73,100,'Enquired',0,'2025-03-31 15:45:06','2025-03-31 15:45:06'),
(78,7,39,64,'Enquired',0,'2025-04-07 16:18:48','2025-04-07 16:18:48'),
(79,128,40,68,'Enquired',0,'2025-06-20 06:29:57','2025-06-20 06:29:57'),
(80,14,47,94,'Enquired',0,'2025-07-01 07:38:42','2025-07-01 07:38:42');
/*!40000 ALTER TABLE `tbl_mp_vehicle_enquiry` ENABLE KEYS */;

--
-- Table structure for table `tbl_mp_vehicle_images`
--

DROP TABLE IF EXISTS `tbl_mp_vehicle_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mp_vehicle_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_id` tinyint(4) NOT NULL,
  `image` varchar(150) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=862 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mp_vehicle_images`
--

/*!40000 ALTER TABLE `tbl_mp_vehicle_images` DISABLE KEYS */;
INSERT INTO `tbl_mp_vehicle_images` VALUES
(16,5,'WhatsApp_Image_2024-06-05_at_16_51_03_(2).jpeg','2024-06-05 13:13:28','2024-06-10 07:05:25'),
(17,5,'WhatsApp_Image_2024-06-05_at_16_51_03_(1).jpeg','2024-06-05 13:13:33','2024-06-10 07:05:27'),
(18,5,'WhatsApp_Image_2024-06-05_at_16_51_01.jpeg','2024-06-05 13:13:33','2024-06-05 13:13:33'),
(19,5,'WhatsApp_Image_2024-06-05_at_16_51_01_(1).jpeg','2024-06-05 13:13:35','2024-06-05 13:13:35'),
(20,5,'WhatsApp_Image_2024-06-05_at_16_51_02_(2).jpeg','2024-06-05 13:13:35','2024-06-05 13:13:35'),
(21,5,'WhatsApp_Image_2024-06-05_at_16_51_03.jpeg','2024-06-05 13:13:35','2024-06-05 13:13:35'),
(22,5,'WhatsApp_Image_2024-06-05_at_16_51_02_(1).jpeg','2024-06-05 13:13:35','2024-06-05 13:13:35'),
(23,5,'WhatsApp_Image_2024-06-05_at_16_51_02.jpeg','2024-06-05 13:13:35','2024-06-05 13:13:35'),
(24,6,'20240503_0825271.jpg','2024-06-07 12:33:58','2024-06-07 12:33:58'),
(25,6,'20240503_082508.jpg','2024-06-07 12:33:58','2024-06-07 12:33:58'),
(26,8,'IMG-20240526-WA00271.jpeg','2024-06-07 12:45:29','2024-06-07 12:45:29'),
(27,9,'WhatsApp_Image_2024-06-07_at_2_23_15_PM_(1)1.jpeg','2024-06-07 13:10:48','2024-06-07 13:10:48'),
(28,9,'WhatsApp_Image_2024-06-07_at_2_23_09_PM.jpeg','2024-06-07 13:10:48','2024-06-07 13:10:48'),
(29,9,'WhatsApp_Image_2024-06-07_at_2_23_13_PM.jpeg','2024-06-07 13:10:48','2024-06-07 13:10:48'),
(30,9,'WhatsApp_Image_2024-06-07_at_2_23_15_PM.jpeg','2024-06-07 13:10:48','2024-06-07 13:10:48'),
(31,9,'WhatsApp_Image_2024-06-07_at_2_23_11_PM.jpeg','2024-06-07 13:10:48','2024-06-07 13:10:48'),
(32,10,'WhatsApp_Image_2024-06-06_at_1_02_04_PM_(2).jpeg','2024-06-07 13:29:17','2024-06-07 13:29:17'),
(33,10,'WhatsApp_Image_2024-06-06_at_1_02_04_PM.jpeg','2024-06-07 13:29:17','2024-06-07 13:29:17'),
(34,10,'WhatsApp_Image_2024-06-06_at_1_02_05_PM.jpeg','2024-06-07 13:29:17','2024-06-07 13:29:17'),
(35,10,'WhatsApp_Image_2024-06-06_at_1_02_04_PM_(1)1.jpeg','2024-06-07 13:29:17','2024-06-07 13:29:17'),
(36,13,'WhatsApp_Image_2024-06-06_at_1_02_04_PM_(2)1.jpeg','2024-06-07 13:49:43','2024-06-07 13:49:43'),
(37,13,'WhatsApp_Image_2024-06-06_at_1_02_04_PM_(1)3.jpeg','2024-06-07 13:49:43','2024-06-07 13:49:43'),
(38,13,'WhatsApp_Image_2024-06-06_at_1_02_05_PM1.jpeg','2024-06-07 13:49:43','2024-06-07 13:49:43'),
(39,13,'WhatsApp_Image_2024-06-06_at_1_02_04_PM1.jpeg','2024-06-07 13:49:43','2024-06-07 13:49:43'),
(40,14,'dp.jpg','2024-06-08 07:21:42','2024-06-08 07:21:42'),
(41,14,'pan.jpg','2024-06-08 07:21:42','2024-06-08 07:21:42'),
(42,14,'pexels-cottonbro-studio-3945674.jpg','2024-06-08 07:21:43','2024-06-08 07:21:43'),
(43,14,'adhar.jpg','2024-06-08 07:21:43','2024-06-08 07:21:43'),
(44,14,'pexels-nubia-navarro-(nubikini)-386025.jpg','2024-06-08 07:21:43','2024-06-08 07:21:43'),
(45,15,'IMG-20240611-WA0038.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(46,15,'IMG-20240611-WA0037.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(47,15,'IMG-20240611-WA0035.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(48,15,'IMG-20240611-WA00361.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(49,15,'IMG-20240611-WA0034.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(50,15,'IMG-20240611-WA0033.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(51,15,'IMG-20240611-WA0032.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(52,15,'IMG-20240611-WA0031.jpg','2024-06-11 07:28:57','2024-06-11 07:28:57'),
(54,16,'IMG-20240317-WA0035.jpg','2024-06-12 13:47:44','2024-06-12 13:47:44'),
(55,16,'IMG-20240317-WA0037.jpg','2024-06-12 13:47:44','2024-06-12 13:47:44'),
(56,16,'IMG-20240317-WA0041.jpg','2024-06-12 13:47:44','2024-06-12 13:47:44'),
(57,17,'IMG-20240525-WA0091.jpg','2024-06-13 14:05:02','2024-06-13 14:05:02'),
(59,17,'IMG-20240525-WA0097.jpg','2024-06-13 14:05:02','2024-06-13 14:05:02'),
(60,17,'IMG-20240525-WA0087.jpg','2024-06-13 14:05:02','2024-06-13 14:05:02'),
(61,17,'IMG-20240525-WA0094.jpg','2024-06-13 14:05:02','2024-06-13 14:05:02'),
(62,17,'IMG-20240525-WA0095.jpg','2024-06-13 14:05:02','2024-06-13 14:05:02'),
(63,17,'IMG-20240525-WA0089.jpg','2024-06-13 14:05:02','2024-06-13 14:05:02'),
(64,17,'IMG-20240525-WA0096.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(65,17,'IMG-20240525-WA0088.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(66,17,'IMG-20240525-WA0090.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(67,17,'IMG-20240525-WA0086.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(68,17,'IMG-20240525-WA0093.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(69,17,'IMG-20240525-WA0092.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(70,17,'IMG-20240525-WA00981.jpg','2024-06-13 14:05:03','2024-06-13 14:05:03'),
(71,18,'temp_17186395273357756710403078086970.jpg','2024-06-17 15:52:12','2024-06-17 15:52:12'),
(72,19,'applogo1.png','2024-06-18 16:21:08','2024-06-18 16:21:08'),
(73,19,'basictoollogo.png','2024-06-18 16:21:08','2024-06-18 16:21:08'),
(74,20,'WhatsApp_Image_2024-06-22_at_1_04_23_PM.jpeg','2024-06-22 07:39:11','2024-06-22 07:39:11'),
(75,20,'WhatsApp_Image_2024-06-22_at_1_04_18_PM.jpeg','2024-06-22 07:39:11','2024-06-22 07:39:11'),
(76,20,'WhatsApp_Image_2024-06-22_at_1_04_22_PM.jpeg','2024-06-22 07:39:11','2024-06-22 07:39:11'),
(77,20,'WhatsApp_Image_2024-06-22_at_1_04_19_PM_(1).jpeg','2024-06-22 07:39:11','2024-06-22 07:39:11'),
(78,20,'WhatsApp_Image_2024-06-22_at_1_04_19_PM1.jpeg','2024-06-22 07:39:11','2024-06-22 07:39:11'),
(79,21,'WhatsApp_Image_2024-06-22_at_1_04_19_PM_(1)1.jpeg','2024-06-22 07:46:24','2024-06-22 07:46:24'),
(80,21,'WhatsApp_Image_2024-06-22_at_1_04_23_PM1.jpeg','2024-06-22 07:46:24','2024-06-22 07:46:24'),
(81,21,'WhatsApp_Image_2024-06-22_at_1_04_22_PM1.jpeg','2024-06-22 07:46:24','2024-06-22 07:46:24'),
(82,21,'WhatsApp_Image_2024-06-22_at_1_04_18_PM1.jpeg','2024-06-22 07:46:24','2024-06-22 07:46:24'),
(83,21,'WhatsApp_Image_2024-06-22_at_1_04_19_PM4.jpeg','2024-06-22 07:46:24','2024-06-22 07:46:24'),
(84,22,'temp_17190438313257253153083979230554.jpg','2024-06-22 08:10:45','2024-06-22 08:10:45'),
(85,23,'temp_17190500079305617547988941875552.jpg','2024-06-22 09:53:38','2024-06-22 09:53:38'),
(86,24,'temp_1719061518439139244800688281112.jpg','2024-06-22 13:05:49','2024-06-22 13:05:49'),
(87,25,'WhatsApp_Image_2024-06-22_at_1_04_23_PM2.jpeg','2024-06-23 07:19:07','2024-06-23 07:19:07'),
(88,25,'WhatsApp_Image_2024-06-22_at_1_04_19_PM_(1)2.jpeg','2024-06-23 07:19:07','2024-06-23 07:19:07'),
(89,25,'WhatsApp_Image_2024-06-22_at_1_04_22_PM2.jpeg','2024-06-23 07:19:07','2024-06-23 07:19:07'),
(90,25,'WhatsApp_Image_2024-06-22_at_1_04_18_PM2.jpeg','2024-06-23 07:19:07','2024-06-23 07:19:07'),
(91,25,'WhatsApp_Image_2024-06-22_at_1_04_19_PM6.jpeg','2024-06-23 07:19:07','2024-06-23 07:19:07'),
(92,26,'WhatsApp_Image_2024-06-25_at_08_22_28_(1).jpeg','2024-06-25 09:46:20','2024-06-25 09:46:20'),
(93,26,'WhatsApp_Image_2024-06-25_at_08_22_29_(2).jpeg','2024-06-25 09:46:20','2024-06-25 09:46:20'),
(94,26,'WhatsApp_Image_2024-06-25_at_08_22_30_(1).jpeg','2024-06-25 09:46:20','2024-06-25 09:46:20'),
(95,26,'WhatsApp_Image_2024-06-25_at_08_22_29_(1).jpeg','2024-06-25 09:46:20','2024-06-25 09:46:20'),
(96,26,'WhatsApp_Image_2024-06-25_at_08_22_28.jpeg','2024-06-25 09:46:20','2024-06-25 09:46:20'),
(97,26,'WhatsApp_Image_2024-06-25_at_08_22_30_(2).jpeg','2024-06-25 09:46:21','2024-06-25 09:46:21'),
(98,26,'WhatsApp_Image_2024-06-25_at_08_22_30.jpeg','2024-06-25 09:46:21','2024-06-25 09:46:21'),
(99,26,'WhatsApp_Image_2024-06-25_at_08_22_311.jpeg','2024-06-25 09:46:21','2024-06-25 09:46:21'),
(100,26,'WhatsApp_Image_2024-06-25_at_08_22_29.jpeg','2024-06-25 09:46:21','2024-06-25 09:46:21'),
(101,27,'temp_17196480178661779378194368759293.jpg','2024-06-29 08:00:29','2024-06-29 08:00:29'),
(102,28,'temp_17197442679633218200341717005075.jpg','2024-06-30 10:44:40','2024-06-30 10:44:40'),
(103,29,'temp_1719849335540218191389160603504.jpg','2024-07-01 15:57:22','2024-07-01 15:57:22'),
(104,30,'temp_17198511233441517940410796216499.jpg','2024-07-01 16:25:39','2024-07-01 16:25:39'),
(105,31,'BMSuJCcfyo50DNNV2kQ1l-transformed2.jpeg','2024-07-01 17:17:51','2024-07-01 17:17:51'),
(106,31,'21477675843.jpg','2024-07-01 17:17:51','2024-07-01 17:17:51'),
(110,32,'temp_1720260112057985541543643475528.jpg','2024-07-06 10:01:58','2024-07-06 10:01:58'),
(111,33,'temp_17202611351949074570401983515478.jpg','2024-07-06 10:19:06','2024-07-06 10:19:06'),
(112,34,'temp_17202613631666997265333387554945.jpg','2024-07-06 10:22:53','2024-07-06 10:22:53'),
(113,35,'temp_17202707221033219810140945301900.jpg','2024-07-06 12:58:48','2024-07-06 12:58:48'),
(114,36,'temp_17208754992047304409129846179590.jpg','2024-07-13 12:58:44','2024-07-13 12:58:44'),
(115,36,'temp_17208757114022266401624864505917.jpg','2024-07-13 13:02:14','2024-07-13 13:02:14'),
(116,36,'temp_17208758280892648232482940566357.jpg','2024-07-13 13:04:19','2024-07-13 13:04:19'),
(117,36,'temp_17208759049947442107229392800731.jpg','2024-07-13 13:05:20','2024-07-13 13:05:20'),
(118,36,'temp_17208761998063678440106658020413.jpg','2024-07-13 13:10:09','2024-07-13 13:10:09'),
(119,37,'temp_17208773221627013339083594309774.jpg','2024-07-13 13:28:54','2024-07-13 13:28:54'),
(120,37,'temp_17208774549735136949108803731779.jpg','2024-07-13 13:31:00','2024-07-13 13:31:00'),
(121,31,'temp_17210655068433667205645631191714.jpg','2024-07-15 17:45:37','2024-07-15 17:45:37'),
(122,31,'temp_17210658796817006695512236350365.jpg','2024-07-15 17:51:29','2024-07-15 17:51:29'),
(123,38,'temp_17210971981854802236712229870982.jpg','2024-07-16 02:34:03','2024-07-16 02:34:03'),
(124,38,'temp_17210973369305328107556930381211.jpg','2024-07-16 02:35:40','2024-07-16 02:35:40'),
(125,38,'temp_17211066920051797435750232936572.jpg','2024-07-16 05:11:35','2024-07-16 05:11:35'),
(126,38,'temp_17211067345655504161451218756831.jpg','2024-07-16 05:12:20','2024-07-16 05:12:20'),
(127,39,'temp_17211074322691749619822280535501.jpg','2024-07-16 05:23:57','2024-07-16 05:23:57'),
(128,40,'WhatsApp_Image_2024-07-13_at_18_42_39_(1).jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(129,40,'WhatsApp_Image_2024-07-13_at_18_42_38_(2)1.jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(130,40,'WhatsApp_Image_2024-07-13_at_18_42_38.jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(131,40,'WhatsApp_Image_2024-07-13_at_18_42_39_(2).jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(132,40,'WhatsApp_Image_2024-07-13_at_18_42_39.jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(133,40,'WhatsApp_Image_2024-07-13_at_18_42_40_(3).jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(134,40,'WhatsApp_Image_2024-07-13_at_18_42_40_(1).jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(135,40,'WhatsApp_Image_2024-07-13_at_18_42_40_(2).jpeg','2024-07-16 06:21:54','2024-07-16 06:21:54'),
(136,41,'temp_17211187304288160296534880856269.jpg','2024-07-16 08:32:20','2024-07-16 08:32:20'),
(137,41,'temp_17211187305002946713178718339838.jpg','2024-07-16 08:32:20','2024-07-16 08:32:20'),
(138,41,'temp_17211187305428019895206393055435.jpg','2024-07-16 08:32:20','2024-07-16 08:32:20'),
(139,41,'temp_1721118730583476860074365289878.jpg','2024-07-16 08:32:20','2024-07-16 08:32:20'),
(140,42,'temp_17211188013737169649474843934347.jpg','2024-07-16 08:33:33','2024-07-16 08:33:33'),
(141,42,'temp_17211188014257071138598185234611.jpg','2024-07-16 08:33:33','2024-07-16 08:33:33'),
(142,42,'temp_17211188014854565049072792943815.jpg','2024-07-16 08:33:33','2024-07-16 08:33:33'),
(143,42,'temp_17211188015268838089322727942001.jpg','2024-07-16 08:33:33','2024-07-16 08:33:33'),
(144,43,'temp_17211198798676045527765963493839.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(145,43,'temp_17211198834861141093365934006671.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(146,43,'temp_17211198861772773153313462433318.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(147,43,'temp_17211198897905711506538127857961.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(148,43,'temp_17211198945088252292519643928757.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(149,43,'temp_1721119901388847147776109811187.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(150,43,'temp_17211199109196974217280982443802.jpg','2024-07-16 08:51:56','2024-07-16 08:51:56'),
(151,44,'temp_17211201012196959103559545578811.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(152,44,'temp_1721120104474160709274502331733.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(153,44,'temp_17211201076627413168232827270727.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(154,44,'temp_17211201107611016660391488653002.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(155,44,'temp_17211201141035375526935295252455.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(156,44,'temp_17211201194635456161543741452350.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(157,44,'temp_17211201235686369493327133281214.jpg','2024-07-16 08:55:30','2024-07-16 08:55:30'),
(158,45,'temp_17211222150692160040953451726644.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(159,45,'temp_17211222150767726987931861853482.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(160,45,'temp_17211222150837287996004851916176.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(161,45,'temp_17211222150916306399469494394515.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(162,45,'temp_17211222150987253159628012135597.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(163,45,'temp_17211222151054665458841808890935.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(164,45,'temp_17211222151134150014449790246015.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(165,45,'temp_17211222151214499524364073053026.jpg','2024-07-16 09:31:37','2024-07-16 09:31:37'),
(166,46,'temp_17211227266242742610065193074962.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(167,46,'temp_17211227418515304466277494814307.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(168,46,'temp_17211227883651589109121428630626.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(169,46,'temp_17211227884035471389918402359462.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(170,46,'temp_17211227884282699896122685578517.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(171,46,'temp_17211227884478773959360594894312.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(172,46,'temp_17211227884696878011249656585185.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(173,46,'temp_17211227885034216176426653029390.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(174,46,'temp_17211227885318155048665291631654.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(175,46,'temp_17211227885645872424178329411884.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(176,46,'temp_17211227885955933961231768816725.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(177,46,'temp_1721122788641503217974395434616.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(178,46,'temp_17211227887215701735788171948316.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(179,46,'temp_17211227888038816642266091896062.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(180,46,'temp_17211227888795341485831898961065.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(181,46,'temp_17211227889454192877894263832804.jpg','2024-07-16 09:40:02','2024-07-16 09:40:02'),
(182,37,'temp_17211240112389000059919993551119.jpg','2024-07-16 10:02:04','2024-07-16 10:02:04'),
(183,37,'temp_17211240324178213374235225466754.jpg','2024-07-16 10:02:04','2024-07-16 10:02:04'),
(184,37,'temp_17211240775362474682148290878530.jpg','2024-07-16 10:02:04','2024-07-16 10:02:04'),
(185,37,'temp_17211240775494733276446585665610.jpg','2024-07-16 10:02:04','2024-07-16 10:02:04'),
(186,37,'temp_17211240775636562059048925559797.jpg','2024-07-16 10:02:04','2024-07-16 10:02:04'),
(187,37,'temp_17211240775913480484905773687236.jpg','2024-07-16 10:02:04','2024-07-16 10:02:04'),
(188,37,'temp_17211300029382861254783145998264.jpg','2024-07-16 11:40:12','2024-07-16 11:40:12'),
(189,37,'temp_17211300029542060528650623071303.jpg','2024-07-16 11:40:12','2024-07-16 11:40:12'),
(190,37,'temp_1721130002975295363907902416923.jpg','2024-07-16 11:40:12','2024-07-16 11:40:12'),
(191,37,'temp_17211300029878865124128065262381.jpg','2024-07-16 11:40:12','2024-07-16 11:40:12'),
(192,37,'temp_17211300029983861835324569777758.jpg','2024-07-16 11:40:12','2024-07-16 11:40:12'),
(193,37,'temp_17211300030086714870408011324147.jpg','2024-07-16 11:40:12','2024-07-16 11:40:12'),
(194,47,'temp_17211303433493589461344587560169.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(195,47,'temp_17211303433625842197816463063239.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(196,47,'temp_17211303433787325866681575567971.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(197,47,'temp_17211303433856867502307701911783.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(198,47,'temp_17211303433943573241953755195702.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(199,47,'temp_17211303434035163171822613608060.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(200,47,'temp_17211303434192319438542974324121.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(201,47,'temp_17211303434297490705921199837409.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(202,47,'temp_17211303434378897505395489215341.jpg','2024-07-16 11:46:48','2024-07-16 11:46:48'),
(206,48,'temp_17212247353701450994056629117186.jpg','2024-07-17 14:01:52','2024-07-17 14:01:52'),
(207,48,'temp_17212247494733517610553418431538.jpg','2024-07-17 14:01:52','2024-07-17 14:01:52'),
(208,48,'temp_17212247495001919835911941632447.jpg','2024-07-17 14:01:52','2024-07-17 14:01:52'),
(209,48,'temp_17212247495364665098437447904941.jpg','2024-07-17 14:01:52','2024-07-17 14:01:52'),
(210,49,'IMG-20240717-WA03421.jpg','2024-07-17 14:50:48','2024-07-17 14:50:48'),
(211,49,'IMG-20240717-WA0343.jpg','2024-07-17 14:50:48','2024-07-17 14:50:48'),
(212,49,'IMG-20240717-WA0344.jpg','2024-07-17 14:50:48','2024-07-17 14:50:48'),
(213,49,'IMG-20240717-WA0301.jpg','2024-07-17 14:50:48','2024-07-17 14:50:48'),
(214,50,'IMG-20240718-WA0023.jpg','2024-07-18 06:28:42','2024-07-18 06:28:42'),
(215,50,'IMG-20240718-WA00011.jpg','2024-07-18 06:28:42','2024-07-18 06:28:42'),
(216,50,'IMG-20240718-WA0027.jpg','2024-07-18 06:28:42','2024-07-18 06:28:42'),
(217,50,'IMG-20240718-WA0041.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(218,50,'IMG-20240718-WA0029.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(219,50,'IMG-20240718-WA0031.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(220,50,'IMG-20240718-WA0033.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(221,50,'IMG-20240718-WA0039.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(222,50,'IMG-20240718-WA00012.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(223,50,'IMG-20240718-WA0037.jpg','2024-07-18 06:28:43','2024-07-18 06:28:43'),
(224,50,'IMG-20240718-WA0003.jpg','2024-07-18 06:28:44','2024-07-18 06:28:44'),
(225,50,'IMG-20240718-WA0043.jpg','2024-07-18 06:28:44','2024-07-18 06:28:44'),
(226,51,'temp_17213154881561377487646854135451.jpg','2024-07-18 15:11:45','2024-07-18 15:11:45'),
(227,51,'temp_17213154978816524416759926878966.jpg','2024-07-18 15:11:45','2024-07-18 15:11:45'),
(228,51,'temp_17213155004713563642153137531781.jpg','2024-07-18 15:11:45','2024-07-18 15:11:45'),
(233,53,'temp_17213356565593318326819712526538.jpg','2024-07-18 20:47:52','2024-07-18 20:47:52'),
(234,53,'temp_17213356623981776795820862498153.jpg','2024-07-18 20:47:52','2024-07-18 20:47:52'),
(235,53,'temp_17213356669785198770739236963125.jpg','2024-07-18 20:47:52','2024-07-18 20:47:52'),
(236,54,'temp_17213723989195006100166081474413.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(237,54,'temp_1721372398944826028765708304914.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(238,54,'temp_17213723989656271955213403026039.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(239,54,'temp_17213723989802818787910733895698.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(240,54,'temp_17213723990051649538532131106990.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(241,54,'temp_17213723990258210195406952097324.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(242,54,'temp_17213723990514832703747047969519.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(243,54,'temp_17213723990923013494231420031121.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(244,54,'temp_17213723991066866623103182864214.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(245,54,'temp_17213723991226716253319642335474.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(246,54,'temp_17213723991383973368864047389982.jpg','2024-07-19 07:01:25','2024-07-19 07:01:25'),
(247,55,'temp_17213731640695997794926153611374.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(248,55,'temp_17213731640891518580917564448292.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(249,55,'temp_17213731641064821384375545962386.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(250,55,'temp_1721373164115482530910324468583.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(251,55,'temp_17213731641293863163218673500323.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(252,55,'temp_17213731641486883275989113214410.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(253,55,'temp_17213731641664385173431443260712.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(254,55,'temp_17213731641857856649407262456870.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(255,55,'temp_17213731641972329147879727918220.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(256,55,'temp_17213731642144677818015908650394.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(257,55,'temp_17213731642268451646498316666274.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(258,55,'temp_17213731642387518106445635398134.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(259,55,'temp_17213731642531442021367399547772.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(260,55,'temp_17213731642613458198784305976063.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(261,55,'temp_17213731642764823428036106638884.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(262,55,'temp_17213731642927387209185571693997.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(263,55,'temp_17213731642995300469780908484712.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(264,55,'temp_17213731643062245784305575206655.jpg','2024-07-19 07:12:57','2024-07-19 07:12:57'),
(265,56,'temp_17213738213298236041107373287119.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(266,56,'temp_17213738213718666776940198669084.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(267,56,'temp_1721373821409733776625090608517.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(268,56,'temp_17213738214373521603018996651971.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(269,56,'temp_17213738214823530808681166110220.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(270,56,'temp_17213738215137784470381375274026.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(271,56,'temp_17213738215425499036486572361936.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(272,56,'temp_17213738215646164175055083424762.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(273,56,'temp_17213738215806290473052414647107.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(274,56,'temp_1721373821595474093621104505597.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(275,56,'temp_17213738216043313694134603556998.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(276,56,'temp_17213738216131354418101917903194.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(277,56,'temp_17213738216192123816387853688808.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(278,56,'temp_17213738216294572858573917900329.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(279,56,'temp_1721373821641487416050133674068.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(280,56,'temp_17213738216488727590822070955034.jpg','2024-07-19 07:23:55','2024-07-19 07:23:55'),
(281,57,'temp_17213767452984212354372436648462.jpg','2024-07-19 08:21:42','2024-07-19 08:21:42'),
(282,57,'temp_17213767571706448060235022672142.jpg','2024-07-19 08:21:42','2024-07-19 08:21:42'),
(283,57,'temp_17213767667593079754773115666625.jpg','2024-07-19 08:21:42','2024-07-19 08:21:42'),
(284,57,'temp_17213767786143135791812781896716.jpg','2024-07-19 08:21:42','2024-07-19 08:21:42'),
(285,57,'temp_17213767866206645450852730240073.jpg','2024-07-19 08:21:42','2024-07-19 08:21:42'),
(286,57,'temp_172137674529842123543724366484621.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(287,57,'temp_172137675717064480602350226721421.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(288,57,'temp_172137676675930797547731156666251.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(289,57,'temp_172137677861431357918127818967161.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(290,57,'temp_172137678662066454508527302400731.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(291,57,'temp_17213767961186247727335795135578.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(292,57,'temp_17213768029682058398256412741275.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(293,57,'temp_17213768130181332176869163258387.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(294,57,'temp_17213768250962081949430009878515.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(295,57,'temp_17213768522763734293920947169146.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(296,57,'temp_17213768662915552231967524772811.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(297,57,'temp_17213768759653308121899199230015.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(298,57,'temp_17213768827412500098387105424099.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(299,57,'temp_17213768888323917386993150990273.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(300,57,'temp_17213768990578292638359391409973.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(301,57,'temp_17213769061924786991481799574429.jpg','2024-07-19 08:22:05','2024-07-19 08:22:05'),
(302,58,'temp_17213779728646573508584450228660.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(303,58,'temp_17213779952713456947681599192889.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(304,58,'temp_17213780053222319493384722447363.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(305,58,'temp_17213780133425423798859624229661.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(306,58,'temp_17213780380493138597309939214492.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(307,58,'temp_17213780494242839774395802743089.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(308,58,'temp_1721378395842370201173685365405.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(309,58,'temp_17213784183307601669186547139633.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(310,58,'temp_1721378429178165079651829562364.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(311,58,'temp_1721378489119459905658123665922.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(312,58,'temp_17213785003436350241699000064105.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(313,58,'temp_17213785176406689733292375893425.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(314,58,'temp_17213785636851409646208326306614.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(315,58,'temp_17213785783122269059295089064770.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(316,58,'temp_17213785889825058126427446933660.jpg','2024-07-19 08:46:00','2024-07-19 08:46:00'),
(317,59,'temp_17213810332028294775611738622402.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(318,59,'temp_17213810332802049366928438162425.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(319,59,'temp_17213810333891115022586260352135.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(320,59,'temp_17213810334894635090812284987749.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(321,59,'temp_17213810335814285862149882140733.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(322,59,'temp_17213810336757084611053026672837.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(323,59,'temp_17213810337568283071864549424136.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(324,59,'temp_17213810338346815566110445028532.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(325,59,'temp_17213810339225793550070845201848.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(326,59,'temp_17213810340117212071554557512835.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(327,59,'temp_17213810340991492706557640922797.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(328,59,'temp_17213810341614334726235282845445.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(329,59,'temp_17213810342293562625743292149631.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(330,59,'temp_1721381034311445738768650322476.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(331,59,'temp_1721381034388741566173648587742.jpg','2024-07-19 09:24:17','2024-07-19 09:24:17'),
(332,60,'temp_17213813702306990411722437436023.jpg','2024-07-19 09:29:44','2024-07-19 09:29:44'),
(333,60,'temp_17213813703055614067329548054034.jpg','2024-07-19 09:29:44','2024-07-19 09:29:44'),
(334,60,'temp_17213813703775897628685466529899.jpg','2024-07-19 09:29:44','2024-07-19 09:29:44'),
(335,60,'temp_17213813704539099385878245052562.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(336,60,'temp_17213813705294248391713078419528.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(337,60,'temp_17213813706135897943591016012571.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(338,60,'temp_17213813706866621965783101109895.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(339,60,'temp_17213813707599162410005929310207.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(340,60,'temp_17213813708411679825338749212735.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(341,60,'temp_172138137092722200137378132168.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(342,60,'temp_17213813709933547257981816709621.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(343,60,'temp_17213813710567360644911030871794.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(344,60,'temp_17213813711355832194245040102403.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(345,60,'temp_17213813712145212078028047047113.jpg','2024-07-19 09:29:45','2024-07-19 09:29:45'),
(346,61,'temp_1721381813802243538514186787546.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(347,61,'temp_17213818138731040525888947448917.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(348,61,'temp_17213818139519018096845928380259.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(349,61,'temp_17213818140236979862345473060050.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(350,61,'temp_17213818140956426963548373922695.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(351,61,'temp_17213818141688921318896309393758.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(352,61,'temp_17213818142376062726620640415237.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(353,61,'temp_17213818143027182593813606669179.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(354,61,'temp_17213818143729045777350776350778.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(355,61,'temp_1721381814441506121355891285679.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(356,61,'temp_17213818145026492540994896530331.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(357,61,'temp_17213818145676710112053821400462.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(358,61,'temp_17213818146385410871712551479369.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(359,61,'temp_17213818147151416222073649344195.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(360,61,'temp_1721381814795853005700908118689.jpg','2024-07-19 09:37:17','2024-07-19 09:37:17'),
(361,62,'temp_1721382528936198584572035070770.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(362,62,'temp_17213825289912281894677312629120.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(363,62,'temp_17213825290383826794666188439277.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(364,62,'temp_17213825290776599043669060972634.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(365,62,'temp_17213825291128332694666437520610.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(366,62,'temp_17213825291457962435985389642590.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(367,62,'temp_17213825291823727051275487791767.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(368,62,'temp_17213825292166359804902024308923.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(369,62,'temp_17213825292478903068198820845973.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(370,62,'temp_17213825292733008947143990857153.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(371,62,'temp_17213825293017695587462478656146.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(372,62,'temp_17213825293286221674082219352242.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(373,62,'temp_17213825293612375401053578736671.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(374,62,'temp_17213825293975834146795480784664.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(375,62,'temp_17213825294332936456872686696198.jpg','2024-07-19 09:48:57','2024-07-19 09:48:57'),
(376,63,'temp_17213834693505132433646207605770.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(377,63,'temp_17213834694247798161980999063456.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(378,63,'temp_17213834694843328216591305191367.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(379,63,'temp_17213834695411968175313036907347.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(380,63,'temp_17213834696036567771801631850996.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(381,63,'temp_17213834696757682261680787858786.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(382,63,'temp_17213834697482497881939097812687.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(383,63,'temp_17213834698142019854039489800223.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(384,63,'temp_17213834698807720058903969383847.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(385,63,'temp_17213834699485643856965455758232.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(386,63,'temp_17213834700213255392478545524473.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(387,63,'temp_17213834700983868242840681628591.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(388,63,'temp_1721383470180846013678225758217.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(389,63,'temp_17213834702556884930849920839845.jpg','2024-07-19 10:05:03','2024-07-19 10:05:03'),
(390,64,'temp_17213846965351060214452605249914.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(391,64,'temp_17213846966082563276626966043459.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(392,64,'temp_17213846966775677447660335080867.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(393,64,'temp_17213846967525898439950399498769.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(394,64,'temp_17213846968291765752005339249946.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(395,64,'temp_17213846968947905239453741841516.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(396,64,'temp_1721384696958411250264619882632.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(397,64,'temp_17213846970202874830099779553980.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(398,64,'temp_1721384697076953296686498115455.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(399,64,'temp_1721384697142666811461669753353.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(400,64,'temp_1721384697196420286736932800670.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(401,64,'temp_17213846972479166346460818397214.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(402,64,'temp_17213846973104613429141316161214.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(403,64,'temp_17213846973595158513049976374073.jpg','2024-07-19 10:25:13','2024-07-19 10:25:13'),
(404,65,'temp_17213851460185882865544295117029.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(405,65,'temp_17213851460998936284360003938505.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(406,65,'temp_17213851461748823042789033179424.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(407,65,'temp_17213851462545176269356487426722.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(408,65,'temp_17213851463416137055445711531851.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(409,65,'temp_1721385146411236886149480783931.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(410,65,'temp_17213851464807446667737067835755.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(411,65,'temp_17213851465438796347160764202563.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(412,65,'temp_17213851466025630642934661437045.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(413,65,'temp_17213851466604873054988538273613.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(414,65,'temp_1721385146727213352777803607981.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(415,65,'temp_17213851467873956488255136982597.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(416,65,'temp_17213851468509072043583555124233.jpg','2024-07-19 10:32:57','2024-07-19 10:32:57'),
(417,66,'C680E3D1-38C0-4C1E-B686-7B80311BC45F.jpeg','2024-07-20 09:44:53','2024-07-20 09:44:53'),
(418,66,'95C3EE2B-5AD6-40F7-BC03-B70A33DFA9B5.jpeg','2024-07-20 09:44:55','2024-07-20 09:44:55'),
(419,66,'7BD6FFC5-4C1E-4B97-9BC6-92EC283DEFDE.jpeg','2024-07-20 09:44:58','2024-07-20 09:44:58'),
(420,66,'45E3CA88-34EA-4C01-82F9-4ED855C4E18E.jpeg','2024-07-20 09:45:02','2024-07-20 09:45:02'),
(421,66,'329C15B5-0868-4243-8376-205E70FA9A89.jpeg','2024-07-20 09:45:03','2024-07-20 09:45:03'),
(422,66,'DC694304-6F3B-4A38-A841-45DF411F693B.jpeg','2024-07-20 09:45:05','2024-07-20 09:45:05'),
(423,66,'220DFA64-4479-488B-B913-BC9FB463929D.jpeg','2024-07-20 09:45:07','2024-07-20 09:45:07'),
(424,66,'2BE22231-A2AA-4857-9BDD-643032A6DA8B.jpeg','2024-07-20 09:45:08','2024-07-20 09:45:08'),
(425,66,'E150FDF4-03DB-4666-81A5-D6338664DC52.jpeg','2024-07-20 09:45:09','2024-07-20 09:45:09'),
(426,67,'a12e3345-9262-4356-9871-e4d692bc4498.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(427,67,'798cedd2-ce91-4f3a-856c-e7b14eb3a56e.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(428,67,'159c19dd-fc92-4dd3-af16-149dccd96943.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(429,67,'c7003c2d-abd6-425e-b295-f48cf9936c2f.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(430,67,'72945069-b312-4839-b18b-9a6dfdf39b88.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(431,67,'c5f82168-3b8e-45bc-91ec-b5d04629455e.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(432,67,'4cf913ac-5365-465d-9078-62f60f5cec82.jpeg','2024-07-20 10:01:33','2024-07-20 10:01:33'),
(433,68,'IMG_2644.jpeg','2024-07-20 10:08:04','2024-07-20 10:08:04'),
(434,68,'IMG_2636.jpeg','2024-07-20 10:08:09','2024-07-20 10:08:09'),
(435,68,'IMG_2640.jpeg','2024-07-20 10:08:10','2024-07-20 10:08:10'),
(436,68,'IMG_2638.jpeg','2024-07-20 10:08:10','2024-07-20 10:08:10'),
(437,68,'IMG_2643.jpeg','2024-07-20 10:08:13','2024-07-20 10:08:13'),
(438,68,'IMG_2642.jpeg','2024-07-20 10:08:14','2024-07-20 10:08:14'),
(439,68,'IMG_2635.jpeg','2024-07-20 10:08:16','2024-07-20 10:08:16'),
(440,69,'c4747a7a-8aca-4bba-a492-1dba8784458b.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(441,69,'7e010dd2-e1f7-4b1f-af8d-67efcb8069c2.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(442,69,'cc099111-51ac-4d28-8a05-2c64adc70945.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(443,69,'a6cf0176-89cc-4b44-842c-a5abde70409d.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(444,69,'62bfcbdd-9372-4cad-8e36-25169f519eb6.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(445,69,'aebc9292-c0f8-44a7-aafb-c30c344c26f5.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(446,69,'604d1717-1b5c-426f-a85d-0d629146b9ce.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(447,69,'bd3dce85-825c-4e59-b54e-925ceecdb45d.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(448,69,'4debc680-0eaf-45ab-9e5e-8ff17a7d1746.jpeg','2024-07-20 11:50:07','2024-07-20 11:50:07'),
(449,70,'BEE8A98F-3949-4970-8BD6-144BDA691794.jpeg','2024-07-20 11:57:53','2024-07-20 11:57:53'),
(450,70,'56B65E61-3945-41B4-8FF2-A292D8FB0E2B.jpeg','2024-07-20 11:57:55','2024-07-20 11:57:55'),
(451,70,'38B5E584-C1EE-4468-B226-931C41A23104.jpeg','2024-07-20 11:57:55','2024-07-20 11:57:55'),
(452,70,'57EE67AE-4888-4614-AC31-14EF66D263F03.jpeg','2024-07-20 11:57:55','2024-07-20 11:57:55'),
(453,70,'9A97F089-5173-411A-A1D9-8691A63334DF.jpeg','2024-07-20 11:57:55','2024-07-20 11:57:55'),
(454,70,'E451AC7F-F9C8-45E5-96DF-EEC8262DC3A9.jpeg','2024-07-20 11:57:55','2024-07-20 11:57:55'),
(455,71,'7bc58cbd-7aca-402b-98d9-f35baa124714.jpeg','2024-07-20 12:01:21','2024-07-20 12:01:21'),
(456,71,'a3eaf88c-7e6e-4cbb-87ad-908303862510.jpeg','2024-07-20 12:01:21','2024-07-20 12:01:21'),
(457,71,'d824b72a-7017-499b-a655-1c74694b343b.jpeg','2024-07-20 12:01:21','2024-07-20 12:01:21'),
(458,71,'3177d90d-f657-4e5f-bb4c-61afc95eb22a.jpeg','2024-07-20 12:01:21','2024-07-20 12:01:21'),
(459,71,'73dde2da-3a35-4411-9069-39ebeda3ae12.jpeg','2024-07-20 12:01:21','2024-07-20 12:01:21'),
(460,71,'45e90bbd-ad85-4809-811c-07f88f4fcc77.jpeg','2024-07-20 12:01:21','2024-07-20 12:01:21'),
(471,75,'temp_17215529859952279506623903917995.jpg','2024-07-21 09:09:53','2024-07-21 09:09:53'),
(472,75,'temp_1721552986066592134333729918419.jpg','2024-07-21 09:09:53','2024-07-21 09:09:53'),
(473,75,'temp_17215529861123317273459091830509.jpg','2024-07-21 09:09:53','2024-07-21 09:09:53'),
(474,76,'Screenshot_2023-12-18_195016.png','2024-07-21 09:49:15','2024-07-21 09:49:15'),
(475,76,'basictoollogo1.png','2024-07-21 09:49:15','2024-07-21 09:49:15'),
(476,76,'Screenshot_(1).png','2024-07-21 09:49:16','2024-07-21 09:49:16'),
(477,77,'temp_17216301201678182948826403193588.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(478,77,'temp_17216301201834731717828804683631.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(479,77,'temp_17216301201985271140521501810904.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(480,77,'temp_17216301202061385902303098797787.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(481,77,'temp_17216301202164501554645286157170.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(482,77,'temp_17216301202264912853810235714235.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(483,77,'temp_17216301202328123649509429858059.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(484,77,'temp_172163012023814817559998496815.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(485,77,'temp_17216301202441671916643359622781.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(486,77,'temp_17216301202505363003667664306515.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(487,77,'temp_17216301202557879323663070197348.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(488,77,'temp_17216301202603630843491234425150.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(489,77,'temp_17216301202652483324831977228339.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(490,77,'temp_17216301202692189579186397139149.jpg','2024-07-22 06:35:32','2024-07-22 06:35:32'),
(491,78,'temp_17216305507096445285384552309514.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(492,78,'temp_17216305507337162913258127722941.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(493,78,'temp_17216305507573790772511829372003.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(494,78,'temp_17216305507786728302275894687842.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(495,78,'temp_17216305508063461291364756857909.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(496,78,'temp_17216305508247123033865620053396.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(497,78,'temp_17216305508374105803869125932220.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(498,78,'temp_17216305508489175300821772495244.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(499,78,'temp_17216305508554308813292199090869.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(500,78,'temp_17216305508593236751164770601293.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(501,78,'temp_17216305508638151137630605369120.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(502,78,'temp_17216305508664628798884164001288.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(503,78,'temp_17216305508717698141505837406057.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(504,78,'temp_1721630550876275794447373317688.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(505,78,'temp_17216305508803824267820153665903.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(506,78,'temp_17216305508871823632224089303991.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(507,78,'temp_17216305508917872079502413580745.jpg','2024-07-22 06:42:43','2024-07-22 06:42:43'),
(508,79,'temp_17216317992118878619117484094419.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(509,79,'temp_17216317992346157970224797190536.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(510,79,'temp_17216317992437638186602015935377.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(511,79,'temp_17216317992555409983233073315422.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(512,79,'temp_17216317992674812911203734845743.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(513,79,'temp_172163179928188614961277775545.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(514,79,'temp_17216317992958217274832555350723.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(515,79,'temp_17216317993087807661692795399492.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(516,79,'temp_17216317993169105767069079331943.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(517,79,'temp_17216317993223103165152325249497.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(518,79,'temp_17216317993284397008503776354685.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(519,79,'temp_17216317993331999749284767377234.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(520,79,'temp_17216317993424726711502688270139.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(521,79,'temp_1721631799348572858101302319149.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(522,79,'temp_17216317993543179901849676480155.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(523,79,'temp_17216317993593360552793333414754.jpg','2024-07-22 07:03:31','2024-07-22 07:03:31'),
(524,80,'temp_17216653316662584085071103701769.jpg','2024-07-22 16:22:34','2024-07-22 16:22:34'),
(525,80,'temp_17216653317026694411191921093608.jpg','2024-07-22 16:22:34','2024-07-22 16:22:34'),
(526,80,'temp_1721665331724278746139643689003.jpg','2024-07-22 16:22:34','2024-07-22 16:22:34'),
(527,80,'temp_17216653317414947375321983671407.jpg','2024-07-22 16:22:34','2024-07-22 16:22:34'),
(528,81,'temp_17217238852699210901101748507830.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(529,81,'temp_17217238852766220440585425651140.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(530,81,'temp_17217238852811729606732621416799.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(531,81,'temp_17217238852874798781657179111392.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(532,81,'temp_17217238852932291449346685599753.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(533,81,'temp_17217238852982928400408242561658.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(534,81,'temp_1721723885303660715811355719905.jpg','2024-07-23 08:41:46','2024-07-23 08:41:46'),
(535,82,'temp_17217489668562069949006013660919.jpg','2024-07-23 15:36:17','2024-07-23 15:36:17'),
(536,82,'temp_1721748970881171372351038420546.jpg','2024-07-23 15:36:17','2024-07-23 15:36:17'),
(537,82,'temp_17217489733397930712089879272134.jpg','2024-07-23 15:36:17','2024-07-23 15:36:17'),
(538,83,'WhatsApp_Image_2024-07-13_at_18_42_39_(1)1.jpeg','2024-07-23 15:51:54','2024-07-23 15:51:54'),
(539,83,'WhatsApp_Image_2024-07-13_at_18_42_381.jpeg','2024-07-23 15:51:54','2024-07-23 15:51:54'),
(540,83,'WhatsApp_Image_2024-07-13_at_18_42_391.jpeg','2024-07-23 15:51:54','2024-07-23 15:51:54'),
(541,83,'WhatsApp_Image_2024-07-13_at_18_42_39_(2)1.jpeg','2024-07-23 15:51:54','2024-07-23 15:51:54'),
(542,83,'WhatsApp_Image_2024-07-13_at_18_42_40_(1)1.jpeg','2024-07-23 15:51:54','2024-07-23 15:51:54'),
(543,84,'temp_17217604119614723404987610838196.jpg','2024-07-23 18:47:14','2024-07-23 18:47:14'),
(544,84,'temp_17217604120174121869331109737634.jpg','2024-07-23 18:47:14','2024-07-23 18:47:14'),
(545,84,'temp_1721760412083662669680574311352.jpg','2024-07-23 18:47:14','2024-07-23 18:47:14'),
(546,84,'temp_17217604121329178380079614343576.jpg','2024-07-23 18:47:14','2024-07-23 18:47:14'),
(547,85,'temp_17218338195983008875976624187927.jpg','2024-07-24 15:10:34','2024-07-24 15:10:34'),
(548,85,'temp_17218338196701809699966855043096.jpg','2024-07-24 15:10:34','2024-07-24 15:10:34'),
(549,85,'temp_17218338197233289234896778529441.jpg','2024-07-24 15:10:34','2024-07-24 15:10:34'),
(550,85,'temp_17218338197718958143786647493745.jpg','2024-07-24 15:10:34','2024-07-24 15:10:34'),
(551,86,'temp_17221498829325291137722843261462.jpg','2024-07-28 06:58:55','2024-07-28 06:58:55'),
(552,86,'temp_17221498913981570807403674066581.jpg','2024-07-28 06:58:55','2024-07-28 06:58:55'),
(553,86,'temp_17221499062063193021588022161757.jpg','2024-07-28 06:58:55','2024-07-28 06:58:55'),
(554,87,'temp_17221525116736705326945393416569.jpg','2024-07-28 07:42:02','2024-07-28 07:42:02'),
(555,87,'temp_17221525118627807242174498498869.jpg','2024-07-28 07:42:02','2024-07-28 07:42:02'),
(556,87,'temp_1722152511920672818124338276910.jpg','2024-07-28 07:42:02','2024-07-28 07:42:02'),
(557,88,'temp_17221534992687058234889086396381.jpg','2024-07-28 07:58:31','2024-07-28 07:58:31'),
(558,88,'temp_17221534994217160079171910226847.jpg','2024-07-28 07:58:31','2024-07-28 07:58:31'),
(559,88,'temp_17221534994814083473772110556418.jpg','2024-07-28 07:58:31','2024-07-28 07:58:31'),
(560,89,'temp_17221537293673069517603376045503.jpg','2024-07-28 08:02:21','2024-07-28 08:02:21'),
(561,89,'temp_17221537294187080354325209146905.jpg','2024-07-28 08:02:21','2024-07-28 08:02:21'),
(562,89,'temp_17221537295384422298391623358914.jpg','2024-07-28 08:02:21','2024-07-28 08:02:21'),
(563,89,'temp_17221537296042371494444260940599.jpg','2024-07-28 08:02:21','2024-07-28 08:02:21'),
(564,90,'temp_1722171545895970188444688775577.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(565,90,'temp_17221715459317034174081314520917.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(566,90,'temp_17221715459443611405350060412265.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(567,90,'temp_17221715459561905652266788656226.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(568,90,'temp_17221715459682103298053133637704.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(569,90,'temp_17221715459808819447081841746296.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(570,90,'temp_17221715459884656601280283206897.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(571,90,'temp_17221715459943905949672879182369.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(572,90,'temp_17221715460024521661043383801721.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(573,90,'temp_17221715460123950454784425400148.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(574,90,'temp_17221715460208009502687587724809.jpg','2024-07-28 12:59:19','2024-07-28 12:59:19'),
(575,91,'temp_17223275041398125608341610512357.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(576,91,'temp_17223275041602682301711913901983.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(577,91,'temp_17223275041884167664738596874284.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(578,91,'temp_172232750419944723415265240297.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(579,91,'temp_17223275042125631319374139172543.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(580,91,'temp_17223275042324354700916357637532.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(581,91,'temp_17223275042504055562063657346858.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(582,91,'temp_1722327504265378216521705159161.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(583,91,'temp_17223275042868929451144919555964.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(584,91,'temp_17223275042956896782723091902389.jpg','2024-07-30 08:17:59','2024-07-30 08:17:59'),
(585,92,'temp_17223335144644326344685770421061.jpg','2024-07-30 10:02:12','2024-07-30 10:02:12'),
(586,92,'temp_17223335536481223351392734347593.jpg','2024-07-30 10:02:12','2024-07-30 10:02:12'),
(587,92,'temp_17223336091228284649188504351389.jpg','2024-07-30 10:02:12','2024-07-30 10:02:12'),
(588,92,'temp_17223336692717470790784633716808.jpg','2024-07-30 10:02:12','2024-07-30 10:02:12'),
(589,92,'temp_1722333696310893882454053605240.jpg','2024-07-30 10:02:12','2024-07-30 10:02:12'),
(590,92,'temp_17223337228917474063996389245912.jpg','2024-07-30 10:02:12','2024-07-30 10:02:12'),
(591,93,'temp_17223339893792026218345828012824.jpg','2024-07-30 10:09:10','2024-07-30 10:09:10'),
(592,93,'temp_17223340167005629991672731764125.jpg','2024-07-30 10:09:10','2024-07-30 10:09:10'),
(593,93,'temp_17223340912454601991830614044138.jpg','2024-07-30 10:09:10','2024-07-30 10:09:10'),
(594,93,'temp_17223341149931123410121251903161.jpg','2024-07-30 10:09:10','2024-07-30 10:09:10'),
(595,94,'temp_17223971122212403900582803427172.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(596,94,'temp_17223971122534845402113526925115.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(597,94,'temp_17223971122586110714025862149524.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(598,94,'temp_17223971122723222695412952419575.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(599,94,'temp_17223971122785419898883997165219.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(600,94,'temp_17223971122853553108049111490519.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(601,94,'temp_17223971122911640902161533841379.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(602,94,'temp_17223971122974261048462347614339.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(603,94,'temp_17223971123034417274426675837118.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(604,94,'temp_17223971123073306454298915358687.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(605,94,'temp_17223971123258179740431125284047.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(606,94,'temp_17223971123318235967857869058279.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(607,94,'temp_17223971123453449890544422141969.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(608,94,'temp_1722397112351831760425262533675.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(609,94,'temp_17223971123552752335388574459998.jpg','2024-07-31 03:38:59','2024-07-31 03:38:59'),
(610,95,'temp_1723463103682852412558520304570.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(611,95,'temp_17234631037126229163666516071333.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(612,95,'temp_17234631037208671169531549416256.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(613,95,'temp_17234631037267026856522672430737.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(614,95,'temp_17234631037315946734069654824332.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(615,95,'temp_17234631037379197035417840059379.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(616,95,'temp_17234631037414516600927642388858.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(617,95,'temp_1723463103746391704676406437216.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(618,95,'temp_17234631037493086674807739608322.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(619,95,'temp_17234631037533796619281878267125.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(620,95,'temp_17234631037571393155818451191568.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(621,95,'temp_172346310376178141887771916241.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(622,95,'temp_17234631037642037711120110750015.jpg','2024-08-12 11:46:02','2024-08-12 11:46:02'),
(626,97,'de5401d7-bde5-479e-9371-08b11a28122b.jpeg','2024-08-13 07:10:39','2024-08-13 07:10:39'),
(627,97,'9d7b1162-5880-49b8-a6d3-cf288f957bbb.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(628,97,'757f0064-5fab-454b-87da-3e089c8f42a3.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(629,97,'6b06fedd-fe78-4dde-b195-dc091dca7a88.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(630,97,'5e660c9a-a90a-4055-9b2c-91fb8ea1b138.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(631,97,'ca83d50c-325c-4714-b1b7-126606bca25e.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(632,97,'ba69416d-bd71-42b7-b218-b12b884c5fde.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(633,97,'53d6fab2-803e-4520-9f4b-001d0af56940.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(634,97,'5c4ce606-22de-4f19-b905-3e73a61d3ff6.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(635,97,'e38282ff-732a-4dd9-aeb3-de24fbd70173.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(636,97,'7af0e988-a6e3-4af4-9dc3-541809d5eabe.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(637,97,'052185e6-8c25-4431-9c74-793d61acd2a9.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(638,97,'4b03e767-54ad-4724-a74a-61aef64928fd.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(639,97,'80a75d68-6e28-4294-9faa-0a45be5d7733.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(640,97,'e02f7bd7-f7d8-4750-bbaa-986639431fdc.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(641,97,'26d49dfa-eda4-4f88-854b-e17b4b9f8500.jpeg','2024-08-13 07:10:40','2024-08-13 07:10:40'),
(642,98,'temp_17238045758014751152820888619205.jpg','2024-08-16 10:38:02','2024-08-16 10:38:02'),
(643,98,'temp_17238045758598131788238923201.jpg','2024-08-16 10:38:02','2024-08-16 10:38:02'),
(644,98,'temp_17238045759027758854687036331983.jpg','2024-08-16 10:38:02','2024-08-16 10:38:02'),
(645,98,'temp_17238045759477064822070700562703.jpg','2024-08-16 10:38:02','2024-08-16 10:38:02'),
(646,98,'temp_17238045759916130341508033265011.jpg','2024-08-16 10:38:02','2024-08-16 10:38:02'),
(647,98,'temp_17238045760362880866120500168809.jpg','2024-08-16 10:38:03','2024-08-16 10:38:03'),
(648,98,'temp_17238045760862346928911116960718.jpg','2024-08-16 10:38:03','2024-08-16 10:38:03'),
(649,98,'temp_17238045761276180045952649091806.jpg','2024-08-16 10:38:03','2024-08-16 10:38:03'),
(650,98,'temp_17238045761691881811952542088927.jpg','2024-08-16 10:38:03','2024-08-16 10:38:03'),
(651,98,'temp_17238045762218971921582041764685.jpg','2024-08-16 10:38:03','2024-08-16 10:38:03'),
(652,98,'temp_17238045762613939867822077287417.jpg','2024-08-16 10:38:03','2024-08-16 10:38:03'),
(653,99,'temp_17238060602584816091149299666633.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(654,99,'temp_17238060603187148774993775890612.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(655,99,'temp_17238060603645875006579588567864.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(656,99,'temp_17238060604102418511611721670846.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(657,99,'temp_17238060604733334401663759992917.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(658,99,'temp_17238060605423883537271877018156.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(659,99,'temp_17238060605993496946768006695110.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(660,99,'temp_17238060606466198546957325979106.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(661,99,'temp_17238060606887126376154700625246.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(662,99,'temp_17238060607293492003553681597674.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(663,99,'temp_17238060607695389253026116326693.jpg','2024-08-16 11:01:54','2024-08-16 11:01:54'),
(664,100,'temp_17238218470572850313825377036750.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(665,100,'temp_1723821847103982557449404316573.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(666,100,'temp_17238218471494298146085675768386.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(667,100,'temp_17238218472087622752269657639224.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(668,100,'temp_17238218472743893686237170664978.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(669,100,'temp_17238218473357121656781489487677.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(670,100,'temp_17238218473946199527136601857805.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(671,100,'temp_17238218474665305966446565731557.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(672,100,'temp_17238218475283823106601265880205.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(673,100,'temp_17238218475964505745550092008697.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(674,100,'temp_17238218476564299355740920171166.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(675,100,'temp_17238218477202517020029020740967.jpg','2024-08-16 15:24:40','2024-08-16 15:24:40'),
(676,101,'temp_17238950840923171890207645537879.jpg','2024-08-17 11:45:13','2024-08-17 11:45:13'),
(677,101,'temp_17238950841572882939899525441080.jpg','2024-08-17 11:45:13','2024-08-17 11:45:13'),
(678,101,'temp_17238950842045707762665131537761.jpg','2024-08-17 11:45:13','2024-08-17 11:45:13'),
(679,101,'temp_1723895084234452313037440428281.jpg','2024-08-17 11:45:13','2024-08-17 11:45:13'),
(680,102,'BMSuJCcfyo50DNNV2kQ1l-transformed3.jpeg','2024-08-22 07:13:23','2024-08-22 07:13:23'),
(681,102,'21477675845.jpg','2024-08-22 07:13:23','2024-08-22 07:13:23'),
(682,103,'temp_17243801696448455093844584011765.jpg','2024-08-23 02:29:39','2024-08-23 02:29:39'),
(683,103,'temp_17243801697124881129025272743568.jpg','2024-08-23 02:29:39','2024-08-23 02:29:39'),
(684,103,'temp_17243801697583141285789436098411.jpg','2024-08-23 02:29:39','2024-08-23 02:29:39'),
(685,103,'temp_17243801698054012214620475579837.jpg','2024-08-23 02:29:39','2024-08-23 02:29:39'),
(686,104,'temp_1724380224291508298751271042265.jpg','2024-08-23 02:30:33','2024-08-23 02:30:33'),
(687,104,'temp_17243802243123945034756130981621.jpg','2024-08-23 02:30:33','2024-08-23 02:30:33'),
(688,104,'temp_17243802243611710459240793108951.jpg','2024-08-23 02:30:33','2024-08-23 02:30:33'),
(689,104,'temp_17243802243981834416206296130769.jpg','2024-08-23 02:30:33','2024-08-23 02:30:33'),
(690,105,'temp_17243802820203799518239729202563.jpg','2024-08-23 02:31:42','2024-08-23 02:31:42'),
(691,105,'temp_1724380282068614545273121381338.jpg','2024-08-23 02:31:42','2024-08-23 02:31:42'),
(692,105,'temp_17243802821042968724767208645828.jpg','2024-08-23 02:31:42','2024-08-23 02:31:42'),
(693,105,'temp_17243802821238786619263641455016.jpg','2024-08-23 02:31:42','2024-08-23 02:31:42'),
(694,106,'temp_17243803631813757774422528432973.jpg','2024-08-23 02:33:11','2024-08-23 02:33:11'),
(695,106,'temp_17243803632057659987852764933186.jpg','2024-08-23 02:33:11','2024-08-23 02:33:11'),
(696,106,'temp_17243803632551394765126952805717.jpg','2024-08-23 02:33:11','2024-08-23 02:33:11'),
(697,106,'temp_17243803632916330016110688104529.jpg','2024-08-23 02:33:11','2024-08-23 02:33:11'),
(698,107,'car3.jpg','2024-08-23 06:18:58','2024-08-23 06:18:58'),
(699,107,'2148130197.jpg','2024-08-23 06:18:59','2024-08-23 06:18:59'),
(700,108,'temp_1724508582766783681873511921501.jpg','2024-08-24 14:09:57','2024-08-24 14:09:57'),
(701,108,'temp_17245085828794328860220331121924.jpg','2024-08-24 14:09:57','2024-08-24 14:09:57'),
(702,108,'temp_17245085830612326561186304252998.jpg','2024-08-24 14:09:57','2024-08-24 14:09:57'),
(703,108,'temp_17245085831372892360236540637767.jpg','2024-08-24 14:09:57','2024-08-24 14:09:57'),
(704,109,'temp_17245118453084639360924037971482.jpg','2024-08-24 15:04:16','2024-08-24 15:04:16'),
(705,109,'temp_17245118453697035511337455877435.jpg','2024-08-24 15:04:16','2024-08-24 15:04:16'),
(706,109,'temp_17245118454257861725766300211658.jpg','2024-08-24 15:04:16','2024-08-24 15:04:16'),
(707,109,'temp_17245118455468546644845556746363.jpg','2024-08-24 15:04:16','2024-08-24 15:04:16'),
(708,110,'temp_1724808998774102243377210691709.jpg','2024-08-28 01:36:56','2024-08-28 01:36:56'),
(709,110,'temp_1724808998783920978921473395152.jpg','2024-08-28 01:36:56','2024-08-28 01:36:56'),
(710,110,'temp_17248089987878048738118169419467.jpg','2024-08-28 01:36:56','2024-08-28 01:36:56'),
(711,110,'temp_17248089987923611903757307823553.jpg','2024-08-28 01:36:56','2024-08-28 01:36:56'),
(712,111,'temp_17248281095567227774628442863739.jpg','2024-08-28 06:55:59','2024-08-28 06:55:59'),
(713,111,'temp_17248281245434309601781578177094.jpg','2024-08-28 06:55:59','2024-08-28 06:55:59'),
(714,111,'temp_1724828155753657506945244693806.jpg','2024-08-28 06:55:59','2024-08-28 06:55:59'),
(715,112,'temp_17248308637457752313830661164829.jpg','2024-08-28 07:42:15','2024-08-28 07:42:15'),
(716,112,'temp_17248308852288321409627262024115.jpg','2024-08-28 07:42:15','2024-08-28 07:42:15'),
(717,112,'temp_17248308852446229247941968745126.jpg','2024-08-28 07:42:15','2024-08-28 07:42:15'),
(718,112,'temp_17248308852534844279012033226390.jpg','2024-08-28 07:42:15','2024-08-28 07:42:15'),
(719,112,'temp_17248308852641031670180638836817.jpg','2024-08-28 07:42:15','2024-08-28 07:42:15'),
(720,112,'temp_17248308852727544377456326527204.jpg','2024-08-28 07:42:15','2024-08-28 07:42:15'),
(721,113,'temp_17249878656425451006816294695064.jpg','2024-08-30 03:17:53','2024-08-30 03:17:53'),
(722,113,'temp_17249878656496848148138801925102.jpg','2024-08-30 03:17:53','2024-08-30 03:17:53'),
(723,113,'temp_17249878656551967377699225504499.jpg','2024-08-30 03:17:53','2024-08-30 03:17:53'),
(724,114,'temp_17249880985282906658700213782888.jpg','2024-08-30 03:21:52','2024-08-30 03:21:52'),
(725,114,'temp_17249880985354010999137172028431.jpg','2024-08-30 03:21:52','2024-08-30 03:21:52'),
(726,114,'temp_17249880985394064808115421513718.jpg','2024-08-30 03:21:52','2024-08-30 03:21:52'),
(727,114,'temp_1724988098543802558436001580491.jpg','2024-08-30 03:21:52','2024-08-30 03:21:52'),
(728,115,'temp_17249887176147025969606937787380.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(729,115,'temp_17249887176233117662690725712575.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(730,115,'temp_17249887176364311027783184569732.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(731,115,'temp_17249887176445782989042981725720.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(732,115,'temp_17249887176507612853542860935274.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(733,115,'temp_17249887176561030423517743886546.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(734,115,'temp_17249887176622567677406955143362.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(735,115,'temp_17249887176686260605249575164166.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(736,115,'temp_17249887176722397474711842557438.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(737,115,'temp_17249887176782386014263326466667.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(738,115,'temp_17249887176847526490617444160737.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(739,115,'temp_17249887176883804537183245183340.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(740,115,'temp_17249887176948218284118770668059.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(741,115,'temp_17249887176988655763695011520870.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(742,115,'temp_1724988717703698385708238418444.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(743,115,'temp_17249887177086892629201963498710.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(744,115,'temp_17249887177137833392101429428261.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(745,115,'temp_17249887177214601904679242771327.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(746,115,'temp_17249887177248099976145475842915.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(747,115,'temp_17249887177271441709469487861650.jpg','2024-08-30 03:32:27','2024-08-30 03:32:27'),
(748,116,'temp_17249889400964074719768089545754.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(749,116,'temp_17249889401061478381626182664858.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(750,116,'temp_172498894011448242344068511388.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(751,116,'temp_17249889401206185197294591683018.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(752,116,'temp_17249889401277107050197952255938.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(753,116,'temp_17249889401354629903319255127592.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(754,116,'temp_17249889401418978547709566836634.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(755,116,'temp_17249889401494823877190977243389.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(756,116,'temp_17249889401561852113988003954994.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(757,116,'temp_17249889401626645446062766331719.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(758,116,'temp_1724988940168673783664220334805.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(759,116,'temp_1724988940172531597199025447074.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(760,116,'temp_17249889401786581696905291945952.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(761,116,'temp_17249889401833631785657414094857.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(762,116,'temp_17249889401877594025429480012556.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(763,116,'temp_17249889401927446084080764926119.jpg','2024-08-30 03:35:55','2024-08-30 03:35:55'),
(764,117,'temp_17249893716887874902353355083519.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(765,117,'temp_17249893716977459046348155802479.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(766,117,'temp_17249893717052317108813047888658.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(767,117,'temp_17249893717137605578119644414217.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(768,117,'temp_17249893717226543990958070192102.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(769,117,'temp_17249893717282741915040513428057.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(770,117,'temp_17249893717332890846814509369558.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(771,117,'temp_17249893717404400708166574224063.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(772,117,'temp_17249893717467140158914634182697.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(773,117,'temp_17249893717513359618421156876522.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(774,117,'temp_17249893717579113358697104793594.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(775,117,'temp_17249893717621704718089441884624.jpg','2024-08-30 03:43:11','2024-08-30 03:43:11'),
(776,118,'temp_17250046836723585027118397702723.jpg','2024-08-30 07:59:59','2024-08-30 07:59:59'),
(777,118,'temp_17250046837062884546082785286037.jpg','2024-08-30 07:59:59','2024-08-30 07:59:59'),
(778,118,'temp_17250047036226717908612960713298.jpg','2024-08-30 07:59:59','2024-08-30 07:59:59'),
(779,118,'temp_1725004716242944881836180430786.jpg','2024-08-30 07:59:59','2024-08-30 07:59:59'),
(780,118,'temp_17250047162494723565664808835010.jpg','2024-08-30 07:59:59','2024-08-30 07:59:59'),
(781,118,'temp_17250047162587901262623274972639.jpg','2024-08-30 07:59:59','2024-08-30 07:59:59'),
(782,119,'temp_17250834838257916800378936283435.jpg','2024-08-31 05:51:34','2024-08-31 05:51:34'),
(783,119,'temp_17250834838354624839763989628580.jpg','2024-08-31 05:51:34','2024-08-31 05:51:34'),
(784,119,'temp_17250834838444985729613870946702.jpg','2024-08-31 05:51:34','2024-08-31 05:51:34'),
(785,119,'temp_17250834838498162273815427280252.jpg','2024-08-31 05:51:34','2024-08-31 05:51:34'),
(786,120,'temp_17250987846237668234649299450019.jpg','2024-08-31 10:06:29','2024-08-31 10:06:29'),
(787,120,'temp_17250987846348387989216613489621.jpg','2024-08-31 10:06:29','2024-08-31 10:06:29'),
(788,120,'temp_17250987846391900088091875680406.jpg','2024-08-31 10:06:29','2024-08-31 10:06:29'),
(789,120,'temp_17250987846529063664709359240940.jpg','2024-08-31 10:06:29','2024-08-31 10:06:29'),
(790,121,'temp_17255195474351792858436347653437.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(791,121,'temp_17255195474523470802685575158223.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(792,121,'temp_17255195474684235765506541743092.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(793,121,'temp_172551955761593655437817439938.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(794,121,'temp_17255195576327873454520456279951.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(795,121,'temp_17255195576434260419780926924370.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(796,121,'temp_17255195576514067892650182211997.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(797,121,'temp_17255195576638226759590884729806.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(798,121,'temp_17255195637921703379548606757769.jpg','2024-09-05 07:01:01','2024-09-05 07:01:01'),
(799,122,'temp_17258757705047996364851082166203.jpg','2024-09-09 09:56:19','2024-09-09 09:56:19'),
(800,122,'temp_17258757705098121917050398634172.jpg','2024-09-09 09:56:19','2024-09-09 09:56:19'),
(801,122,'temp_17258757705145295377201565630448.jpg','2024-09-09 09:56:19','2024-09-09 09:56:19'),
(802,123,'temp_17258807170511752699253.jpg','2024-09-09 11:19:01','2024-09-09 11:19:01'),
(803,123,'temp_1725880721753784285975.jpg','2024-09-09 11:19:01','2024-09-09 11:19:01'),
(804,123,'temp_1725880726106961922701.jpg','2024-09-09 11:19:01','2024-09-09 11:19:01'),
(805,124,'temp_17301327732926375820851533412995.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(806,124,'temp_17301327733261052443745559853671.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(807,124,'temp_17301327733481371008188023833767.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(808,124,'temp_1730132773377458302277789270123.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(809,124,'temp_17301327734196889755265445065134.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(810,124,'temp_17301327734584912090794096477038.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(811,124,'temp_17301327734843825835582940673092.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(812,124,'temp_17301327735146248136468450330870.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(813,124,'temp_17301327735673679314946782272361.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(814,124,'temp_17301327736264951441432915425573.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(815,124,'temp_17301327736871568157815597267849.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(816,124,'temp_17301327737406326319300763667216.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(817,124,'temp_17301327737933637778665576969634.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(818,124,'temp_17301327738438101844609107098020.jpg','2024-10-28 16:26:21','2024-10-28 16:26:21'),
(819,125,'temp_17301344724978727001246044711941.jpg','2024-10-28 16:55:11','2024-10-28 16:55:11'),
(820,125,'temp_17301345065351829641580477432844.jpg','2024-10-28 16:55:11','2024-10-28 16:55:11'),
(821,125,'temp_1730134508883284240205640824116.jpg','2024-10-28 16:55:11','2024-10-28 16:55:11'),
(822,126,'temp_1730183242600500806487810400352.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(823,126,'temp_17301832426186078492236263036574.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(824,126,'temp_17301832426277637771907697410116.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(825,126,'temp_17301832426366263537540748801216.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(826,126,'temp_17301832426448008999137609700426.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(827,126,'temp_17301832426527922994138581529912.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(828,126,'temp_17301832426621890764587045760126.jpg','2024-10-29 06:28:51','2024-10-29 06:28:51'),
(829,127,'temp_17305379762953390090258555016032.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(830,127,'temp_17305379763105556184458614242971.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(831,127,'temp_17305379763258975513701933050363.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(832,127,'temp_17305379763394004325497963887224.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(833,127,'temp_17305379763522125481407894848627.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(834,127,'temp_17305379763672409811027186694210.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(835,127,'temp_17305379763962414831669640135405.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(836,127,'temp_17305379764119178375615997708188.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(837,127,'temp_17305379764252931452244880156370.jpg','2024-11-02 08:59:54','2024-11-02 08:59:54'),
(838,127,'temp_17305381024851557027379492426704.jpg','2024-11-02 09:01:57','2024-11-02 09:01:57'),
(839,127,'temp_17305381025026213563599015025448.jpg','2024-11-02 09:01:57','2024-11-02 09:01:57'),
(840,127,'temp_173053810251649658265673776233.jpg','2024-11-02 09:01:57','2024-11-02 09:01:57'),
(841,127,'temp_1730538102531999689779991069655.jpg','2024-11-02 09:01:57','2024-11-02 09:01:57'),
(842,127,'temp_17305400307615216378969824281501.jpg','2024-11-02 09:33:55','2024-11-02 09:33:55'),
(843,127,'temp_17305400307826801916811063861323.jpg','2024-11-02 09:33:55','2024-11-02 09:33:55'),
(844,127,'temp_1730540030800380172729026308717.jpg','2024-11-02 09:33:55','2024-11-02 09:33:55'),
(845,127,'temp_1730701140846479946153273676980.jpg','2024-11-04 06:19:13','2024-11-04 06:19:13'),
(846,127,'temp_17307011408724572037650105789396.jpg','2024-11-04 06:19:13','2024-11-04 06:19:13'),
(847,127,'temp_17307011408968493381375734442431.jpg','2024-11-04 06:19:13','2024-11-04 06:19:13'),
(848,127,'temp_1730701140918290544144934282697.jpg','2024-11-04 06:19:13','2024-11-04 06:19:13'),
(849,127,'temp_17307011693836713807892027145549.jpg','2024-11-04 06:19:50','2024-11-04 06:19:50'),
(850,127,'temp_17307011693993507485087092066434.jpg','2024-11-04 06:19:50','2024-11-04 06:19:50'),
(851,127,'temp_17307011694164746374792190908632.jpg','2024-11-04 06:19:50','2024-11-04 06:19:50'),
(852,127,'temp_17307011694355391080282137574906.jpg','2024-11-04 06:19:50','2024-11-04 06:19:50'),
(853,127,'temp_17347626466522946359674071451872.jpg','2024-12-21 06:32:53','2024-12-21 06:32:53'),
(854,127,'temp_17347626466616065953521141030337.jpg','2024-12-21 06:32:53','2024-12-21 06:32:53'),
(855,127,'temp_17347626466782359902634596272997.jpg','2024-12-21 06:32:53','2024-12-21 06:32:53'),
(856,127,'temp_17377796050558524675454567001897.jpg','2025-01-25 04:33:45','2025-01-25 04:33:45'),
(857,127,'temp_17377796050625483291976426409332.jpg','2025-01-25 04:33:45','2025-01-25 04:33:45'),
(858,127,'temp_17377796050692877661597365673619.jpg','2025-01-25 04:33:45','2025-01-25 04:33:45'),
(859,127,'temp_17377796050749180455827211387712.jpg','2025-01-25 04:33:45','2025-01-25 04:33:45'),
(860,127,'temp_17377796050809114882877613914213.jpg','2025-01-25 04:33:45','2025-01-25 04:33:45'),
(861,127,'temp_17377796050851394542310190608577.jpg','2025-01-25 04:33:45','2025-01-25 04:33:45');
/*!40000 ALTER TABLE `tbl_mp_vehicle_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_mp_vehicle_price_request`
--

DROP TABLE IF EXISTS `tbl_mp_vehicle_price_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_mp_vehicle_price_request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_mp_vehicle_price_request`
--

/*!40000 ALTER TABLE `tbl_mp_vehicle_price_request` DISABLE KEYS */;
INSERT INTO `tbl_mp_vehicle_price_request` VALUES
(1,10,97,55888,'2024-08-17 11:36:56'),
(3,4,21,6000000,'2024-08-22 07:43:27'),
(4,8,48,100000,'2024-08-22 07:45:29'),
(5,1,107,1200000,'2024-08-25 07:09:23'),
(9,82,120,2590000,'2024-08-31 10:07:06'),
(10,4,121,500000,'2024-09-05 07:34:38'),
(11,7,124,500000,'2024-10-29 06:30:39');
/*!40000 ALTER TABLE `tbl_mp_vehicle_price_request` ENABLE KEYS */;

--
-- Table structure for table `tbl_packages`
--

DROP TABLE IF EXISTS `tbl_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `content` text NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_packages`
--

/*!40000 ALTER TABLE `tbl_packages` DISABLE KEYS */;
INSERT INTO `tbl_packages` VALUES
(2,'New','<ul>\r\n <li>Dealer to Dealer (B2B)</li>\r\n <li>Cannot sell to a customer</li>\r\n <li>Unlimited listing for dealers</li>\r\n</ul>\r\n','5000','service_3.jpg','2024-04-09 10:55:35','2024-09-10 07:04:58'),
(3,'Basic Plan','<ul>\r\n <li>Renewal Amt – (Actual price- 7500/-, Discounted price- 5000/- for 1 month). </li>\r\n <li>Unlimited slots</li>\r\n <li>Deal in Dealer-to-dealer cars.</li>\r\n <li>10% discount on 1 outstation booking.</li>\r\n</ul>\r\n','5000','','2024-04-09 10:55:56','2025-06-16 10:29:54'),
(4,'Standard Plan','<ul>\r\n <li>Renewal Amt– (Actual price- 10000/-, Discounted price- 7000/- for 1 month). </li>\r\n <li>Unlimited slots.</li>\r\n <li>Deal in all segments.</li>\r\n <li>1 free home Delivery (Intracity).</li>\r\n</ul>\r\n','7000','','2024-04-09 10:56:12','2025-06-16 10:28:55'),
(5,'Premium Plan','<ul>\r\n <li>Renewal Amount – (Actual price- 21000/-, Discounted price- 16000/- for 3 months).</li>\r\n <li>Unlimited slots.</li>\r\n <li>Deal in all segments.</li>\r\n <li>3 free home Deliveries.</li>\r\n</ul>\r\n','16000','','2024-04-09 10:56:27','2025-06-15 05:32:01');
/*!40000 ALTER TABLE `tbl_packages` ENABLE KEYS */;

--
-- Table structure for table `tbl_pages`
--

DROP TABLE IF EXISTS `tbl_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages`
--

/*!40000 ALTER TABLE `tbl_pages` DISABLE KEYS */;
INSERT INTO `tbl_pages` VALUES
(1,1,'About','','2023-12-01 06:26:01');
/*!40000 ALTER TABLE `tbl_pages` ENABLE KEYS */;

--
-- Table structure for table `tbl_payment`
--

DROP TABLE IF EXISTS `tbl_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` tinyint(4) NOT NULL,
  `package_id` tinyint(4) NOT NULL,
  `order_id` varchar(200) NOT NULL,
  `payment_id` varchar(200) NOT NULL,
  `status` enum('Pending','Completed','','') NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_payment`
--

/*!40000 ALTER TABLE `tbl_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_payment` ENABLE KEYS */;

--
-- Table structure for table `tbl_pick_odometer_images`
--

DROP TABLE IF EXISTS `tbl_pick_odometer_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pick_odometer_images` (
  `id` int(11) NOT NULL,
  `bookingId` int(11) NOT NULL,
  `reading` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pick_odometer_images`
--

/*!40000 ALTER TABLE `tbl_pick_odometer_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_pick_odometer_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_pickup_images`
--

DROP TABLE IF EXISTS `tbl_pickup_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pickup_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingId` int(11) NOT NULL,
  `image` varchar(150) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pickup_images`
--

/*!40000 ALTER TABLE `tbl_pickup_images` DISABLE KEYS */;
INSERT INTO `tbl_pickup_images` VALUES
(1,15,'temp2105136954486807404.jpg','2025-06-29 15:54:39'),
(2,21,'temp8063967339591294459.jpg','2025-06-29 17:13:01'),
(3,22,'temp722834673068162440.jpg','2025-06-30 15:18:00'),
(4,22,'temp1305084679271574597.jpg','2025-06-30 16:58:51');
/*!40000 ALTER TABLE `tbl_pickup_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_service_category`
--

DROP TABLE IF EXISTS `tbl_service_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_service_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_service_category`
--

/*!40000 ALTER TABLE `tbl_service_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_service_category` ENABLE KEYS */;

--
-- Table structure for table `tbl_services`
--

DROP TABLE IF EXISTS `tbl_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_services`
--

/*!40000 ALTER TABLE `tbl_services` DISABLE KEYS */;
INSERT INTO `tbl_services` VALUES
(1,'Driver Booking','driver1.jpg','2024-09-03 14:30:40'),
(2,'Trailer Booking','trailer2.jpg','2024-09-03 14:30:55'),
(3,'Inspection','inspection.jpg','2024-09-03 14:31:04'),
(4,'Towing','towing-app.jpg','2024-10-25 05:00:05'),
(5,'RTO Assist','rto-app.jpg','2024-10-25 05:01:01'),
(6,'Insurance','insurance-app.jpg','2024-10-25 05:01:39');
/*!40000 ALTER TABLE `tbl_services` ENABLE KEYS */;

--
-- Table structure for table `tbl_signup`
--

DROP TABLE IF EXISTS `tbl_signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `autoGenId` varchar(100) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` text NOT NULL,
  `phoneNumber` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `state` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `dlNumber` varchar(100) DEFAULT NULL,
  `frontLic` varchar(150) NOT NULL,
  `backLic` varchar(150) NOT NULL,
  `image` varchar(100) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `yearinbzns` int(10) NOT NULL,
  `partner` varchar(300) NOT NULL,
  `partnerphone` varchar(300) NOT NULL,
  `partneremail` varchar(300) NOT NULL,
  `gst` varchar(300) NOT NULL,
  `pan` varchar(300) NOT NULL,
  `lat` text NOT NULL,
  `lng` text NOT NULL,
  `type` enum('DRIVER','DEALER','USER') NOT NULL,
  `checkTandC` tinyint(1) NOT NULL,
  `source` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `token` text NOT NULL,
  `device_token` text DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT 0,
  `login_time` varchar(200) DEFAULT NULL,
  `deleteAccountReq` tinyint(4) NOT NULL,
  `freeTrailAccessed` tinyint(4) NOT NULL DEFAULT 0,
  `freeTrialEndDate` varchar(200) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_signup`
--

/*!40000 ALTER TABLE `tbl_signup` DISABLE KEYS */;
INSERT INTO `tbl_signup` VALUES
(1,'','sagar ','test','testing@gma.com','25d55ad283aa400af464c76d713c07ad',9015191992,'',2,5,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',0,'8c344f407e3ca53cb907cd7d227c02f9f4f435163ec43f880781d5f18348a14960592e9a3547adf76698033f693d57251812043548e2621f8696c43c86faec26MRb++WV4GAtNJYCe/4mmJVbjNGmGXaeAQo8NEN4WYuA=','eJ0xeIrdR1KT1O31AMBCOq:APA91bH9dBh6Xp0S9e1LbmnI1eCbbuehje-O0zTmCUu7v0xKJN__7F6aRp7kKaJrS-Yr7Lvb8A-wDxLP8-u03xmvtXv7M_fcwsekNvGH9JRxVbLrmJuzSOU',0,'2025-07-01 12:26:40',0,0,NULL,'2025-06-21 14:54:27','2025-07-01 06:56:43'),
(2,'','sagar drive','sagar drive','driver@gmail.com','25d55ad283aa400af464c76d713c07ad',7503196450,'',0,0,NULL,'Screenshot_20250620_114530.jpg','Screenshot_20250620_204536.jpg','Screenshot_20250620_2045361.jpg','',0,'','','','','','','','DRIVER',0,'APP',1,'b0f7a368b63df618d48a93dfb1e551d8d2d7c31f71aba4757d7c6af23d955ebd959e21f1a523a52710c61be8805b7489f3e6a41f3f625b7113f2272c59024b3coGT1lTl9fqx7NQRAzUpidhWreI6oP3gxpaaXez/8WOk=',NULL,0,'2025-06-30 21:04:27',0,0,NULL,'2025-06-21 14:57:26','2025-06-30 15:34:27'),
(3,'','second driver','second driver','second@gmail.com','e807f1fcf82d132f9bb018ca6738a19f',1234567890,'',0,0,NULL,'Screenshot_20250620_2045362.jpg','Screenshot_20250620_1145301.jpg','IMG_20250619_230748.jpg','',0,'','','','','','','','DRIVER',0,'APP',1,'85d6c3251dffb9b165d5adbf6867ef5847f9cb1a8dc5563be6a121893da219aada8f0f36648cf531945dc090a123335e72dc97a9542e9b296c197f9abeae4c421l/NgModSCZeYGEUL7Bbt0CH8Vu23gZiNKCXpBu+3eo=',NULL,0,'2025-06-26 20:25:54',0,0,NULL,'2025-06-21 15:00:36','2025-06-26 14:55:54'),
(4,'','Amit','Shukla','aashukla04@gmail.com','6c98406a475b568d42d30c2e1db3e8c6',9764334576,'',21,626,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',0,'f94761955adcd945b7481cfdb5b6b3f4e6b316905020615ba5e1d019a4ba28ee5410839b4523002b3d2a61bc638ae511d9b3e6d1d520a968bf3ce1f2628aa929qffj2bsfoCQwZ8oo77Cb7CmY7sRalkAxKGcbF6ME7cI=','fSi-6dboQaaIRHEYhB_aUy:APA91bFUrSHNsnP5VW4T8K_dnut259Xmjpe_tEnv4I_gG1wFvFMytkUI_vUEYZmN0oCt0DCKUfAFTuUTMs_hU1MGe1wdtUP134r6dCNGEXHpo4l6whCNUgM',0,'2025-07-01 11:18:03',0,0,NULL,'2025-06-22 12:04:32','2025-07-01 05:48:03'),
(5,'','Pratik','Gadkar','pratikgkar@gmail.com','0e594ddd28a244384d2dd208d3528073',7757053797,'',21,628,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',0,'1260a049c59971cc4bc0ec218c15fbf121d3361de24b4b3a64ec72d4d772be76b76bac77fff767bd411d0c3db67de3d64c978a8006a81ecb07f9feb4c6b96d65mWx9rTsasV7pUvs4nFg/ldGCYtnQ+3LXPSZ0RohKNAw=','ckBgCgWbT2Cy-NdqDONUjU:APA91bEoYlj-Bx3no77fJeVH_1pP-abkGJ-FuF0CPcqNLPMgFaHh9S4Z_Fc2u8CK0Xih5p4nMrKDx8ItFbPLcnUNm-6SqlscNPEg_i9GtaAhz2CQg3P9HG0',0,'2025-07-01 10:53:38',0,0,NULL,'2025-06-25 15:32:44','2025-07-01 05:23:42'),
(6,'','shashikumar','kumbhar','skumbhar031@gmail.com','3cefc1cb9d0d69947e653f2319141725',9653610533,'',21,629,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',0,'8ac08f3dc5227200247f1c7f4afc3fb210b5ef436beeeffbd9726dd3e50270ad1d6d3cd0148b6b679ee9ea464b0e74a3380eb720bd3649f0502e33e0bd089043FgWCIk2zfb7854oYs4baA4SVIPV9kM85S8XYl8r8u1Q=','eVdSWscbRJWG5JcnHJaO8e:APA91bGRsBy5pQii0QvAkHKD8BPAGrHBNRX2tsiA0v5Rpj_j1VI4OeSOhGVO-5AMT0s2TkrTzEFqgv9IUNHTbr48nATcchez5aGNcxoN5NQQyf64r1Ii2lU',0,'2025-07-01 08:49:00',0,0,NULL,'2025-06-25 16:17:18','2025-07-01 03:19:02'),
(7,'','test driver 3','test driver 3','test3@gmail.com','6fb42da0e32e07b61c9f0251fe627a9c',987654321,'',0,0,NULL,'IMG_20250623_183211.jpg','IMG_20250623_183203.jpg','IMG_20250623_1832111.jpg','',0,'','','','','','','','DRIVER',0,'APP',1,'0727195a42019cfc409dd30c8ba937c06226c31c2b0435a2368eab4eeca2e424195f82a93ec80d22bb484ce49fd3cb58959b45649a8d8fd75dac7108c3330a9eFiFZ62kHqx9nOsFsGWyEIDmhiUmdXCMD/73gCmPlgqI=',NULL,0,'2025-06-28 10:54:43',0,0,NULL,'2025-06-26 08:19:58','2025-06-28 05:24:43'),
(8,'','pratik new','pratik new','xxxxxxx@gmail.com','0e594ddd28a244384d2dd208d3528073',7777777777,'',0,0,NULL,'IMG-20250627-WA0002.jpg','IMG-20250627-WA00021.jpg','IMG-20250627-WA0005.jpg','',0,'','','','','','','','DRIVER',0,'APP',1,'4d6537ae8225f8b468bbc6a7b929d0c309b1567928d30d552dac33fec9c42f76281ade32bd9a6d134ff73ae5c71841ec86df7e4fd6f1a563cd868d7b1fe38993+54AWB07fSpcbFEvMiGUhorbYAawYXB3wsD744Crnek=',NULL,0,'2025-06-27 19:38:31',0,0,NULL,'2025-06-27 14:08:07','2025-06-27 14:08:31'),
(9,'','Amittest','Amittest','123@gmail.com','6c98406a475b568d42d30c2e1db3e8c6',9090909090,'',0,0,NULL,'Screenshot_20250627_193507_VahanAssist3.jpg','Screenshot_20250627_193507_VahanAssist4.jpg','Screenshot_20250627_193507_VahanAssist5.jpg','',0,'','','','','','','','DRIVER',0,'APP',1,'391d45a0614ea5432dcc3cb66e87306badecf0b35044a5c75297d8ff9cb680b77e8b7ff2b2c53c1cdad956bf282ed49cb5153458d9dc4dc3d1d7f10bf5c44905V+IJWgAcSyDLC4T3bnKVWm9+C61cA/HDrqLe1us9frc=',NULL,0,'2025-07-01 00:19:55',0,0,NULL,'2025-06-27 14:08:18','2025-06-30 18:49:55'),
(10,'','amittest2','amittest2','040590@gmail.com','6c98406a475b568d42d30c2e1db3e8c6',0,'',0,0,NULL,'Screenshot_20250701_001609_VahanAssist.jpg','Screenshot_20250701_001609_VahanAssist1.jpg','Screenshot_20250701_001609_VahanAssist2.jpg','',0,'','','','','','','','DRIVER',0,'APP',1,'344a5bab7c08657a74f94b378918c0d48f255d104e8bb1f978777cf6c33c75b05a203fbf54bf064cc0bd379b955b1ff015e788aecbe2e20777b1e9496f6aed8bKVXiB+SdEckmisiQ4cTfSqPmJIfAJ7+s3GXtVhOVd0c=',NULL,0,'2025-07-01 00:40:59',0,0,NULL,'2025-06-30 19:09:39','2025-06-30 19:10:59'),
(11,'','SANJEEV ','BHOSALE ','sheetalbhosalebhosale@gmail.com','0cd8b3b2640f4510650ac80de6bc4c36',9960944599,'',21,301,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'bbf5aba6d2c78298d6789bafbb52cd956a59e260e35a0b74d22ba6388c9a1c6d479313100e5acaef1b86961381160a22aa7bbfac79c0e92882600715188a11facy9H07FM0Pn4rYERntU0DLglz+CQqSFvRu2BpTVKTKs=','di4u5FQYT_eh97aUO8pjyG:APA91bFNI1RGcMmY6qSJf7CD8QU96znmh24l_CZ9DHKAfjhrxwnkktT45bM4-1dXt0gZBV8RDh1tU3-XymJix7iYNhpgLIaPJpTzZz9H8hgXk_pC5pVwTQ8',0,'2025-07-01 11:02:18',0,0,NULL,'2025-07-01 05:28:21','2025-07-01 08:21:30'),
(12,'','Gajanan ','Patil ','gajananmotors@gmail.com','644ea54acb2cc42fa4d5561329531c7c',8999809224,'',21,301,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'',NULL,0,NULL,0,0,NULL,'2025-07-01 05:46:37','2025-07-01 08:20:59'),
(13,'','vikas','gade','vikasgade4140@gmail.com','0862393b51ca4192d56da48d71f50a2b',7020218222,'',21,282,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'',NULL,0,NULL,0,0,NULL,'2025-07-01 06:27:08','2025-07-01 08:20:52'),
(14,'','Aman','Dubey','amandubey042004@gmail.com','3ae4242ccb28ce97f1ce99675daeaad7',9307993551,'',21,626,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'8c235847406c86de074e04498507b57eb94b3da27d5c5f14b5eca8db53c48e2c0b537619c1edca95dc59b365f366914e06a497f5fb087aef8441e2196a8a7c2d8hlUi7oljD2pZwWxV9LZzPSbqy1jlIURL0U/Kp1bNmY=',NULL,0,'2025-07-01 13:04:41',0,0,NULL,'2025-07-01 07:20:47','2025-07-01 08:16:18'),
(15,'','Pradeep','Selakoti','pradeepselakoti@gmail.com','12c7424cf7be9a63122d40a0c3128103',6399660562,'',35,601,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'56c9d6acbcbce661bf048fab76c0f522dc543e290df3cdda3c904c352e0fdfe905f79b2617a3ccf2515e28c6269e23c0ba62c5e697e785522a5887d4bb2531c6aHH17jVbuA77YWFPkG6BSsHvT+/b9F7hzP7duHYNqyA=','dwzbBjEuTImcwqMbJAsnkK:APA91bHUt07_-oOdew7QpCoDJ6hwWd3DpYPrTpci12YXEP9TiqE-xPE2Jezdz2-DKRPrAR0M7XTmVFuhn-hfF8EozrTEWgNaHmNJ-kij3sfxho_6d9m-FfU',0,'2025-07-01 13:32:17',1,0,NULL,'2025-07-01 08:00:46','2025-07-01 08:16:08'),
(16,'','Kunal','Mehrotra','kunalmehrotra52@gmail.com','524aba18741083e3f192a00ad4847d82',8299428021,'',34,569,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'2561519ef0340f12a7fcc786f24e5837468d55004992f99908bb021db403e9886c3e281d27ca6e48758c1679934f4e8a16cbca204a60b3f263c20ef29392fc667kYCZYNLQT7X9bKZfZt+RD2fk0RjeUr/yRzFEPnzIFU=','ePXewA2YT4uWSpjzqierrj:APA91bEVl5TzI9NX4kqMcuuxazD5eXmps4CcnSkD7pL5Aghu9qjil9RGV1m0FR1EBFpe9YYVWq3cpGJX8pcjJph883v03Aa3mRC_PYFpL0ywaqoFO8OA3J0',0,'2025-07-01 13:47:17',0,0,NULL,'2025-07-01 08:15:36','2025-07-01 08:17:19'),
(17,'','Pradeep','Selakoti 2','selakotiprashant@gmail.com','12c7424cf7be9a63122d40a0c3128103',8954387327,'',35,601,NULL,'','','','',0,'','','','','','','','DEALER',0,'APP',1,'8c8c42e99c35c8bd5041472eda6cf8b3e5c8acdcdddb986f2a7aa776fd4405caaef1bef2cd66b773bdd9a3b8ce387df06d3b2d14ecde64ee3cf779bd54c958206naHOVJWoFpKKi0aOx32PifET6X9O6konOE501GGaX4=',NULL,0,'2025-07-01 13:56:10',0,0,NULL,'2025-07-01 08:25:03','2025-07-01 09:36:32');
/*!40000 ALTER TABLE `tbl_signup` ENABLE KEYS */;

--
-- Table structure for table `tbl_states`
--

DROP TABLE IF EXISTS `tbl_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_states`
--

/*!40000 ALTER TABLE `tbl_states` DISABLE KEYS */;
INSERT INTO `tbl_states` VALUES
(1,'Andaman & Nicobar Islands'),
(2,'Andhra Pradesh'),
(3,'Arunachal Pradesh'),
(4,'Assam'),
(5,'Bihar'),
(6,'Chandigarh'),
(7,'Chhattisgarh'),
(8,'Dadra & Nagar Haveli'),
(9,'Daman & Diu'),
(10,'Delhi'),
(11,'Goa'),
(12,'Gujarat'),
(13,'Haryana'),
(14,'Himachal Pradesh'),
(15,'Jammu & Kashmir'),
(16,'Jharkhand'),
(17,'Karnataka'),
(18,'Kerala'),
(19,'Lakshadweep'),
(20,'Madhya Pradesh'),
(21,'Maharashtra'),
(22,'Manipur'),
(23,'Meghalaya'),
(24,'Mizoram'),
(25,'Nagaland'),
(26,'Odisha'),
(27,'Puducherry'),
(28,'Punjab'),
(29,'Rajasthan'),
(30,'Sikkim'),
(31,'Tamil Nadu'),
(32,'Telangana'),
(33,'Tripura'),
(34,'Uttar Pradesh'),
(35,'Uttarakhand'),
(36,'West Bengal');
/*!40000 ALTER TABLE `tbl_states` ENABLE KEYS */;

--
-- Table structure for table `tbl_vehicle`
--

DROP TABLE IF EXISTS `tbl_vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryId` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `price` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_vehicle`
--

/*!40000 ALTER TABLE `tbl_vehicle` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_vehicle` ENABLE KEYS */;

--
-- Table structure for table `tbl_vehicle_category`
--

DROP TABLE IF EXISTS `tbl_vehicle_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_vehicle_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_vehicle_category`
--

/*!40000 ALTER TABLE `tbl_vehicle_category` DISABLE KEYS */;
INSERT INTO `tbl_vehicle_category` VALUES
(2,'Car','red-sedan-car-isolated-white-vector.png','2024-05-11 09:44:57');
/*!40000 ALTER TABLE `tbl_vehicle_category` ENABLE KEYS */;

--
-- Table structure for table `tbl_vehicle_images`
--

DROP TABLE IF EXISTS `tbl_vehicle_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_vehicle_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicleId` int(11) NOT NULL,
  `image` varchar(150) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_vehicle_images`
--

/*!40000 ALTER TABLE `tbl_vehicle_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_vehicle_images` ENABLE KEYS */;

--
-- Table structure for table `tbl_wishlist`
--

DROP TABLE IF EXISTS `tbl_wishlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_wishlist`
--

/*!40000 ALTER TABLE `tbl_wishlist` DISABLE KEYS */;
INSERT INTO `tbl_wishlist` VALUES
(36,79,37,'2024-07-22 07:04:55','2024-07-22 07:04:55'),
(37,78,37,'2024-07-22 07:04:57','2024-07-22 07:04:57'),
(38,77,37,'2024-07-22 07:05:00','2024-07-22 07:05:00'),
(44,65,24,'2024-07-24 17:17:21','2024-07-24 17:17:21'),
(45,64,24,'2024-07-24 17:17:31','2024-07-24 17:17:31'),
(46,81,24,'2024-07-24 17:18:20','2024-07-24 17:18:20'),
(56,97,74,'2024-09-09 10:22:57','2024-09-09 10:22:57'),
(61,111,1,'2024-09-09 11:42:59','2024-09-09 11:42:59'),
(62,107,1,'2024-09-09 11:43:01','2024-09-09 11:43:01'),
(88,97,115,'2025-04-07 16:53:01','2025-04-07 16:53:01'),
(90,93,5,'2025-06-25 15:34:07','2025-06-25 15:34:07'),
(91,95,5,'2025-06-25 15:34:08','2025-06-25 15:34:08'),
(92,92,5,'2025-06-25 15:34:17','2025-06-25 15:34:17'),
(93,91,5,'2025-06-25 15:34:20','2025-06-25 15:34:20'),
(94,90,5,'2025-06-25 15:34:21','2025-06-25 15:34:21'),
(95,94,14,'2025-07-01 07:36:22','2025-07-01 07:36:22'),
(96,95,14,'2025-07-01 07:36:24','2025-07-01 07:36:24');
/*!40000 ALTER TABLE `tbl_wishlist` ENABLE KEYS */;

--
-- Dumping routines for database 'u837566661_vahan'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 14:27:56
